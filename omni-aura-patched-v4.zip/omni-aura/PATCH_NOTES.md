# Omni-Aura update 4, 24 November 2026

## What I found about "it won't answer" and "it is not calling"
You said both also happen on the website, so this was never only the APK.
- **The voice model changed under the app.** Omni-Aura talks through Google's `gemini-3.8-live`. Per Google's own notes for that model,
  tools now run in the background by default, and the model decides for itself whether speech was meant for it, so it can stay
  silent. The voice screen now tells it that every spoken word is for it, makes commands finish before it says "done", prompts it
  twice if it hears you but stays quiet (and then says so on screen), and shows the real reason when the service closes a session.
- **Sound now goes through the same engine the "hear the voice" test uses** (the one you confirmed works in the APK), instead of two
  separate ones at special sample rates. The microphone is turned into 16 kHz sound by the app itself.
- **A check-in could be lost.** If every text model was busy when the 3-hour job ran, the check-in call was never placed. It now places
  the call with a plain question instead. The server also notes every time its scheduled job reaches it.
- I cannot see your server from here, so I cannot prove which of these hit you. **Settings > Voice and calls check** will tell you:
  it shows whether the check-in trigger arrived and when, quiet hours, focus mode, whether any phone or browser is registered to be
  called, and the last calls with how each was delivered. Use "Test voice reply" and "Test microphone" there too.

## Do these, in this order
1. **Supabase.** Open the SQL editor, paste all of `supabase/02-chats.sql` and run it. Nothing to edit. It keeps every message and
   makes your old messages one chat called "Earlier conversation". (Until you run it, everything works with one single chat.)
2. **Push the whole folder to GitHub.** Render redeploys the server and the web app. The APK shows the new web app next time it opens.
3. **Build the APK once more** (Actions > build-apk > Run workflow) and install it. This one adds phone parts (below).
   If those parts fail to compile, the workflow builds the plain APK by itself and prints a warning, so you always get an APK.
4. **Open the new APK.** Allow notifications when asked. Then Settings > Voice and calls check > "Android: calls and sharing":
   allow the four listed permissions, tap **Ring test**, and lock the phone. You should get a full-screen call.
5. Tap **Place a test call** and **Test voice reply** in the same page.

## What is new
- **Calls ring in the Android app even when it is closed**, like a phone call, with Answer and Decline, over the lock screen. No
  Google services and no ntfy. A small background service asks the server every 15 seconds. A silent "Ready for calls" notice stays in the shade.
  The phone must allow unrestricted battery use for this; some brands (Xiaomi, Oppo, Vivo, Samsung) also have an autostart list.
- **Live voice can share the screen over other apps in the Android app** until you stop it: a small bubble stays on screen with a
  STOP button, and the voice session keeps running while you use other apps. In a computer browser it uses the browser's own screen sharing.
- **Camera: selfie and back**, with a switch button and a small preview. (Android only lets an app use the camera while it is on
  screen, so the camera stops if you leave the app; screen sharing does not.)
- **Tap the glowing logo** to cut it off while it talks, or to ask it to answer. **Details** shows what the connection is doing.
- **Life and psychology.** It now talks through stress, sleep, habits, relationships, money and decisions the way a well-read friend
  would, listens first, does not diagnose, and points to a professional or to emergency help (999 / 112, Kenya Red Cross 1199) when needed.
- **It knows you are its creator**, and says so when it comes up, while staying honest about what it runs on.
- **Train** (side panel): tell it how things work. Each lesson is read into every chat and call from then on. You can also say
  "I am teaching you: ..." in a chat or call and it files the lesson there. Edit or forget lessons any time.
- **Chats in their own side panel**: New chat, a list grouped by day, search, rename, delete, and a Calls list. Docked beside the chat on wide screens.
- **Sign out** is in the side panel (and still in Settings). It also stops the phone listening for calls; they come back after you sign in.
- Your portfolio link is on the "contact Ashraf" page.

## Honest limits
- I could not run the app or build the APK here. The web and server code were syntax-checked, the native Android code was compiled only
  against stand-in classes, and the build has the automatic fallback above. The first real test of ringing and screen sharing is on your phone.
- Android shows its own "start sharing?" box each time you share the screen; that cannot be skipped.
- Calls reach the phone within about 15 seconds. The listener also keeps the free Render server awake.
- Voice and chat limits on the free Gemini tier are Google's.
- No new settings are needed. Optional: `VITE_PORTFOLIO_URL` changes the portfolio link.

---

# Omni-Aura update 3, 23 November 2026

## What changed
1. **The APK no longer opens to a black page, and it updates itself.** The APK is now a thin shell that opens your live web app,
   so every feature of the web app is in the APK, and every time the web app is redeployed (a push to GitHub, Render
   rebuilds) the APK shows the new version the next time it is opened. You never build the APK again for ordinary changes.
   Build it again only when a *native* feature is added (a new plugin or permission); this update adds some, so build it once now.
   - If the web app cannot be reached, the APK shows a small "Try again" page instead of a black one.
   - If anything fails while the app starts, the screen now says what failed (and offers Try again) instead of staying black.
   - A build made without its database address shows a plain explanation on screen.
   - While the app is open it notices a newer version and offers **Update now**; after a couple of minutes in the background it
     switches by itself.
2. **Fingerprint.** Settings, Security has two switches. Each is proven to work before it turns on, so it cannot lock you out.
   - *Open the app with my fingerprint:* the prompt appears by itself on the lock screen. The passphrase still works. If the
     server has no passphrase, the fingerprint alone opens the app (with "Sign out instead" as the way out).
   - *Ask for my fingerprint before sensitive actions:* approving or sending replies, turning on auto-send or changing the allow-list,
     downloading a backup, clearing chat history, adding or removing emergency contacts, sending a test alert, changing the code
     word, and turning the fingerprint off. Emergency features (SOS, "I am safe") are never delayed by it.
   - In the Android app it uses the phone's own prompt. In Chrome on a phone with a fingerprint sensor it uses the browser's.
   - It no longer fails silently: if the phone has no fingerprint saved, or this APK lacks the plugin, Settings says so.
3. **The voice is faster.** Four causes were fixed: the call used to wait for the background notes, then fetch its connection
   token, then connect, one after the other (now all start together, and the notes are fetched ahead of time); the microphone
   was sent in 256 ms pieces (now 64 ms); the glowing logo redrew an expensive blur 60 times a second and kept phones too busy
   to handle audio promptly (now cheap); and the background notes given to the voice were long (now shorter). It also answers sooner
   after you stop talking. If the voice service ever refuses the new turn-taking settings, the call retries without them by itself.
4. **One voice.** Calls, alerts and the test call used to be read by the phone's built-in voice. They are now read by the same live
   voice you talk to (Charon), and the phone's voice is only a fallback if that cannot connect. Settings, Calls has
   **Hear the assistant voice (test)**. To change the voice for everything, set `VOICE_NAME` on the server (default Charon).
5. **Attach files in chat.** A paperclip beside the message box: photos (shrunk first), PDFs, audio, text and code files. Up to 4
   files, 8 MB each, 12 MB in all. Pictures, PDFs and audio are read by Gemini; text and code are read as data. Add a question or
   send them alone. "Save picture" and "Download a backup" now work in the Android app too (they open the share sheet).
6. The message box is now two rows (text above, buttons below) so five buttons fit on a narrow phone.

## What to do, once
1. **Web app address.** GitHub, Actions, build-apk, Run workflow, and paste your web app address (the Render *static site*,
   e.g. https://something.onrender.com). To avoid pasting it each time, save it once: repository Settings, Secrets and variables,
   Actions, Variables, New variable, name `APP_URL`. Without it the workflow stops with a message (so you never get an APK that differs from the website by accident).
   Ticking `built_in_copy` builds the old kind that carries its own copy and does not update itself.
2. Run the workflow, download the APK, **uninstall the old app first** (this one has a different home, so you sign in again), install.
3. Keep the `DEBUG_KEYSTORE_B64` secret (section below) so any later APK installs over the top.
4. Redeploy the server (Render) so the new chat upload and voice changes are live.
5. Supabase, SQL editor: run `supabase/01-schema.sql` (edit your email on the marked line first; it stops with a message if you forget).
   It replaces the old `schema.sql` and `update-calls.sql`, repairs everything and keeps your data. For a true fresh start run
   `supabase/00-wipe.sql` first (change NO to WIPE on its marked line: this deletes all Omni-Aura data). Last result: tables_found 19.
6. After installing the APK, open Settings, **This app**: it says whether the APK is live (self-updating), whether the server is
   reachable, and whether the fingerprint, file and notification plugins are inside this APK.

## Notes
- The Android app cannot receive Web Push; it still gets ntfy when closed. Chrome installed as an app does receive Push.
- Free-tier voice limits are Google's. If the voice feels slow only at some hours, that is queueing on Google's side.
- If fingerprint says "no fingerprint support", the plugin step in the workflow log shows a warning: build again.

---

# Omni-Aura update 2, 22 November 2026

## What changed
1. **Old mail no longer rings.** The Gmail poll asked for every unread inbox message with no date limit, so long-forgotten
   unread mail was pulled in ten at a time and each one could ring. It now reads only unread mail from the last 2 days
   (`MAIL_DAYS` on the server changes that, 1 to 14), and anything received more than 12 hours ago is sorted quietly:
   no call, no draft. Settings, Mail, **Clear old mail drafts** discards drafts that have sat for more than 3 days.
2. **One call at a time.** Only one call is ever on screen. While you are on a call, or one is ringing, new calls wait.
   When you finish, Omni-Aura tells you what came in ("Another emergency, sir. ..."), most serious first, with a
   **Take it** button for anything that needs a conversation. Declining a call lets the next waiting one ring. A call
   nobody answers in 45 seconds becomes a missed call.
3. **It remembers calls.** Every spoken call is summarised into the chat history (lines starting with a phone symbol).
   Each new call starts with those summaries, your recent chat, your notes, open tasks and what is coming up.
4. **Hang up.** Say "hang up" or "end the call" and it ends after a short goodbye. It can also hang up by itself when a
   matter is settled.
5. **It manages its settings, by chat or voice:** quiet hours, focus mode, daily word goal, automatic model switching,
   call screen (full or banner), plus tasks, events, notes, shopping and email drafts. It will not switch on auto-send:
   that stays in Settings.
6. **Google Docs and Drive.** Find files, read them, create a new Doc, add to Docs it created itself. It never edits
   a document it did not create. Needs the APIs and scopes below.
7. **Settings, Google connection, Test Google now** checks every account against Gmail, Calendar, Drive and Docs and says
   in plain words what fails (revoked token, API switched off, missing scope).

## Google: what the token needs
1. Google Cloud, APIs and Services, Library: enable the Gmail API, Google Calendar API, Google Drive API and Google Docs API.
2. OAuth consent screen: set the publishing status to **In production**. While it says Testing, refresh tokens die after 7 days.
3. Make a new refresh token at developers.google.com/oauthplayground: gear icon, tick "Use your own OAuth credentials"
   (G_ID and G_SECRET), pick these scopes, Authorize APIs, Exchange authorization code for tokens, copy the refresh token
   (it starts with 1//):
   - https://mail.google.com/
   - https://www.googleapis.com/auth/calendar
   - https://www.googleapis.com/auth/drive
   - https://www.googleapis.com/auth/documents
4. Put it in G_ACCOUNTS as {"main":"1//..."} on the server and redeploy.

## Nothing new to run in Supabase this time.

---

# Omni-Aura update, 22 November 2026

## What changed
1. **Omni-Aura calls you.** Check-ins, messages that need your decision (appointments, money, security, anything urgent)
   and test calls ring as an incoming call: full screen with the orb, or a banner at the top (Settings, Calls and alerts).
   Answer starts a spoken conversation; Decline dismisses it. With the app closed the call is the phone's own notification
   (Web Push) with Answer and Decline buttons. ntfy is now only the last resort for ordinary alerts and is never used for
   security alerts. A spoken decision on a reply is understood: "no" discards the draft, "change it" rewrites it. Sending
   still needs the Approve button and your PIN.
2. **New loading animation.** Fine layered strands flow along one large infinity curve, each led by an atom.
   It is also the splash screen, now sized to the screen.
3. **A general assistant.** The chat answers anything: code, whole apps and pages (with Copy, and Run for HTML),
   plans, maths, translation. Say "draw ..." or tap the picture button to make an image (Gemini image model, with a free
   backup service). It can add tasks, events, shopping items and notes, set focus mode and draft emails for approval.
   It cannot run commands on your server or devices: that would let a chat message run code.
4. **App lock.** Set APP_PASSPHRASE on the server. The app asks for it, said or typed, on every open and after 5 minutes
   in the background. Three quick taps on the logo still send the silent SOS from the lock screen.
5. **Strangers.** A sign-in with an account that is not yours shows "Haha, nice try" with your contact email, and you
   are alerted directly with the email they used. A real account that is not yours is also signed out and reported if it
   reaches the server.
6. **Google bug.** G_ACCOUNTS is now read in every common format (curly quotes, single quotes, name=token pairs), and the
   app says exactly what is wrong instead of "add G_ID, G_SECRET". See Settings, Google connection.

## Do this once
1. (Superseded by update 3: run `supabase/01-schema.sql` instead.)
2. Render, server service, Environment: add `APP_PASSPHRASE`. Optional: `ALERT_EMAIL` (where emailed security alerts go if
   no phone is registered; defaults to OWNER_EMAIL).
3. Push the code to GitHub and let Render redeploy both services (the server installs the new `web-push` package).
4. Open the app, Settings, Calls and alerts, **Turn on direct calls**, then **Ring me now (test)**.
5. Supabase, Authentication, Sign In / Providers: switch off "Allow new users to sign up".
6. Optional, static site only: `VITE_CONTACT_EMAIL` changes the address shown on the nice-try page.

## G_ACCOUNTS format
`{"main":"1//0g...refresh-token..."}` with straight double quotes. The value must be a Google OAuth **refresh token**
(starts with 1//), not an email address. Several accounts: `{"main":"1//0g...","work":"1//0g..."}`.

## Limits worth knowing
- A web app cannot take over the lock screen the way a native phone call does. With the app closed, the call is a
  notification that stays until you act on it; opening the app shows the full call screen.
- Web Push works in Chrome on Android and in an installed web app. The Android APK (a WebView) cannot receive it, so the
  APK still gets ntfy when it is closed, and the call screen when it is open.
- The spoken passphrase is checked as words, not as a voiceprint. Anyone who knows the phrase can say it.
- The safe-walk quick check in the Safety tab still uses ntfy action buttons on purpose; it was not touched.

---

# Earlier patch notes — November 2026

## Critical fixes

### 1. SOS can no longer silently fail (server + app)
The 60-second quiet period now starts **after** an alert gets out, not before.
A failed attempt can always be retried. Two simultaneous taps share one alert.
The Help button now shows what actually happened instead of always saying "Done."
Four tries are made before giving up; a failed SOS is queued in localStorage and
sent the next time the phone comes online.

### 2. Safety tab duplicate removed (App.jsx)
`<Safety />` was rendered on lines 638 and 640. Line 640 is gone.

### 3. Voice screen: microphone is always released on unmount, close and error
`Voice.jsx` calls `stop()` on unmount, on tab hide (after 45 s) and on the Live
API's `onclose` and `onerror`. The session reconnects with the resumption handle
when the ten-minute limit is hit; it ends cleanly if no handle is available.

### 4. The "≡" button no longer spans the full header
The global `button{width:100%}` rule scoped to `.page section button` does not
reach the header. `button.brand` has its own rule and is `width:auto`.

### 5. Failed replies now show why (server + app)
`/api/outbox/:id/approve` returns `{ sent, result, error }`. The UI reads `result`,
which is set for both success and failure, so a refused send is visible in the app.

### 6. Edited replies cannot be overwritten by a realtime refresh
Unsent edits live in a module-level `DRAFTS` object that is not touched by a
re-render from a new message or by leaving the Inbox tab and coming back.

### 7. Blank-screen risk removed (server + app)
The `strict()` wrapper in `server.js` turns every Supabase `.error` into a thrown
exception, so a 200 response with `null` data is no longer possible. The UI uses
`arr()` for every list (`filter` and `map` cannot crash), and an `<Boundary>`
error screen replaces any white-screen crash.

### 8. Inbound messages saved before triage (server)
`triage()` now inserts the row into `inbox` first (marked `pending`), then tries
to classify it. If every model is cooling down, the message is kept and the
`/cron/gmail` poll calls `retriage()` on the pending rows.

### 9. Memory: newest 40 notes are used (server)
`ctx()` previously loaded the **oldest** 40 notes. It now loads the newest 40,
then reverses them so older context comes first.

---

## Other server fixes

- **Double-tap Approve** sends once: an in-memory lock prevents two concurrent
  approvals of the same outbox or actions item.
- **ntfy quick-check priority is 5 (urgent)**: the timer check now uses
  `Priority: 5` so the notification is not silent.
- **`/cron/safety` is documented** in `about.md` and must run every minute.
- **WhatsApp safety template noted**: if `WA_SAFETY_TEMPLATE` is unset, free-text
  alerts only reach contacts within the 24-hour window. The limitation is noted in
  `about.md` and `terms.html`.
- **Code word matches whole words only**: the regex uses Unicode word-boundary
  anchors so "star" does not fire on "start".
- **Backup pages through Supabase's 1 000-row default**: each table is now read
  1 000 rows at a time until exhausted.
- **Google Calendar helper now throws clearly**: the helper in `features.js` and
  `actions.js` throws with the Google error message instead of returning an opaque
  object. Calendar sync and event deletion never white-screen the app.
- **Google sign-in error messages are human-readable**: `gToken()` maps
  `invalid_grant`, `invalid_client`, `unauthorized_client` and `invalid_request`
  to plain-English hints (shown in Settings → Email accounts).
- **Account recovery or backup codes do not work for G_REFRESH**: the `invalid_grant`
  hint says this explicitly.
- **Receipt scan and account list show the error when Google is down**: instead of
  returning empty results with no explanation.
- **New scene always sends `body: ''` and `words: 0`**: so the write does not
  depend on a Supabase column default.
- **`writing_log.upsert` passes `onConflict: 'day'`**: so it works without a
  server-side default index.
- **Calendar sync does not delete local events when the remote list was cut at 100**.
- **`/terms` and `/privacy` links are absolute** (`API + '/terms'`) so they reach
  the server pages from the installed APK.
- **Policy pages updated**: `home.html`, `privacy.html` and `terms.html` now
  describe auto-reply correctly and mention ntfy and the WhatsApp limitation.

---

## CI / build fixes

- **Biometric plugin pinned to 9.1.2**: `9.x` is the last line whose README says
  it supports Capacitor 7. `--legacy-peer-deps` is now the fallback, not the
  default.
- **Persistent debug signing key**: the workflow checks for a `DEBUG_KEYSTORE_B64`
  secret. Without it you must uninstall the old APK before installing a new build.
  See "How to set up a persistent debug key" below.

---

## UI redesign

| Item | Detail |
|------|--------|
| Palette | Black (`#000`), navy panels (`#060c17`, `#0c1626`), mint (`#76f2c4`), cobalt blue (`#2563ff`), ice blue headings (`#9cc2ff`), off-white text (`#eaf1ff`) |
| Layout | Collapsing side panel (slides in on mobile, pinned and collapsible on ≥ 900 px); Chat is the primary page |
| Loading | Mint-to-blue infinity trail loop |
| Voice bubble | The logo itself, glowing. Blue outer halo and mint rays expand with the microphone level. The halo pulses faster while OMNI-AURA is speaking. |
| Triple-tap SOS | Tap the logo three times quickly on any screen. Nothing shows and nothing sounds. Phone buzzes: once to start, twice on success, one long buzz on failure. |
| Long-press logo | Opens Safety (useful when Safety is hidden from the menu) |
| Check-in | Voice first, type as fallback. The check-in card sits below the chat history, not above it. |
| App icons | Regenerated from the new logo in black and mint. |

---

## Schema (`supabase/01-schema.sql`)

The file creates all 16 tables with RLS enabled, the `events.gcal_id` unique
constraint the calendar sync needs, the `outbox`, `checkins` and `inbox` SELECT
policies for Realtime, and the `writing_log.day` primary key. It is safe to run
more than once. **Change the owner email in `is_owner()` before running it.**

---

## How to set up a persistent debug signing key

Run this once on your machine (macOS / Linux):

```bash
keytool -genkeypair -v -keystore debug.keystore -alias androiddebugkey \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android \
  -dname "CN=Android Debug,O=Android,C=US"
base64 -i debug.keystore | pbcopy      # macOS: copies the base64 string to the clipboard
```

Paste the result into a GitHub Actions secret called `DEBUG_KEYSTORE_B64`.
Every CI build will use the same key, so new APKs install over old ones without
needing an uninstall.
