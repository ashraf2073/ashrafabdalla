# Omni-Aura

server/ = Render Web Service (Node). app/ = Render Static Site + Android APK (Capacitor). Setup steps were sent in chat.

APK: run the build-apk workflow once with your web app address (APP_URL). The APK opens the live web app, so it updates itself; see PATCH_NOTES.md.
