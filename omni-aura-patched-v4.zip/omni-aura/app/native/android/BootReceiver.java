package com.ashraf.omniaura;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

/** After a restart or an app update, start listening for calls again (if they were turned on). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            if (OmniState.prefs(context).getBoolean("standby_on", false)) {
                ContextCompat.startForegroundService(context, new Intent(context, StandbyService.class));
            }
        } catch (Throwable ignored) {
            /* the phone may refuse; opening the app starts it again */
        }
    }
}
