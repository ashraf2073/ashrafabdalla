package com.ashraf.omniaura;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;

/** Notification channels, and the notification that rings like an incoming call. */
final class CallRinger {
    private CallRinger() { }

    static final String CH_CALLS = "omni_calls_v1";
    static final String CH_MISSED = "omni_missed_v1";
    static final String CH_STANDBY = "omni_standby_v1";
    static final String CH_SESSION = "omni_session_v1";
    static final int CALL_ID = 4101;
    static final int STANDBY_ID = 4102;
    static final int SESSION_ID = 4103;
    static final int SHARE_ID = 4104;
    static final int MISSED_ID = 4105;

    static int flags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    static Intent openApp(Context c) {
        return new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    }

    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        NotificationChannel calls = new NotificationChannel(CH_CALLS, "Incoming calls", NotificationManager.IMPORTANCE_HIGH);
        calls.setDescription("Omni-Aura calling you: check-ins and decisions that need you");
        AudioAttributes ring = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        calls.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE), ring);
        calls.enableVibration(true);
        calls.setVibrationPattern(new long[] {0, 700, 500, 700, 500, 700});
        calls.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(calls);

        NotificationChannel missed = new NotificationChannel(CH_MISSED, "Missed calls", NotificationManager.IMPORTANCE_DEFAULT);
        missed.setDescription("A call from Omni-Aura that you did not answer");
        nm.createNotificationChannel(missed);

        NotificationChannel standby = new NotificationChannel(CH_STANDBY, "Ready for calls", NotificationManager.IMPORTANCE_LOW);
        standby.setDescription("Shows that Omni-Aura is listening for its calls");
        standby.setShowBadge(false);
        nm.createNotificationChannel(standby);

        NotificationChannel session = new NotificationChannel(CH_SESSION, "Voice session and screen sharing", NotificationManager.IMPORTANCE_LOW);
        session.setDescription("Shown while a live voice session or a screen share is running");
        session.setShowBadge(false);
        nm.createNotificationChannel(session);
    }

    /** Rings like a call: sound, vibration, full screen over the lock screen where the phone allows it. */
    static void ring(Context c, long id, String title, String say, boolean urgent) {
        channels(c);
        int base = (int) (Math.abs(id) % 100000L) * 3;
        Intent open = openApp(c).putExtra("omni_call_id", id).putExtra("omni_answer", false);
        Intent answer = openApp(c).putExtra("omni_call_id", id).putExtra("omni_answer", true);
        Intent decline = new Intent(c, StandbyService.class).setAction(StandbyService.ACTION_DECLINE).putExtra("omni_call_id", id);
        PendingIntent openPi = PendingIntent.getActivity(c, base + 1, open, flags());
        PendingIntent answerPi = PendingIntent.getActivity(c, base + 2, answer, flags());
        PendingIntent declinePi = PendingIntent.getService(c, base + 3, decline, flags());
        String text = say == null ? "" : say;
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_CALLS)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle(title == null || title.length() == 0 ? "Omni-Aura is calling" : "Omni-Aura: " + title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(true)
                .setTimeoutAfter(45000L)
                .setContentIntent(openPi)
                .setFullScreenIntent(openPi, true)
                .addAction(android.R.drawable.sym_action_call, "Answer", answerPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Decline", declinePi)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE))
                .setVibrate(new long[] {0, 700, 500, 700, 500, 700});
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(CALL_ID, n);
    }

    static void missed(Context c, long id, String say) {
        channels(c);
        PendingIntent pi = PendingIntent.getActivity(c, 9, openApp(c), flags());
        Notification n = new NotificationCompat.Builder(c, CH_MISSED)
                .setSmallIcon(android.R.drawable.sym_call_missed)
                .setContentTitle("Missed call from Omni-Aura")
                .setContentText(say == null ? "" : say)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(say == null ? "" : say))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(MISSED_ID, n);
    }

    static void cancel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(CALL_ID);
    }
}
