package com.ashraf.omniaura;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;
import com.getcapacitor.JSObject;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(OmniNativePlugin.class);
        super.onCreate(savedInstanceState);
        takeCall(getIntent());
    }

    @Override
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        takeCall(intent);
    }

    @Override
    public void onResume() {
        super.onResume();
        OmniState.foreground = true;
    }

    @Override
    public void onPause() {
        super.onPause();
        OmniState.foreground = false;
        /* While a voice session or a screen share is running, the page must keep running with another app in front. */
        if (OmniState.sessionOn || OmniState.sharing) {
            try {
                if (getBridge() != null && getBridge().getWebView() != null) {
                    getBridge().getWebView().onResume();
                    getBridge().getWebView().resumeTimers();
                }
            } catch (Throwable ignored) {
                /* best effort */
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        /* the lock-screen privileges are only for the moment a call opens the app */
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                setShowWhenLocked(false);
                setTurnScreenOn(false);
            } catch (Throwable ignored) {
                /* best effort */
            }
        }
    }

    /** The app was opened from a call notification: show over the lock screen, silence the ring, tell the page. */
    private void takeCall(Intent i) {
        if (i == null || !i.hasExtra("omni_call_id")) return;
        long id = i.getLongExtra("omni_call_id", 0L);
        boolean answer = i.getBooleanExtra("omni_answer", false);
        i.removeExtra("omni_call_id");
        i.removeExtra("omni_answer");
        OmniState.launchCallId = id;
        OmniState.launchAnswer = answer;
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                setShowWhenLocked(true);
                setTurnScreenOn(true);
            } catch (Throwable ignored) {
                /* best effort */
            }
        }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(CallRinger.CALL_ID);
        } catch (Throwable ignored) {
            /* best effort */
        }
        JSObject d = new JSObject();
        d.put("id", id);
        d.put("answer", answer);
        OmniState.emit("callOpened", d);
    }
}
