package com.ashraf.omniaura;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;

import androidx.activity.result.ActivityResult;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

/** What the web page cannot do on its own: ring when the app is closed, share the screen over other apps, stay alive in the background. */
@CapacitorPlugin(name = "OmniNative")
public class OmniNativePlugin extends Plugin {
    private boolean routedSpeaker = false;
    private boolean previousSpeaker = false;

    @Override
    public void load() {
        OmniState.plugin = this;
    }

    @Override
    protected void handleOnDestroy() {
        if (OmniState.plugin == this) OmniState.plugin = null;
    }

    void emit(String event, JSObject data) {
        notifyListeners(event, data);
    }

    private void openSettings(PluginCall call, Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Throwable t) {
            call.reject("Could not open that settings page: " + t.getMessage());
        }
    }

    private Uri me() {
        return Uri.parse("package:" + getContext().getPackageName());
    }

    /* ---------- what this phone has and has not allowed ---------- */
    @PluginMethod
    public void info(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        r.put("version", 4);
        r.put("sdk", Build.VERSION.SDK_INT);
        r.put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c));
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        r.put("battery", Build.VERSION.SDK_INT < 23 || (pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName())));
        r.put("notifications", NotificationManagerCompat.from(c).areNotificationsEnabled());
        boolean fullScreen = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) fullScreen = nm.canUseFullScreenIntent();
        }
        r.put("fullScreen", fullScreen);
        SharedPreferences p = OmniState.prefs(c);
        r.put("standbyOn", p.getBoolean("standby_on", false));
        r.put("standbyRunning", StandbyService.running);
        r.put("lastOk", p.getLong("last_ok", 0L));
        r.put("lastError", p.getString("last_err", ""));
        r.put("sharing", OmniState.sharing);
        r.put("session", OmniState.sessionOn);
        call.resolve(r);
    }

    /* ---------- ringing when the app is closed ---------- */
    @PluginMethod
    public void standbyStart(PluginCall call) {
        String api = call.getString("apiUrl", "");
        String key = call.getString("key", "");
        Integer every = call.getInt("intervalSec", 15);
        if (api == null || !api.startsWith("https://") || key == null || key.length() < 20) {
            call.reject("The server address or the phone's key is missing.");
            return;
        }
        while (api.endsWith("/")) api = api.substring(0, api.length() - 1);
        OmniState.prefs(getContext()).edit()
                .putString("api", api)
                .putString("key", key)
                .putInt("every", every == null ? 15 : every)
                .putBoolean("standby_on", true)
                .putString("last_err", "")
                .apply();
        try {
            ContextCompat.startForegroundService(getContext(), new Intent(getContext(), StandbyService.class));
            call.resolve();
        } catch (Throwable t) {
            call.reject("Could not start the background service: " + t.getMessage());
        }
    }

    @PluginMethod
    public void standbyStop(PluginCall call) {
        SharedPreferences p = OmniState.prefs(getContext());
        final String api = p.getString("api", "");
        final String key = p.getString("key", "");
        p.edit().putBoolean("standby_on", false).remove("key").apply();
        getContext().stopService(new Intent(getContext(), StandbyService.class));
        if (api != null && api.length() > 0 && key != null && key.length() > 0) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        StandbyService.http("POST", api + "/api/device/unregister", key);
                    } catch (Throwable ignored) {
                        /* the phone forgets the key either way */
                    }
                }
            }).start();
        }
        CallRinger.cancel(getContext());
        call.resolve();
    }

    /** Rings this phone after a few seconds, with no server involved, to prove the ring and the lock-screen call screen work. */
    @PluginMethod
    public void testRing(PluginCall call) {
        final Context c = getContext().getApplicationContext();
        Integer after = call.getInt("afterSec", 8);
        long ms = Math.max(0, Math.min(60, after == null ? 8 : after)) * 1000L;
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                CallRinger.ring(c, 0L, "Test call", "This is a test call from Omni-Aura. If you can hear it, calls will reach you.", false);
            }
        }, ms);
        call.resolve();
    }

    @PluginMethod
    public void launchCall(PluginCall call) {
        JSObject r = new JSObject();
        r.put("id", OmniState.launchCallId);
        r.put("answer", OmniState.launchAnswer);
        OmniState.launchCallId = 0L;
        OmniState.launchAnswer = false;
        call.resolve(r);
    }

    /* ---------- a live voice session that survives another app being in front ---------- */
    @PluginMethod
    public void sessionStart(final PluginCall call) {
        Context c = getContext();
        try {
            Intent s = new Intent(c, SessionService.class).putExtra("title", call.getString("title", "Omni-Aura voice session"));
            ContextCompat.startForegroundService(c, s);
        } catch (Throwable t) {
            JSObject r = new JSObject();
            r.put("ok", false);
            r.put("error", String.valueOf(t.getMessage()));
            call.resolve(r);
            return;
        }
        /* the service says whether the phone accepted it a moment later */
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                JSObject r = new JSObject();
                r.put("ok", OmniState.sessionOn);
                call.resolve(r);
            }
        }, 450L);
    }

    @PluginMethod
    public void sessionEnd(PluginCall call) {
        try {
            getContext().startService(new Intent(getContext(), SessionService.class).setAction(SessionService.ACTION_STOP));
        } catch (Throwable ignored) {
            /* already stopped */
        }
        call.resolve();
    }

    /* ---------- sound: while the microphone is open the phone is in "call" mode, which can mean the earpiece or a very low volume ---------- */
    @SuppressWarnings("deprecation")
    @PluginMethod
    public void prepareVoice(PluginCall call) {
        JSObject r = new JSObject();
        try {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            int mode = am.getMode();
            r.put("mode", mode);
            if (mode == AudioManager.MODE_IN_COMMUNICATION || mode == AudioManager.MODE_IN_CALL) {
                if (!am.isSpeakerphoneOn()) {
                    previousSpeaker = false;
                    routedSpeaker = true;
                    am.setSpeakerphoneOn(true);
                }
                int max = am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL);
                int cur = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL);
                if (max > 0 && cur * 100 < max * 50) {
                    am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, Math.max(1, Math.round(max * 0.7f)), 0);
                    r.put("raisedVolume", true);
                }
                r.put("callVolume", am.getStreamVolume(AudioManager.STREAM_VOICE_CALL));
            }
            r.put("speaker", am.isSpeakerphoneOn());
        } catch (Throwable t) {
            r.put("error", String.valueOf(t.getMessage()));
        }
        call.resolve(r);
    }

    @SuppressWarnings("deprecation")
    @PluginMethod
    public void releaseVoice(PluginCall call) {
        try {
            if (routedSpeaker) {
                AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
                am.setSpeakerphoneOn(previousSpeaker);
                routedSpeaker = false;
            }
        } catch (Throwable ignored) {
            /* best effort */
        }
        call.resolve();
    }

    /* ---------- the whole screen, over other apps ---------- */
    @PluginMethod
    public void startScreenShare(PluginCall call) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(call, mpm.createScreenCaptureIntent(), "shareResult");
        } catch (Throwable t) {
            call.reject("Screen sharing could not start: " + t.getMessage());
        }
    }

    @ActivityCallback
    private void shareResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result == null || result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            call.reject("Screen sharing was cancelled.");
            return;
        }
        Context c = getContext();
        try {
            Intent s = new Intent(c, ScreenService.class)
                    .setAction(ScreenService.ACTION_START)
                    .putExtra("code", result.getResultCode())
                    .putExtra("data", result.getData());
            ContextCompat.startForegroundService(c, s);
            JSObject r = new JSObject();
            r.put("started", true);
            r.put("overlay", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c));
            call.resolve(r);
        } catch (Throwable t) {
            call.reject("Screen sharing could not start: " + t.getMessage());
        }
    }

    @PluginMethod
    public void stopScreenShare(PluginCall call) {
        try {
            getContext().startService(new Intent(getContext(), ScreenService.class).setAction(ScreenService.ACTION_STOP));
        } catch (Throwable ignored) {
            /* not running */
        }
        call.resolve();
    }

    /* ---------- the phone's own settings pages ---------- */
    @PluginMethod
    public void openOverlaySettings(PluginCall call) {
        openSettings(call, new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, me()));
    }

    @PluginMethod
    public void requestBatteryExemption(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 23) {
            openSettings(call, new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, me()));
        } else {
            call.resolve();
        }
    }

    @PluginMethod
    public void openFullScreenSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 34) {
            openSettings(call, new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, me()));
        } else {
            openSettings(call, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, me()));
        }
    }

    @PluginMethod
    public void openAppSettings(PluginCall call) {
        openSettings(call, new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, me()));
    }
}
