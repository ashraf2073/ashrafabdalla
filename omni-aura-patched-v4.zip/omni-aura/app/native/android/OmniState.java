package com.ashraf.omniaura;

import android.content.Context;
import android.content.SharedPreferences;

import com.getcapacitor.JSObject;

/** Flags and settings shared by the activity, the plugin and the background services. */
final class OmniState {
    private OmniState() { }

    static volatile boolean foreground = false;
    static volatile boolean sessionOn = false;
    static volatile boolean sharing = false;
    static volatile long launchCallId = 0L;
    static volatile boolean launchAnswer = false;
    static volatile OmniNativePlugin plugin = null;

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("omni_native", Context.MODE_PRIVATE);
    }

    /** Sends an event to the web page, if the page is there to hear it. */
    static void emit(String event, JSObject data) {
        OmniNativePlugin p = plugin;
        if (p != null) p.emit(event, data == null ? new JSObject() : data);
    }
}
