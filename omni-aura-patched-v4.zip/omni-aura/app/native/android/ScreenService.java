package com.ashraf.omniaura;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.getcapacitor.JSObject;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;

/**
 * Shares the whole screen with the voice session, over every app. It takes a picture about once a second and hands it
 * to the page, which passes it to Omni-Aura. A small bubble stays on screen in other apps (when the phone allows it)
 * with a button to stop.
 */
public class ScreenService extends Service {
    static final String ACTION_START = "com.ashraf.omniaura.SHARE_START";
    static final String ACTION_STOP = "com.ashraf.omniaura.SHARE_STOP";
    static final String ACTION_END_SESSION = "com.ashraf.omniaura.SHARE_END_SESSION";

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay display;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private WindowManager windows;
    private View bubble;
    private int cw;
    private int ch;
    private long lastFrame = 0L;
    private boolean done = false;
    private boolean started = false;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            finish("stopped", true);
            return START_NOT_STICKY;
        }
        if (ACTION_END_SESSION.equals(action)) {
            OmniState.emit("endSession", new JSObject());
            finish("ended", true);
            return START_NOT_STICKY;
        }
        if (intent == null || !ACTION_START.equals(action) || started) {
            if (!started) stopSelf();
            return START_NOT_STICKY;
        }
        started = true;
        try {
            promote();
            begin(intent.getIntExtra("code", 0), (Intent) intent.getParcelableExtra("data"));
        } catch (Throwable t) {
            JSObject d = new JSObject();
            d.put("reason", "error");
            d.put("message", String.valueOf(t.getMessage()));
            finish("error", false);
            OmniState.emit("screenEnded", d);
        }
        return START_NOT_STICKY;
    }

    private void promote() {
        CallRinger.channels(this);
        PendingIntent open = PendingIntent.getActivity(this, 21, CallRinger.openApp(this), CallRinger.flags());
        PendingIntent stop = PendingIntent.getService(this, 22, new Intent(this, ScreenService.class).setAction(ACTION_STOP), CallRinger.flags());
        PendingIntent end = PendingIntent.getService(this, 23, new Intent(this, ScreenService.class).setAction(ACTION_END_SESSION), CallRinger.flags());
        Notification n = new NotificationCompat.Builder(this, CallRinger.CH_SESSION)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("Omni-Aura can see your screen")
                .setContentText("Sharing in your voice session. Use any app; stop here when you like.")
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_media_pause, "Stop sharing", stop)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "End session", end)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(CallRinger.SHARE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(CallRinger.SHARE_ID, n);
        }
    }

    @SuppressWarnings("deprecation")
    private void begin(int code, Intent data) {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) throw new IllegalStateException("The phone did not give permission to share the screen.");
        thread = new HandlerThread("omni-screen");
        thread.start();
        handler = new Handler(thread.getLooper());
        projectionCallback = new MediaProjection.Callback() {
            @Override
            public void onStop() {
                /* the system ended the projection (for example from its own "stop sharing" control) */
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        finish("system", true);
                    }
                });
            }
        };
        projection.registerCallback(projectionCallback, handler);

        windows = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        try {
            windows.getDefaultDisplay().getRealMetrics(dm);
        } catch (Throwable t) {
            dm = getResources().getDisplayMetrics();
        }
        float scale = Math.min(1f, 960f / Math.max(dm.widthPixels, dm.heightPixels));
        cw = Math.max(2, Math.round(dm.widthPixels * scale / 2f) * 2);
        ch = Math.max(2, Math.round(dm.heightPixels * scale / 2f) * 2);
        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader r) {
                onImage(r);
            }
        }, handler);
        display = projection.createVirtualDisplay("omni-share", cw, ch, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
        OmniState.sharing = true;
        showBubble();
    }

    /** One picture at most once a second, as a small JPEG, handed to the page. */
    private void onImage(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long now = SystemClock.elapsedRealtime();
            if (now - lastFrame < 1000L) return;
            lastFrame = now;
            Image.Plane plane = img.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int pixel = plane.getPixelStride();
            int row = plane.getRowStride();
            int pad = row - pixel * cw;
            Bitmap wide = Bitmap.createBitmap(cw + pad / pixel, ch, Bitmap.Config.ARGB_8888);
            wide.copyPixelsFromBuffer(buf);
            Bitmap shot = pad == 0 ? wide : Bitmap.createBitmap(wide, 0, 0, cw, ch);
            ByteArrayOutputStream bos = new ByteArrayOutputStream(64 * 1024);
            shot.compress(Bitmap.CompressFormat.JPEG, 55, bos);
            if (shot != wide) shot.recycle();
            wide.recycle();
            JSObject d = new JSObject();
            d.put("data", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP));
            OmniState.emit("screenFrame", d);
        } catch (Throwable t) {
            /* skip this picture */
        } finally {
            if (img != null) img.close();
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** A small bubble over other apps: a red dot, what it means, and a stop button. Needs "Display over other apps". */
    private void showBubble() {
        try {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) return;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.HORIZONTAL);
            box.setGravity(Gravity.CENTER_VERTICAL);
            box.setPadding(dp(12), dp(7), dp(8), dp(7));
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xEE0C1626);
            bg.setCornerRadius(dp(26));
            bg.setStroke(dp(1), 0xFF76F2C4);
            box.setBackground(bg);

            View dot = new View(this);
            GradientDrawable dg = new GradientDrawable();
            dg.setShape(GradientDrawable.OVAL);
            dg.setColor(0xFFFF4D5E);
            dot.setBackground(dg);
            box.addView(dot, new LinearLayout.LayoutParams(dp(10), dp(10)));

            TextView label = new TextView(this);
            label.setText("Omni-Aura sees your screen");
            label.setTextColor(0xFFEAF1FF);
            label.setTextSize(12f);
            label.setPadding(dp(8), 0, dp(10), 0);
            box.addView(label);

            TextView stop = new TextView(this);
            stop.setText("STOP");
            stop.setTextColor(0xFF000000);
            stop.setTextSize(12f);
            stop.setTypeface(Typeface.DEFAULT_BOLD);
            stop.setPadding(dp(12), dp(5), dp(12), dp(5));
            GradientDrawable sb = new GradientDrawable();
            sb.setColor(0xFF76F2C4);
            sb.setCornerRadius(dp(16));
            stop.setBackground(sb);
            stop.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish("stopped", true);
                }
            });
            box.addView(stop);

            final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = dp(36);

            /* drag the bubble by its label; a plain tap on it brings the app back */
            final float[] last = new float[3];
            label.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            last[0] = e.getRawX();
                            last[1] = e.getRawY();
                            last[2] = 0f;
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            lp.x += Math.round(e.getRawX() - last[0]);
                            lp.y += Math.round(e.getRawY() - last[1]);
                            last[2] += Math.abs(e.getRawX() - last[0]) + Math.abs(e.getRawY() - last[1]);
                            last[0] = e.getRawX();
                            last[1] = e.getRawY();
                            try {
                                windows.updateViewLayout(bubble, lp);
                            } catch (Throwable ignored) {
                                /* gone already */
                            }
                            return true;
                        case MotionEvent.ACTION_UP:
                            if (last[2] < dp(8)) {
                                try {
                                    startActivity(CallRinger.openApp(ScreenService.this));
                                } catch (Throwable ignored) {
                                    /* best effort */
                                }
                            }
                            return true;
                        default:
                            return false;
                    }
                }
            });
            windows.addView(box, lp);
            bubble = box;
        } catch (Throwable t) {
            bubble = null;
        }
    }

    private void finish(String reason, boolean tell) {
        if (done) return;
        done = true;
        OmniState.sharing = false;
        try {
            if (bubble != null && windows != null) windows.removeView(bubble);
        } catch (Throwable ignored) {
            /* best effort */
        }
        bubble = null;
        try {
            if (display != null) display.release();
        } catch (Throwable ignored) {
            /* best effort */
        }
        try {
            if (reader != null) {
                reader.setOnImageAvailableListener(null, null);
                reader.close();
            }
        } catch (Throwable ignored) {
            /* best effort */
        }
        try {
            if (projection != null) {
                if (projectionCallback != null) projection.unregisterCallback(projectionCallback);
                projection.stop();
            }
        } catch (Throwable ignored) {
            /* best effort */
        }
        try {
            if (thread != null) thread.quitSafely();
        } catch (Throwable ignored) {
            /* best effort */
        }
        if (tell) {
            JSObject d = new JSObject();
            d.put("reason", reason);
            OmniState.emit("screenEnded", d);
        }
        try {
            stopForeground(true);
        } catch (Throwable ignored) {
            /* best effort */
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        finish("destroyed", false);
        super.onDestroy();
    }
}
