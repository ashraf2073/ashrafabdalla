package com.ashraf.omniaura;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

import com.getcapacitor.JSObject;

/** Keeps a live voice session (microphone, connection, page) running while another app is in front. */
public class SessionService extends Service {
    static final String ACTION_STOP = "com.ashraf.omniaura.SESSION_STOP";
    static final String ACTION_END = "com.ashraf.omniaura.SESSION_END";

    private PowerManager.WakeLock wl;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            finish();
            return START_NOT_STICKY;
        }
        if (ACTION_END.equals(action)) {
            OmniState.emit("endSession", new JSObject());
            finish();
            return START_NOT_STICKY;
        }
        try {
            CallRinger.channels(this);
            String title = intent == null ? null : intent.getStringExtra("title");
            PendingIntent open = PendingIntent.getActivity(this, 11, CallRinger.openApp(this), CallRinger.flags());
            PendingIntent end = PendingIntent.getService(this, 12, new Intent(this, SessionService.class).setAction(ACTION_END), CallRinger.flags());
            Notification n = new NotificationCompat.Builder(this, CallRinger.CH_SESSION)
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle(title == null || title.length() == 0 ? "Omni-Aura voice session" : title)
                    .setContentText("Running while you use other apps. Tap to come back.")
                    .setOngoing(true)
                    .setShowWhen(false)
                    .setContentIntent(open)
                    .addAction(android.R.drawable.ic_menu_close_clear_cancel, "End session", end)
                    .build();
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(CallRinger.SESSION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(CallRinger.SESSION_ID, n);
            }
            OmniState.sessionOn = true;
            if (wl == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "omni:session");
                    wl.acquire(2L * 60L * 60L * 1000L);
                }
            }
        } catch (Throwable t) {
            OmniState.sessionOn = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_NOT_STICKY;
    }

    private void finish() {
        OmniState.sessionOn = false;
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
            /* best effort */
        }
        wl = null;
        try {
            stopForeground(true);
        } catch (Throwable ignored) {
            /* best effort */
        }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        OmniState.sessionOn = false;
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Throwable ignored) {
            /* best effort */
        }
        super.onDestroy();
    }
}
