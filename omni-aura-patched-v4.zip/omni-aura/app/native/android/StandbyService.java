package com.ashraf.omniaura;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;

/**
 * Keeps Omni-Aura able to ring when the app is closed. It asks the server every few seconds whether a call is waiting
 * (with the device key the app saved), and rings the phone like a call. No Google services are involved.
 */
public class StandbyService extends Service {
    static final String ACTION_DECLINE = "com.ashraf.omniaura.DECLINE";
    static volatile boolean running = false;

    /** The server did not accept this phone's key. */
    static final class AuthException extends Exception {
        AuthException() { super("The server does not know this phone any more."); }
    }

    private Thread loop;
    private volatile boolean stopFlag = false;
    private final HashSet<Long> rung = new HashSet<>();
    private long ringingId = 0L;
    private long ringAt = 0L;
    private String ringSay = "";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!promote()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        if (intent != null && ACTION_DECLINE.equals(intent.getAction())) {
            CallRinger.cancel(this);
            post("decline", intent.getLongExtra("omni_call_id", 0L));
        }
        if (loop == null || !loop.isAlive()) {
            stopFlag = false;
            loop = new Thread(new Runnable() {
                @Override
                public void run() {
                    poll();
                }
            }, "omni-standby");
            loop.setDaemon(true);
            loop.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopFlag = true;
        running = false;
        if (loop != null) loop.interrupt();
        super.onDestroy();
    }

    private boolean promote() {
        try {
            CallRinger.channels(this);
            PendingIntent pi = PendingIntent.getActivity(this, 7, CallRinger.openApp(this), CallRinger.flags());
            Notification n = new NotificationCompat.Builder(this, CallRinger.CH_STANDBY)
                    .setSmallIcon(android.R.drawable.stat_notify_chat)
                    .setContentTitle("Omni-Aura is ready for calls")
                    .setContentText("Listening for check-ins and decisions. Tap to open.")
                    .setOngoing(true)
                    .setShowWhen(false)
                    .setPriority(NotificationCompat.PRIORITY_MIN)
                    .setContentIntent(pi)
                    .build();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(CallRinger.STANDBY_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(CallRinger.STANDBY_ID, n);
            }
            return true;
        } catch (Throwable t) {
            OmniState.prefs(this).edit().putString("last_err", "The phone refused the background service: " + t.getMessage()).apply();
            return false;
        }
    }

    private void poll() {
        int fails = 0;
        while (!stopFlag) {
            SharedPreferences p = OmniState.prefs(this);
            String api = p.getString("api", "");
            String key = p.getString("key", "");
            int every = Math.max(8, Math.min(120, p.getInt("every", 15)));
            if (!p.getBoolean("standby_on", false) || api == null || api.length() == 0 || key == null || key.length() == 0) break;
            long waitMs = every * 1000L;
            PowerManager.WakeLock wl = null;
            try {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "omni:standby");
                    wl.acquire(30000L);
                }
                handle(http("GET", api + "/api/device/pending", key));
                fails = 0;
                p.edit().putLong("last_ok", System.currentTimeMillis()).putString("last_err", "").apply();
            } catch (AuthException e) {
                p.edit().putBoolean("standby_on", false).putString("last_err", "The server no longer knows this phone. Open the app and turn calls on again.").apply();
                break;
            } catch (Throwable e) {
                fails++;
                p.edit().putString("last_err", String.valueOf(e.getMessage())).apply();
                waitMs = Math.min(60000L, every * 1000L * Math.min(4, fails));
            } finally {
                try {
                    if (wl != null && wl.isHeld()) wl.release();
                } catch (Throwable ignored) {
                    /* best effort */
                }
            }
            try {
                Thread.sleep(waitMs);
            } catch (InterruptedException e) {
                break;
            }
        }
        running = false;
        if (!stopFlag) stopSelf();
    }

    private void handle(String body) throws Exception {
        JSONObject o = new JSONObject(body);
        JSONArray arr = o.optJSONArray("calls");
        HashSet<Long> now = new HashSet<>();
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject c = arr.getJSONObject(i);
                long id = c.getLong("id");
                long age = c.optLong("age", 0L);
                now.add(id);
                if (rung.contains(id)) continue;
                rung.add(id);
                /* the open app rings by itself */
                if (OmniState.foreground) continue;
                String say = c.optString("say", "");
                if (age < 120000L) {
                    CallRinger.ring(this, id, c.optString("title", ""), say, c.optBoolean("urgent", false));
                    ringingId = id;
                    ringAt = System.currentTimeMillis();
                    ringSay = say;
                } else {
                    CallRinger.missed(this, id, say);
                    post("missed", id);
                }
            }
        }
        if (ringingId != 0L) {
            if (!now.contains(ringingId)) {
                /* answered in the app, declined, or timed out somewhere else */
                CallRinger.cancel(this);
                ringingId = 0L;
            } else if (System.currentTimeMillis() - ringAt > 50000L) {
                CallRinger.cancel(this);
                CallRinger.missed(this, ringingId, ringSay);
                post("missed", ringingId);
                ringingId = 0L;
            }
        }
        if (rung.size() > 200) rung.clear();
    }

    private void post(final String action, final long id) {
        if (id == 0L) return;
        SharedPreferences p = OmniState.prefs(this);
        final String api = p.getString("api", "");
        final String key = p.getString("key", "");
        if (api == null || api.length() == 0 || key == null || key.length() == 0) return;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    http("POST", api + "/api/device/calls/" + id + "/" + action, key);
                } catch (Throwable ignored) {
                    /* the next poll shows where things stand */
                }
            }
        }, "omni-standby-post").start();
    }

    static String http(String method, String url, String key) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod(method);
            c.setConnectTimeout(12000);
            c.setReadTimeout(25000);
            c.setRequestProperty("x-device-key", key);
            c.setRequestProperty("accept", "application/json");
            if ("POST".equals(method)) {
                c.setDoOutput(true);
                c.setRequestProperty("content-type", "application/json");
                c.getOutputStream().write("{}".getBytes("UTF-8"));
            }
            int code = c.getResponseCode();
            if (code == 401 || code == 403) throw new AuthException();
            if (code >= 400) throw new Exception("The server answered " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }
}
