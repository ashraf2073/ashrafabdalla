// Adds the Omni-Aura phone parts (background calls, screen sharing over other apps, a voice session that survives other apps)
// to the Android project that `npx cap add android` created. Run from the app/ folder:
//     node native/patch-android.mjs            add them
//     node native/patch-android.mjs --revert   take them out again (the workflow does this if they fail to compile)
// If anything goes wrong while adding, it takes everything back out and the APK is built without them.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const src = path.join(here, 'android');
const root = path.join(process.cwd(), 'android');
const manifest = path.join(root, 'app/src/main/AndroidManifest.xml');
const NEW = ['OmniState', 'CallRinger', 'StandbyService', 'SessionService', 'ScreenService', 'BootReceiver', 'OmniNativePlugin'];
const ALL = [...NEW, 'MainActivity'];
const BAK = '.omni-bak';

function findMain() {
  const base = path.join(root, 'app/src/main/java');
  const walk = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { const r = walk(p); if (r) return r; } else if (e.name === 'MainActivity.java') return p;
    }
    return null;
  };
  return fs.existsSync(base) ? walk(base) : null;
}

function revert() {
  const main = findMain();
  const dir = main ? path.dirname(main) : null;
  if (dir) for (const n of NEW) fs.rmSync(path.join(dir, n + '.java'), { force: true });
  for (const f of [manifest, main]) {
    if (f && fs.existsSync(f + BAK)) { fs.copyFileSync(f + BAK, f); fs.rmSync(f + BAK, { force: true }); }
  }
  console.log('Omni-Aura phone parts removed.');
}

function apply() {
  const main = findMain();
  if (!main) throw new Error('MainActivity.java was not found in the Android project.');
  if (!/package\s+com\.ashraf\.omniaura\s*;/.test(fs.readFileSync(main, 'utf8')) && !fs.existsSync(main + BAK)) throw new Error('MainActivity.java is not in the package com.ashraf.omniaura.');
  const dir = path.dirname(main);
  for (const f of [manifest, main]) if (!fs.existsSync(f + BAK)) fs.copyFileSync(f, f + BAK);
  for (const n of ALL) fs.copyFileSync(path.join(src, n + '.java'), path.join(dir, n + '.java'));

  let m = fs.readFileSync(manifest, 'utf8');
  const perms = ['POST_NOTIFICATIONS', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_SPECIAL_USE', 'FOREGROUND_SERVICE_MICROPHONE', 'FOREGROUND_SERVICE_MEDIA_PROJECTION',
    'USE_FULL_SCREEN_INTENT', 'WAKE_LOCK', 'SYSTEM_ALERT_WINDOW', 'RECEIVE_BOOT_COMPLETED', 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS', 'VIBRATE'];
  const missing = perms.filter((p) => !m.includes(`android.permission.${p}"`));
  if (missing.length) {
    if (!m.includes('<application')) throw new Error('AndroidManifest.xml has no <application> tag.');
    m = m.replace('<application', missing.map((p) => `<uses-permission android:name="android.permission.${p}"/>`).join('') + '<application');
  }
  if (!m.includes('.StandbyService')) {
    if (!m.includes('</application>')) throw new Error('AndroidManifest.xml has no </application> tag.');
    const parts = `
        <service android:name=".StandbyService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="Listens for scheduled assistant calls and rings the phone like an incoming call"/>
        </service>
        <service android:name=".SessionService" android:exported="false" android:foregroundServiceType="microphone"/>
        <service android:name=".ScreenService" android:exported="false" android:foregroundServiceType="mediaProjection"/>
        <receiver android:name=".BootReceiver" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
            </intent-filter>
        </receiver>
    `;
    m = m.replace('</application>', parts + '</application>');
  }
  fs.writeFileSync(manifest, m);
  console.log('Omni-Aura phone parts added: ' + ALL.length + ' files, ' + missing.length + ' permissions, 3 services, 1 receiver.');
}

if (process.argv.includes('--revert')) {
  revert();
} else {
  try { apply(); } catch (e) {
    console.log(`::warning::The Omni-Aura phone parts could not be added (${e.message}). The APK will be built without them.`);
    try { revert(); } catch { /* nothing more to undo */ }
  }
}
