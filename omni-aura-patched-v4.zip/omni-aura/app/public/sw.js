/* Omni-Aura service worker. It receives direct calls and alerts (Web Push) and opens the app when one is tapped.
   It does no caching, so it can never serve an old version of the app. */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

self.addEventListener('push', (event) => {
  let d = {};
  try { d = event.data ? event.data.json() : {}; } catch { d = { title: 'Omni-Aura', body: event.data ? event.data.text() : '' }; }
  event.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const call = d.id != null && !d.plain;
    /* The app is open and in front: it shows the call itself, so no notification is needed. */
    const front = wins.find((w) => w.visibilityState === 'visible' && w.focused);
    if (front && call) { front.postMessage({ type: 'omni-call', id: d.id }); return; }
    await self.registration.showNotification(d.title || 'Omni-Aura', {
      body: d.body || '',
      icon: '/icon-192.png', badge: '/icon-192.png',
      tag: call ? 'omni-call-' + d.id : 'omni-' + Date.now(),
      renotify: true,
      requireInteraction: call,
      vibrate: call ? [450, 180, 450, 180, 450, 180, 450] : [120],
      actions: call ? [{ action: 'answer', title: 'Answer' }, { action: 'decline', title: 'Decline' }] : [],
      data: d,
    });
  })());
});

self.addEventListener('notificationclick', (event) => {
  const d = event.notification.data || {};
  event.notification.close();
  const call = d.id != null && !d.plain;
  /* Decline cannot sign in, so it uses a signed link that came with the call. */
  if (event.action === 'decline' && d.decline) { event.waitUntil(fetch(d.decline, { method: 'POST' }).catch(() => {})); return; }
  const answer = event.action === 'answer';
  event.waitUntil((async () => {
    const wins = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    if (wins.length) {
      const w = wins[0];
      try { await w.focus(); } catch { /* ignore */ }
      if (call) w.postMessage({ type: 'omni-call', id: d.id, answer });
      return;
    }
    await self.clients.openWindow(call ? `/?call=${d.id}${answer ? '&answer=1' : ''}` : '/');
  })());
});
