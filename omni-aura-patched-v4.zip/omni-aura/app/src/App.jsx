import { useCallback, useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { API, CONFIG_PROBLEM, api, applyUi, arr, sb } from './lib.js';
import { bioStatus, disableFingerprint, enableFingerprint, fpLockOn, fpOn, guard } from './bio.js';
import { MAX_ALL, MAX_FILES, kb, readAttachment, saveDataUrl, saveFile } from './files.js';
import { buildInfo } from './diag.js';
import { sayAloud } from './speak.js';
import Voice from './Voice.jsx';
import ChatBar from './Chats.jsx';
import Train from './Train.jsx';
import PhoneParts, { autoStandby, pauseStandby } from './Phone.jsx';
import { isNative } from './native.js';
import { CallLayer, disablePush, enablePush, pushState, syncPush, useCalls } from './Call.jsx';
import { Lock, NiceTry } from './Lock.jsx';
import { Boundary, Busy, Icon, InfinityLoader, Loading } from './ui.jsx';
import { buzz, flushSos, lastSos, silentSos, warmLocation } from './sos.js';
import about from './about.md?raw';

const NAV = [['Chat', 'chat'], ['Today', 'today'], ['Voice', 'mic'], ['Train', 'train'], ['Inbox', 'inbox'], ['Bills', 'bills'], ['Shop', 'shop'], ['Write', 'write'], ['Assets', 'assets'], ['Safety', 'safety'], ['Settings', 'settings'], ['About', 'about']];

async function notify(title, body) {
  try {
    if (Capacitor.isNativePlatform()) {
      await LocalNotifications.requestPermissions();
      await LocalNotifications.schedule({ notifications: [{ id: Date.now() % 2147483647, title, body: body || '' }] });
    } else if (window.Notification && Notification.permission === 'granted') new Notification(title, { body });
  } catch {}
}

let chReady = false;
async function liveStatus(min) {
  if (!Capacitor.isNativePlatform() || localStorage.isl === '0') return;
  try {
    if (min <= 0) { await LocalNotifications.cancel({ notifications: [{ id: 7001 }] }); return; }
    if (!chReady) { await LocalNotifications.requestPermissions(); await LocalNotifications.createChannel({ id: 'live', name: 'Live status', description: 'Focus mode countdown', importance: 2, visibility: 1 }); chReady = true; }
    await LocalNotifications.schedule({ notifications: [{ id: 7001, title: 'Focus mode', body: `${min} min left. Only urgent alerts get through.`, ongoing: true, autoCancel: false, channelId: 'live' }] });
  } catch {}
}

function Login({ fresh, onIntruder }) {
  const [e, setE] = useState(''), [p, setP] = useState(''), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const go = async (ev) => {
    ev.preventDefault();
    if (busy) return;
    setBusy(true); setErr('');
    fresh.current = true; /* a password sign-in already proves who you are, so the app lock is skipped this once */
    const { error } = await sb.auth.signInWithPassword({ email: e, password: p });
    if (!error) { setBusy(false); return; }
    fresh.current = false;
    if (/invalid login credentials/i.test(error.message) || error.code === 'invalid_credentials') {
      /* a wrong password for the owner is normal; an account that is not his is not */
      try {
        const r = await fetch(API + '/api/security/attempt', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: e }) });
        const j = await r.json().catch(() => ({}));
        if (j.known === false) { setBusy(false); onIntruder(e.trim()); return; }
        setErr(j.known ? 'That password did not work. Try again.' : 'Could not sign in. Check your details and try again.');
      } catch { setErr('Could not reach the server to check that. Try again in a moment.'); }
    } else setErr(error.message);
    setBusy(false);
  };
  return (
    <div className="login">
      <form onSubmit={go}>
        <h1 className="brandline"><img src="/logo.svg" alt="" width="44" height="44" />Omni-Aura</h1>
        <input type="email" autoComplete="username" placeholder="Email" value={e} onChange={(x) => setE(x.target.value)} />
        <input type="password" autoComplete="current-password" placeholder="Password" value={p} onChange={(x) => setP(x.target.value)} />
        <button className="primary" type="submit" disabled={busy}>{busy ? <Busy label="Signing in" /> : 'Sign in'}</button>
        {err && <p className="err" role="alert">{err}</p>}
      </form>
    </div>
  );
}

function Code({ lang, code }) {
  const [run, setRun] = useState(false), [ok, setOk] = useState(false);
  const web = /^(html?|svg)$/i.test(lang) || /^\s*(<!doctype html|<html)/i.test(code);
  const copy = () => { if (navigator.clipboard) navigator.clipboard.writeText(code).then(() => { setOk(true); setTimeout(() => setOk(false), 1200); }).catch(() => {}); };
  return (
    <div className="code">
      <div className="code-bar">
        <span>{lang || 'code'}</span>
        <span>
          {web && <button className="tiny-btn" onClick={() => setRun((x) => !x)}>{run ? 'Code' : 'Run'}</button>}
          <button className="tiny-btn" onClick={copy}>{ok ? 'Copied' : 'Copy'}</button>
        </span>
      </div>
      {run ? <iframe className="code-run" title="Preview" sandbox="allow-scripts" srcDoc={code} /> : <pre>{code}</pre>}
    </div>
  );
}

function Md({ text }) {
  const link = (x, k) => x.split(/(https?:\/\/[^\s)]+)/g).map((y, j) => (j % 2 ? <a key={k + '-' + j} href={y} target="_blank" rel="noreferrer">{y}</a> : y));
  const bold = (s) => s.split(/\*\*(.+?)\*\*/g).map((x, k) => (k % 2 ? <b key={k}>{x}</b> : link(x, k)));
  return String(text).split('```').map((seg, i) => (i % 2
    ? <Code key={i} lang={(seg.match(/^(\w*)\n/) || [, ''])[1]} code={seg.replace(/^\w*\n/, '').replace(/\n$/, '')} />
    : seg.split('\n').map((ln, j) => {
      if (!ln.trim()) return null;
      if (/^\s*[-*] /.test(ln)) return <p key={i + '-' + j} className="li">{bold(ln.replace(/^\s*[-*] /, ''))}</p>;
      if (/^#{1,3} /.test(ln)) return <p key={i + '-' + j}><b>{bold(ln.replace(/^#{1,3} /, ''))}</b></p>;
      return <p key={i + '-' + j}>{bold(ln)}</p>;
    })));
}

/* The check-in is answered by voice first. Typing is the fallback. */
function CheckinCard({ ck, voice, onDone }) {
  const [typing, setTyping] = useState(false), [reply, setReply] = useState(''), [busy, setBusy] = useState(false), [err, setErr] = useState('');
  const send = async () => {
    if (!reply.trim() || busy) return;
    setBusy(true); setErr('');
    try { const r = await api(`/api/checkin/${ck.id}/reply`, 'POST', { reply }); onDone(r.verdict || ''); setReply(''); } catch (e) { setErr(e.message); }
    setBusy(false);
  };
  return (
    <section className="checkin" aria-label="Check-in">
      <h2>Check-in</h2>
      <p>{ck.prompt}</p>
      <button className="primary big" onClick={() => voice.current && voice.current.start({ mode: 'checkin', checkin: ck })}><Icon n="mic" size={20} /> Answer by voice</button>
      {!typing && <button className="link" onClick={() => setTyping(true)}>Type instead</button>}
      {typing && (
        <>
          <input placeholder="What are you doing right now?" value={reply} onChange={(e) => setReply(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') send(); }} />
          <button className="ghost" disabled={busy} onClick={send}>{busy ? <Busy label="Sending" /> : 'Send update'}</button>
        </>
      )}
      {err && <p className="err">{err}</p>}
    </section>
  );
}
const Verdict = ({ text, onClose }) => <section className="verdict"><h2>Verdict</h2><p>{text}</p><button className="link" onClick={onClose}>Dismiss</button></section>;

function Today({ tick, voice, verdict, setVerdict, bump }) {
  const [tasks, setTasks] = useState([]), [events, setEvents] = useState([]), [ck, setCk] = useState(null);
  const [plan, setPlan] = useState(''), [planning, setPlanning] = useState(false), [err, setErr] = useState('');
  const [t, setT] = useState({ title: '', due: '' }), [ev, setEv] = useState({ title: '', start: '', end: '' });
  const iso = (v) => (v ? new Date(v).toISOString() : null);
  const load = useCallback(async () => {
    try {
      const [a, b, c] = await Promise.all([api('/api/tasks'), api('/api/events'), api('/api/checkin/latest')]);
      setTasks(arr(a)); setEvents(arr(b)); setCk(c && c.id ? c : null); setErr('');
    } catch (e) { setErr(e.message); }
  }, []);
  useEffect(() => { load(); }, [load, tick]);
  const guard = async (f) => { try { await f(); setErr(''); } catch (e) { setErr(e.message); } load(); };
  return (
    <>
      {err && <p className="err">{err}</p>}
      {ck && <CheckinCard ck={ck} voice={voice} onDone={(v) => { setVerdict(v); setCk(null); bump(); }} />}
      {verdict && !ck && <Verdict text={verdict} onClose={() => setVerdict('')} />}
      <section>
        <h2>Tasks</h2>
        {tasks.filter((x) => x.status === 'open').map((x) => (
          <label key={x.id} className="row">
            <input type="checkbox" onChange={() => guard(() => api('/api/tasks/' + x.id, 'PUT', { status: 'done' }))} />
            {x.title}{x.due && <small className="mute"> {new Date(x.due).toLocaleString()}</small>}
          </label>
        ))}
        <input placeholder="New task" value={t.title} onChange={(e) => setT({ ...t, title: e.target.value })} />
        <input type="datetime-local" value={t.due} onChange={(e) => setT({ ...t, due: e.target.value })} />
        <button onClick={() => { if (!t.title) return; guard(async () => { await api('/api/tasks', 'POST', { title: t.title, due: iso(t.due) }); setT({ title: '', due: '' }); }); }}>Add task</button>
      </section>
      <section>
        <h2>Calendar</h2>
        {events.map((x) => (
          <p key={x.id} className="row">{x.title}<small className="mute">{new Date(x.start_at).toLocaleString()}</small>
            <button className="sm" onClick={() => guard(() => api('/api/events/' + x.id, 'DELETE'))}>Delete</button></p>
        ))}
        <input placeholder="New event" value={ev.title} onChange={(e) => setEv({ ...ev, title: e.target.value })} />
        <input type="datetime-local" value={ev.start} onChange={(e) => setEv({ ...ev, start: e.target.value })} />
        <input type="datetime-local" value={ev.end} onChange={(e) => setEv({ ...ev, end: e.target.value })} />
        <button onClick={() => { if (!ev.title || !ev.start) return; guard(async () => { await api('/api/events', 'POST', { title: ev.title, start_at: iso(ev.start), end_at: iso(ev.end) }); setEv({ title: '', start: '', end: '' }); }); }}>Add event</button>
      </section>
      <section>
        <h2>Plan</h2>
        <button disabled={planning} onClick={async () => { setPlanning(true); try { setPlan((await api('/api/agenda', 'POST')).plan); } catch (e) { setPlan(e.message); } setPlanning(false); }}>{planning ? <Busy label="Planning" /> : 'Plan my day'}</button>
        <p className="pre">{plan}</p>
      </section>
    </>
  );
}

function Proposal({ a, accts = [], onApprove, onDiscard }) {
  const p = a.payload || {}, [to, setTo] = useState(p.to || ''), [subject, setSubject] = useState(p.subject || ''), [body, setBody] = useState(p.body || ''), [account, setAccount] = useState(''), [busy, setBusy] = useState(false);
  const cancel = a.kind === 'cancel_event';
  const once = async (f) => { if (busy) return; setBusy(true); try { await f(); } finally { setBusy(false); } };
  return (
    <section>
      <h2>{cancel ? 'Cancel meeting' : a.kind === 'cancel_request' ? 'Cancel order or membership' : 'Email'}</h2>
      <p>{a.summary}</p>
      {!cancel && (<>
        {accts.length > 1 && <select value={account} onChange={(e) => setAccount(e.target.value)}><option value="">Send from the first account</option>{accts.map((x) => <option key={x.name} value={x.name}>{x.name} {x.email}</option>)}</select>}
        <input placeholder="To" value={to} onChange={(e) => setTo(e.target.value)} />
        <input placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <textarea rows={6} value={body} onChange={(e) => setBody(e.target.value)} />
      </>)}
      <button disabled={busy} onClick={() => once(() => onApprove(cancel ? {} : { to, subject, body, account }))}>{busy ? <Busy label="Working" /> : cancel ? 'Approve cancellation' : 'Approve and send'}</button>
      <button className="ghost" disabled={busy} onClick={() => once(onDiscard)}>Discard</button>
    </section>
  );
}

/* Unsent reply edits survive leaving the Inbox and coming back, until they are sent. */
let DRAFTS = {};

function Inbox({ tick }) {
  const [out, setOut] = useState([]), [inb, setInb] = useState([]), [acts, setActs] = useState([]), [msg, setMsg] = useState('');
  const [pin, setPin] = useState(''), [stamp, setStamp] = useState(true), [ask, setAsk] = useState(''), [busy, setBusy] = useState(false), [accts, setAccts] = useState([]);
  /* Edited reply text lives here, by reply id, so a refresh from a new message cannot replace it with the old draft. */
  const [edits, setEditsRaw] = useState(() => ({ ...DRAFTS })), [sending, setSending] = useState({});
  const setEdits = (f) => setEditsRaw((m) => { const n = typeof f === 'function' ? f(m) : f; DRAFTS = n; return n; });
  useEffect(() => { api('/api/accounts').then((a) => setAccts(arr(a).filter((x) => !x.error))).catch(() => {}); }, []);
  const load = useCallback(async () => {
    try { setOut(arr(await api('/api/outbox'))); setInb(arr(await api('/api/inbox'))); setActs(arr(await api('/api/actions')).filter((a) => a.status === 'proposed')); } catch (e) { setMsg(e.message); }
  }, []);
  useEffect(() => { load(); }, [load, tick]);
  const act = async (url, body) => {
    if (url.endsWith('/approve')) { const why = await guard('Approve this action'); if (why) { setMsg(why); return; } }
    try { const r = await api(url, 'POST', body || {}); setMsg(r.result || ''); } catch (e) { setMsg(e.message); }
    load();
  };
  const sendReply = async (o) => {
    if (sending[o.id]) return;
    { const why = await guard('Send this reply'); if (why) { setMsg(why); return; } }
    setSending((m) => ({ ...m, [o.id]: true })); setMsg('');
    try {
      const r = await api(`/api/outbox/${o.id}/approve`, 'POST', { body: edits[o.id] ?? o.body, stamp, pin });
      setMsg(r.sent ? 'Sent.' : r.result || r.error || 'Not sent.');
      if (r.sent) setEdits((m) => { const n = { ...m }; delete n[o.id]; return n; });
    } catch (e) { setMsg(e.message); }
    setSending((m) => ({ ...m, [o.id]: false }));
    load();
  };
  const propose = async () => {
    if (!ask.trim()) return;
    setBusy(true); setMsg('');
    try { const r = await api('/api/actions/propose', 'POST', { request: ask }); if (r.note) setMsg(r.note); else setAsk(''); } catch (e) { setMsg(e.message); }
    setBusy(false); load();
  };
  return (
    <>
      <section>
        <h2>Ask for an action</h2>
        <textarea rows={3} value={ask} onChange={(e) => setAsk(e.target.value)} placeholder="Cancel my gym membership, email support@gym.com. Or: cancel tomorrow's design review. Or: email Sam about Friday." />
        <button disabled={busy} onClick={propose}>{busy ? <Busy label="Drafting" /> : 'Draft it'}</button>
        <input type="password" inputMode="numeric" placeholder="Approval PIN" value={pin} onChange={(e) => setPin(e.target.value)} />
        <label className="row"><input type="checkbox" checked={stamp} onChange={(e) => setStamp(e.target.checked)} />Add my stamp to emails I approve</label>
        {msg && <p className={/^(sent|meeting cancelled|email sent)/i.test(msg) ? 'mute' : 'err'} role="status">{msg}</p>}
      </section>
      {acts.map((a) => <Proposal key={a.id} a={a} accts={accts} onApprove={(edits2) => act(`/api/actions/${a.id}/approve`, { pin, stamp, edits: edits2 })} onDiscard={() => act(`/api/actions/${a.id}/discard`)} />)}
      <section>
        <h2>Replies waiting</h2>
        {!out.length && <p className="mute">No replies waiting.</p>}
        {out.map((o) => (
          <div key={o.id}>
            <p className="mute">{o.channel}{o.account ? ` (${o.account})` : ''} to {o.to_addr}</p>
            <textarea rows={3} value={edits[o.id] ?? o.body ?? ''} onChange={(e) => setEdits((m) => ({ ...m, [o.id]: e.target.value }))} />
            <button disabled={!!sending[o.id]} onClick={() => sendReply(o)}>{sending[o.id] ? <Busy label="Sending" /> : 'Send reply'}</button>
            <button className="ghost" disabled={!!sending[o.id]} onClick={() => act(`/api/outbox/${o.id}/discard`)}>Discard</button>
          </div>
        ))}
      </section>
      <section>
        <h2>Recent messages</h2>
        {inb.map((m) => <p key={m.id}><b>{m.channel}{m.account ? ` (${m.account})` : ''}</b> {m.sender}<br /><span className="mute">{m.triage?.pending ? 'waiting to be sorted' : `${m.triage?.urgency}: ${m.triage?.summary}`}</span></p>)}
      </section>
    </>
  );
}

function Chat({ tick, voice, verdict, setVerdict, bump }) {
  const [h, setH] = useState([]), [t, setT] = useState(''), [search, setSearch] = useState(false), [busy, setBusy] = useState(false), [ready, setReady] = useState(false), [ck, setCk] = useState(null), [err, setErr] = useState(''), [pic, setPic] = useState(false);
  const [files, setFiles] = useState([]), [fmsg, setFmsg] = useState('');
  const [chats, setChats] = useState([]), [cur, setCur] = useState(null), [enabled, setEnabled] = useState(false), [bar, setBar] = useState(false);
  const end = useRef(null), ta = useRef(null), pick = useRef(null);
  const remember = (id) => { try { if (id == null) localStorage.removeItem('omni.chat'); else localStorage.setItem('omni.chat', String(id)); } catch { /* private mode */ } };
  const loadChats = useCallback(async () => {
    try { const r = await api('/api/chats'); setEnabled(!!r.enabled); setChats(arr(r.chats)); return r; } catch { return { enabled: false, chats: [] }; }
  }, []);
  const openChat = useCallback(async (id) => {
    setBar(false); setErr(''); setCur(id); if (id !== 'calls') remember(id);
    try { setH(arr(await api(`/api/chats/${id}/messages`))); } catch (e) { setErr(e.message); setH([]); }
  }, []);
  /* the chat you had open comes back; without the chats table there is one single chat, as before */
  useEffect(() => {
    (async () => {
      const r = await loadChats();
      try {
        if (r.enabled) {
          const list = arr(r.chats), want = localStorage.getItem('omni.chat'), pick1 = list.find((c) => String(c.id) === want) || list[0];
          if (pick1) { setCur(pick1.id); setH(arr(await api(`/api/chats/${pick1.id}/messages`))); }
        } else setH(arr(await api('/api/chat/history')));
      } catch (e) { setErr(e.message); }
      setReady(true);
    })();
  }, [loadChats]);
  const newChat = () => { setCur(null); setH([]); setErr(''); setBar(false); remember(null); };
  const rename = async (id, title) => {
    try { const r = await api('/api/chats/' + id, 'PUT', { title }); setChats((l) => l.map((c) => (c.id === id ? { ...c, title: r.title || title } : c))); } catch (e) { setErr(e.message); }
  };
  const remove = async (id) => {
    try {
      await api('/api/chats/' + id, 'DELETE');
      const rest = chats.filter((c) => c.id !== id); setChats(rest);
      if (cur === id) { if (rest[0]) openChat(rest[0].id); else newChat(); }
    } catch (e) { setErr(e.message); }
  };
  useEffect(() => { api('/api/checkin/latest').then((c) => setCk(c && c.id ? c : null)).catch(() => {}); }, [tick]);
  useEffect(() => { if (end.current) end.current.scrollIntoView({ block: 'end' }); }, [h, busy, ck, verdict]);
  useEffect(() => { const el = ta.current; if (!el) return; el.style.height = 'auto'; el.style.height = Math.min(el.scrollHeight, 140) + 'px'; }, [t]);

  /* attaching: pictures (shrunk first), PDFs, audio, text and code files */
  const attach = async (list) => {
    const chosen = [...(list || [])];
    if (!chosen.length) return;
    setFmsg('');
    const room = MAX_FILES - files.length;
    if (room <= 0) { setFmsg(`Up to ${MAX_FILES} files at a time.`); return; }
    const out = [], notes = [];
    let total = files.reduce((n, f) => n + f.size, 0);
    for (const f of chosen.slice(0, room)) {
      try {
        const a = await readAttachment(f);
        if (total + a.size > MAX_ALL) { notes.push(`"${a.name}" would make the message too big (${kb(MAX_ALL)} in all).`); continue; }
        total += a.size; out.push(a);
      } catch (e) { notes.push(e.message); }
    }
    if (chosen.length > room) notes.push(`Only ${room} more file${room === 1 ? '' : 's'} fit in this message.`);
    if (out.length) { setFiles((x) => [...x, ...out]); setPic(false); }
    if (notes.length) setFmsg(notes.join(' '));
  };

  const send = async () => {
    if ((!t.trim() && !files.length) || busy) return;
    const sent = files, text = t.trim() || `Please look at the attached file${sent.length > 1 ? 's' : ''}.`;
    setH((x) => [...x, { role: 'user', content: text, files: sent.map(({ name, mime, size, preview }) => ({ name, mime, size, preview })) }]);
    setT(''); setFiles([]); setFmsg(''); setBusy(true); setErr('');
    try {
      const r = await api('/api/chat/send', 'POST', { text, search, image: pic && !sent.length, files: sent.map(({ name, mime, data }) => ({ name, mime, data })), chat_id: typeof cur === 'number' ? cur : null, new_chat: enabled && typeof cur !== 'number' });
      applyUi(r.ui); setH((x) => [...x, { role: 'assistant', content: r.reply, image: r.image }]);
      if (r.chat_id != null) {
        setCur(r.chat_id); remember(r.chat_id);
        setChats((l) => { const old = l.find((c) => c.id === r.chat_id); return [{ id: r.chat_id, title: r.title || (old && old.title) || 'New chat', updated_at: new Date().toISOString() }, ...l.filter((c) => c.id !== r.chat_id)]; });
      }
    } catch (e) { setH((x) => [...x, { role: 'assistant', content: 'Error: ' + e.message }]); }
    setPic(false); setBusy(false);
  };
  return (
    <div className="chat">
      <ChatBar open={bar} onClose={() => setBar(false)} enabled={enabled} chats={chats} cur={cur} onOpen={openChat} onNew={newChat} onRename={rename} onDelete={remove} onCalls={() => openChat('calls')} />
      <div className="chat-main">
      <div className="chat-head">
        <button className="icon bar-btn" aria-label="Open the chat list" onClick={() => { setBar(true); loadChats(); }}><Icon n="list" /></button>
        <span className="chat-title">{cur === 'calls' ? 'Calls' : (chats.find((c) => c.id === cur) || {}).title || 'New chat'}</span>
        <button className="icon" aria-label="Start a new chat" onClick={newChat}><Icon n="plus" /></button>
      </div>
      <div className="msgs"><div className="msgs-in">
        {err && <p className="err">{err}</p>}
        {!ready && <Loading />}
        {ready && !h.length && !ck && (
          <div className="empty">
            <img src="/logo.svg" alt="" width="56" height="56" />
            <p>Ask anything, or tap the microphone and talk.</p>
            <p className="mute">Code, plans, ideas, pictures (say "draw ..."), and files: tap the paperclip to attach a photo, PDF or document. Start a message with "remember that" to save a note. Teach it how things work in the Train section.</p>
          </div>
        )}
        {h.map((m, i) => (
          <div key={i} className={'msg ' + m.role}>
            {m.role === 'user' ? (
              <div className="bub">
                {arr(m.files).length > 0 && <div className="att">{m.files.map((f, j) => (f.preview ? <img key={j} src={f.preview} alt={f.name} /> : <span key={j} className="chip"><Icon n="file" size={14} /><span className="chip-n">{f.name}</span></span>))}</div>}
                <Md text={m.content} />
              </div>
            ) : (
              <div className="reply">
                <Md text={m.content} />
                {m.image && <figure className="gen"><img src={m.image} alt="Generated picture" /><button className="tiny-btn" onClick={() => saveDataUrl('omni-aura.png', m.image).catch(() => setErr('The picture could not be saved.'))}>Save picture</button></figure>}
                <button className="icon tiny" aria-label="Copy reply" onClick={() => navigator.clipboard && navigator.clipboard.writeText(m.content)}><Icon n="copy" size={16} /></button>
              </div>
            )}
          </div>
        ))}
        {ck && <CheckinCard ck={ck} voice={voice} onDone={(v) => { setVerdict(v); setCk(null); bump(); }} />}
        {verdict && !ck && <Verdict text={verdict} onClose={() => setVerdict('')} />}
        {busy && <div className="msg assistant"><div className="reply thinking"><InfinityLoader size={38} label={pic ? 'Drawing' : 'Thinking'} /></div></div>}
        <div ref={end} />
      </div></div>
      <div className="composer">
        {(files.length > 0 || fmsg) && (
          <div className="chips">
            {files.map((f, i) => (
              <span key={i} className="chip">
                {f.preview ? <img src={f.preview} alt="" /> : <Icon n="file" size={14} />}
                <span className="chip-n">{f.name}</span><em>{kb(f.size)}</em>
                <button className="chip-x" aria-label={'Remove ' + f.name} onClick={() => setFiles((x) => x.filter((_, j) => j !== i))}>×</button>
              </span>
            ))}
            {fmsg && <p className="err chip-err" role="status">{fmsg}</p>}
          </div>
        )}
        <div className="box">
          <input ref={pick} type="file" multiple hidden aria-hidden="true" tabIndex={-1} accept="image/*,application/pdf,audio/*,text/*,.md,.csv,.json,.js,.jsx,.ts,.tsx,.py,.java,.kt,.c,.cpp,.h,.go,.rs,.php,.rb,.sh,.sql,.yml,.yaml,.xml,.html,.css,.log" onChange={(e) => { attach(e.target.files); e.target.value = ''; }} />
          <textarea ref={ta} rows={1} value={t} onChange={(e) => setT(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && window.innerWidth > 700) { e.preventDefault(); send(); } }} placeholder={pic ? 'Describe the picture' : files.length ? 'Add a question about the file (optional)' : 'Message Omni-Aura'} aria-label="Message" />
          <div className="tools">
            <button className={'icon' + (files.length ? ' on' : '')} aria-label="Attach a file" title="Attach a photo, PDF or file" disabled={busy || files.length >= MAX_FILES} onClick={() => pick.current && pick.current.click()}><Icon n="clip" /></button>
            <button className={'icon' + (pic ? ' on' : '')} aria-label="Make a picture" aria-pressed={pic} title="Make a picture" disabled={files.length > 0} onClick={() => setPic((x) => !x)}><Icon n="image" /></button>
            <button className={'icon' + (search ? ' on' : '')} aria-label="Search the web" aria-pressed={search} title="Search the web" onClick={() => setSearch((s) => !s)}><Icon n="globe" /></button>
            <span className="grow" />
            <button className="icon" aria-label="Talk instead" onClick={() => voice.current && voice.current.start()}><Icon n="mic" /></button>
            <button className="send" aria-label="Send" disabled={busy || (!t.trim() && !files.length)} onClick={send}><Icon n="send" /></button>
          </div>
        </div>
      </div>
      </div>
    </div>
  );
}

function Assets() {
  const [q, setQ] = useState(''), [type, setType] = useState('photo'), [hits, setHits] = useState([]), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const go = async () => { setErr(''); setBusy(true); try { setHits(arr((await api(`/api/assets?q=${encodeURIComponent(q)}&type=${type}`)).hits)); } catch (e) { setErr(e.message); } setBusy(false); };
  return (
    <section>
      <h2>Assets</h2>
      <input placeholder="Search Pixabay" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') go(); }} />
      <select value={type} onChange={(e) => setType(e.target.value)}><option value="photo">Photos</option><option value="illustration">Illustrations</option><option value="vector">Vectors</option></select>
      <button disabled={busy} onClick={go}>{busy ? <Busy label="Searching" /> : 'Search'}</button>
      {err && <p className="err">{err}</p>}
      <div className="grid">{hits.map((x) => <a key={x.id} href={x.pageURL} target="_blank" rel="noreferrer"><img src={x.previewURL} alt={x.tags} loading="lazy" /></a>)}</div>
      <p className="mute">Images from Pixabay. Download an asset before using it in a project; permanent hotlinking is not allowed.</p>
    </section>
  );
}

function Settings() {
  const [s, setS] = useState(null), [models, setModels] = useState([]), [f, setF] = useState(''), [msg, setMsg] = useState('');
  useEffect(() => { (async () => { try { setS(await api('/api/settings')); setModels(arr(await api('/api/models'))); } catch (e) { setMsg(e.message); } })(); }, []);
  if (!s) return <section>{msg ? <p className="err">{msg}</p> : <Loading label="Loading settings" />}</section>;
  const save = async (patch) => {
    /* anything that lets replies go out without asking is a sensitive change */
    const widens = patch.autonomy === 'auto' || (patch.allowlist && patch.allowlist.join(',') !== (s.allowlist || []).join(','));
    if (widens) { const why = await guard('Change what is sent without asking'); if (why) { setMsg(why); return; } }
    try { setS(await api('/api/settings', 'PUT', patch)); setMsg('Saved'); } catch (e) { setMsg(e.message); }
  };
  const opts = () => ['free'].map((tier) => (
    <optgroup key={tier} label={tier === 'free' ? 'Free' : 'Paid'}>
      {models.filter((m) => m.tier === tier && (m.id + m.name).toLowerCase().includes(f.toLowerCase())).map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
    </optgroup>
  ));
  return (
    <section>
      <h2>Model</h2>
      <input placeholder="Filter models" value={f} onChange={(e) => setF(e.target.value)} />
      <label>Main model</label>
      <select value={s.model} onChange={(e) => save({ model: e.target.value })}>{opts()}</select>
      <h2>Autonomy</h2>
      <select value={s.autonomy} onChange={(e) => save({ autonomy: e.target.value })}>
        <option value="draft">Draft only</option>
        <option value="approve">Ask me before sending</option>
        <option value="auto">Auto-send routine replies to allowlisted senders</option>
      </select>
      <label>Allowlist (emails or phone numbers, comma-separated)</label>
      <input defaultValue={(s.allowlist || []).join(', ')} onBlur={(e) => save({ allowlist: e.target.value.split(',').map((x) => x.trim()).filter(Boolean) })} />
      <h2>Email stamp</h2>
      <textarea rows={3} defaultValue={s.stamp || ''} placeholder="Ashraf Abdalla, Developer, +254..." onBlur={(e) => save({ stamp: e.target.value })} />
      <h2>Quiet hours, start and end (EAT, 0 to 23)</h2>
      <div className="row">
        <input type="number" min="0" max="23" defaultValue={s.quiet_start} onBlur={(e) => save({ quiet_start: +e.target.value })} />
        <input type="number" min="0" max="23" defaultValue={s.quiet_end} onBlur={(e) => save({ quiet_end: +e.target.value })} />
      </div>
      <p className={/^saved$/i.test(msg) ? 'mute' : 'err'}>{msg}</p>
      <button className="ghost" onClick={async () => { try { await pauseStandby(); } catch { /* not the Android app */ } sb.auth.signOut(); }}>Sign out</button>
    </section>
  );
}

function About() {
  const out = [];
  let list = [];
  const flush = () => { if (list.length) { out.push(<ul key={'u' + out.length}>{list.map((t, i) => <li key={i}>{t}</li>)}</ul>); list = []; } };
  about.split('\n').forEach((line) => {
    if (line.startsWith('- ')) { list.push(line.slice(2)); return; }
    flush();
    if (line.startsWith('## ')) out.push(<h2 key={'h' + out.length}>{line.slice(3)}</h2>);
    else if (line.trim()) out.push(<p key={'p' + out.length}>{line}</p>);
  });
  flush();
  return <section>{out}</section>;
}

function Shop() {
  const blank = { name: '', note: '', budget: '', link: '' };
  const [items, setItems] = useState([]), [err, setErr] = useState(''), [f, setF] = useState(blank), [busy, setBusy] = useState(0), [ready, setReady] = useState(false);
  const load = useCallback(async () => { try { setItems(arr(await api('/api/shop'))); setErr(''); } catch (e) { setErr(e.message); } setReady(true); }, []);
  useEffect(() => { load(); }, [load]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const find = async (id) => { setBusy(id); try { await api(`/api/shop/${id}/find`, 'POST'); await load(); } catch (e) { setErr(e.message); } setBusy(0); };
  const mark = async (id, status) => { try { await api('/api/shop/' + id, 'PUT', { status }); } catch (e) { setErr(e.message); } load(); };
  const drop = async (id) => { try { await api('/api/shop/' + id, 'DELETE'); } catch (e) { setErr(e.message); } load(); };
  const todo = items.filter((x) => x.status === 'todo'), done = items.filter((x) => x.status === 'bought');
  return (
    <>
      <section>
        <h2>Shopping list</h2>
        {err && <p className="err">{err}</p>}
        {!ready && <Loading />}
        {ready && !todo.length && <p className="mute">Nothing to buy yet.</p>}
        {todo.map((x) => (
          <div key={x.id}>
            <p><b>{x.name}</b>{x.budget && <span className="mute"> budget {x.budget}</span>}<br /><span className="mute">{x.note}</span></p>
            {x.options && <p className="pre">{x.options}</p>}
            {arr(x.sources).map((s, i) => <p key={i}><a href={s.uri} target="_blank" rel="noreferrer">{s.title || s.uri}</a></p>)}
            {x.link && <p><a href={x.link} target="_blank" rel="noreferrer">Open saved link</a></p>}
            <button disabled={busy === x.id} onClick={() => find(x.id)}>{busy === x.id ? <Busy label="Searching" /> : x.options ? 'Search again' : 'Find options'}</button>
            <button className="ghost" onClick={() => mark(x.id, 'bought')}>Bought it</button>
            <button className="ghost" onClick={() => drop(x.id)}>Remove</button>
          </div>
        ))}
        <p className="mute">Prices come from a web search and can be out of date. Check the seller and the price at checkout; you do the buying.</p>
      </section>
      <section>
        <h2>Add an item</h2>
        <input placeholder="What do you need? (phone case, 1TB SSD)" value={f.name} onChange={set('name')} />
        <input placeholder="Details (size, model, colour)" value={f.note} onChange={set('note')} />
        <input placeholder="Budget (KES 3,000)" value={f.budget} onChange={set('budget')} />
        <input placeholder="Product link, if you already have one" value={f.link} onChange={set('link')} />
        <button onClick={async () => { if (!f.name.trim()) return; try { await api('/api/shop', 'POST', f); setF(blank); load(); } catch (e) { setErr(e.message); } }}>Add to list</button>
      </section>
      {done.length > 0 && (
        <section>
          <h2>Bought</h2>
          {done.map((x) => (
            <p key={x.id} className="row">{x.name}
              <button className="sm ghost" onClick={() => mark(x.id, 'todo')}>Undo</button>
              <button className="sm ghost" onClick={() => drop(x.id)}>Remove</button></p>
          ))}
        </section>
      )}
    </>
  );
}

function Bills() {
  const blank = { name: '', amount: '', cycle: 'monthly', next_due: '', notes: '' };
  const [subs, setSubs] = useState([]), [err, setErr] = useState(''), [f, setF] = useState(blank), [sug, setSug] = useState([]), [scanning, setScanning] = useState(false), [ready, setReady] = useState(false);
  const load = useCallback(async () => { try { setSubs(arr(await api('/api/subs'))); setErr(''); } catch (e) { setErr(e.message); } setReady(true); }, []);
  useEffect(() => { load(); }, [load]);
  const left = (d) => Math.round((Date.parse(d + 'T00:00:00Z') - Date.parse(new Date(Date.now() + 3 * 36e5).toISOString().slice(0, 10) + 'T00:00:00Z')) / 864e5);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const act = async (fn) => { try { await fn(); } catch (e) { setErr(e.message); } load(); };
  return (
    <>
      <section>
        <h2>Bills and subscriptions</h2>
        {err && <p className="err">{err}</p>}
        {!ready && <Loading />}
        {ready && !subs.length && <p className="mute">Nothing tracked yet.</p>}
        {subs.map((s) => {
          const d = left(s.next_due);
          return (
            <div key={s.id}>
              <p><b>{s.name}</b> {s.amount}<br /><span className="mute">{d < 0 ? `overdue by ${-d} day(s)` : d === 0 ? 'due today' : `due in ${d} day(s)`} ({s.next_due}, {s.cycle})</span></p>
              {s.notes && <p className="mute">{s.notes}</p>}
              <button onClick={() => act(() => api(`/api/subs/${s.id}/paid`, 'POST'))}>Mark paid</button>
              <button className="ghost" onClick={() => act(() => api('/api/subs/' + s.id, 'DELETE'))}>Remove</button>
            </div>
          );
        })}
      </section>
      <section>
        <h2>Add one</h2>
        <input placeholder="Name (Netflix, gym, rent)" value={f.name} onChange={set('name')} />
        <input placeholder="Amount (KES 500)" value={f.amount} onChange={set('amount')} />
        <select value={f.cycle} onChange={set('cycle')}><option value="monthly">Monthly</option><option value="weekly">Weekly</option><option value="yearly">Yearly</option><option value="once">One time</option></select>
        <input type="date" value={f.next_due} onChange={set('next_due')} />
        <input placeholder="How to pay (paybill or till number, link). No card numbers." value={f.notes} onChange={set('notes')} />
        <button onClick={async () => { if (!f.name || !f.next_due) return; try { await api('/api/subs', 'POST', f); setF(blank); load(); } catch (e) { setErr(e.message); } }}>Add</button>
        <p className="mute">Reminders reach your phone at 09:00 EAT: 7 days, 3 days and 1 day before, on the day, and once if overdue.</p>
      </section>
      <section>
        <h2>Find subscriptions in my email</h2>
        <button disabled={scanning} onClick={async () => { setScanning(true); setErr(''); try { setSug(arr((await api('/api/subs/scan', 'POST')).suggestions)); } catch (e) { setErr(e.message); } setScanning(false); }}>{scanning ? <Busy label="Reading receipts" /> : 'Scan my email'}</button>
        {sug.map((x, i) => (
          <div key={i}>
            <p><b>{x.name}</b> {x.amount} ({x.cycle})<br /><span className="mute">{x.evidence}</span></p>
            <input type="date" defaultValue={x.next_due || ''} onChange={(e) => { x.next_due = e.target.value; }} />
            <button onClick={async () => { if (!x.next_due) { setErr('Pick the next due date first.'); return; } try { await api('/api/subs', 'POST', { name: x.name, amount: x.amount, cycle: x.cycle, next_due: x.next_due, notes: x.evidence }); setSug(sug.filter((y) => y !== x)); load(); } catch (e) { setErr(e.message); } }}>Add to Bills</button>
          </div>
        ))}
        <p className="mute">It reads receipt-like emails from the last 4 months. Check each amount and date before adding.</p>
      </section>
    </>
  );
}

function Extras({ tick, bump }) {
  const [br, setBr] = useState([]), [until, setUntil] = useState(null), [msg, setMsg] = useState(''), [syncing, setSyncing] = useState(false), [, force] = useState(0);
  const load = useCallback(async () => { try { const [b, s] = await Promise.all([api('/api/briefings'), api('/api/settings')]); setBr(arr(b)); setUntil(s && s.focus_until); } catch {} }, []);
  useEffect(() => { load(); }, [load, tick]);
  useEffect(() => { const i = setInterval(() => force((n) => n + 1), 30000); return () => clearInterval(i); }, []);
  const left = until ? Math.max(0, Math.round((new Date(until) - Date.now()) / 6e4)) : 0;
  useEffect(() => { liveStatus(left); }, [left]);
  const setFocus = async (m) => { try { const s = await api('/api/focus', 'POST', { minutes: m }); setUntil(s.focus_until); } catch (e) { setMsg(e.message); } };
  const sync = async () => { setSyncing(true); setMsg(''); try { const r = await api('/api/gcal/sync', 'POST'); setMsg(`Synced ${r.synced} events with Google Calendar.`); bump(); } catch (e) { setMsg(e.message); } setSyncing(false); };
  return (
    <>
      {br[0] && <section><h2>{br[0].kind === 'weekly' ? 'Weekly review' : 'Briefing'}</h2><p className="pre">{br[0].text}</p></section>}
      <section>
        <h2>Focus mode</h2>
        <p className="mute">{left ? `On for ${left} more minutes. Only urgent alerts get through.` : 'Off. Turn it on to hold non-urgent alerts and check-ins.'}</p>
        {left ? <button onClick={() => setFocus(0)}>End focus</button> : <div className="row">{[30, 60, 90, 120].map((m) => <button key={m} onClick={() => setFocus(m)}>{m} min</button>)}</div>}
        <button className="ghost" disabled={syncing} onClick={sync}>{syncing ? <Busy label="Syncing" /> : 'Sync Google Calendar'}</button>
        {msg && <p className={/^synced/i.test(msg) ? 'mute' : 'err'} role="status">{msg}</p>}
      </section>
    </>
  );
}

function Write() {
  const [list, setList] = useState([]), [cur, setCur] = useState(null), [st, setSt] = useState({}), [out, setOut] = useState(''), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false), [ready, setReady] = useState(false);
  const load = useCallback(async () => { try { setList(arr(await api('/api/scenes'))); setSt((await api('/api/writing/stats')) || {}); } catch (e) { setMsg(e.message); } setReady(true); }, []);
  useEffect(() => { load(); }, [load]);
  const norm = (s) => ({ ...s, title: s.title || '', body: s.body || '' });
  const open = async (id) => { setOut(''); setMsg(''); try { setCur(norm(await api('/api/scenes/' + id))); } catch (e) { setMsg(e.message); } };
  const save = async () => { try { const s = await api('/api/scenes/' + cur.id, 'PUT', { title: cur.title, body: cur.body }); setCur(norm(s)); setMsg('Saved'); load(); } catch (e) { setMsg(e.message); } };
  const assist = async (mode) => { setBusy(true); setOut(''); try { await save(); setOut((await api(`/api/scenes/${cur.id}/assist`, 'POST', { mode })).text); } catch (e) { setOut(e.message); } setBusy(false); };
  if (cur) {
    const wc = cur.body.trim() ? cur.body.trim().split(/\s+/).length : 0;
    return (
      <section>
        <h2>Manuscript 28</h2>
        <input value={cur.title} onChange={(e) => setCur({ ...cur, title: e.target.value })} />
        <textarea rows={14} value={cur.body} onChange={(e) => setCur({ ...cur, body: e.target.value })} />
        <p className="mute">{wc} words {msg}</p>
        <button onClick={save}>Save</button>
        <div className="row">
          <button className="ghost" disabled={busy} onClick={() => assist('critique')}>Critique</button>
          <button className="ghost" disabled={busy} onClick={() => assist('continue')}>Next steps</button>
          <button className="ghost" disabled={busy} onClick={() => assist('brainstorm')}>Brainstorm</button>
        </div>
        {busy && <Busy label="Reading" />}
        {out && <p className="pre">{out}</p>}
        <p className="mute">Text you send for feedback goes to the AI provider. On Google's free tier it may be used to improve Google's products.</p>
        <button className="ghost" onClick={() => { setCur(null); load(); }}>Back to scenes</button>
        <button className="ghost" onClick={async () => { if (window.confirm('Delete this scene?')) { try { await api('/api/scenes/' + cur.id, 'DELETE'); } catch (e) { setMsg(e.message); return; } setCur(null); load(); } }}>Delete scene</button>
      </section>
    );
  }
  return (
    <section>
      <h2>Manuscript 28</h2>
      <p className="mute">Today {st.today || 0} of {st.goal || 500} words. Total {st.total || 0}.</p>
      {!ready && <Loading />}
      {list.map((s) => <p key={s.id} className="row"><a href="#open" onClick={(e) => { e.preventDefault(); open(s.id); }}>{s.title}</a><small className="mute">{s.words} words</small></p>)}
      <button onClick={async () => { try { const s = await api('/api/scenes', 'POST', { title: 'New scene' }); await open(s.id); load(); } catch (e) { setMsg(e.message); } }}>New scene</button>
      <label>Daily word goal</label>
      <input type="number" defaultValue={st.goal || 500} key={st.goal} onBlur={async (e) => { try { await api('/api/writing/goal', 'POST', { words: +e.target.value }); } catch (er) { setMsg(er.message); } load(); }} />
      {msg && <p className="err">{msg}</p>}
    </section>
  );
}

/* Calls, direct alerts, the Google connection and the security log */
function CallsSettings() {
  const [vt, setVt] = useState(''), stopVt = useRef(null);
  useEffect(() => () => { if (stopVt.current) stopVt.current(); }, []);
  /* plays a sample in the assistant's own voice, the same one used in calls and conversations */
  const testVoice = () => {
    if (stopVt.current) { stopVt.current(); stopVt.current = null; setVt(''); return; }
    stopVt.current = sayAloud('Good day, sir. This is my voice. If it matches the one you hear when we talk, all is in order.', (st) => { setVt(st === 'done' ? '' : st); if (st === 'done') stopVt.current = null; });
  };
  const [ps, setPs] = useState('checking'), [style, setStyle] = useState(localStorage.callStyle === 'banner' ? 'banner' : 'full'), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false), [g, setG] = useState(null), [log, setLog] = useState([]), [dev, setDev] = useState(null), [gt, setGt] = useState(null);
  const refresh = useCallback(async () => {
    setPs(await pushState());
    try { setG(await api('/api/google/status')); } catch (e) { setG({ problem: e.message }); }
    try { setDev((await api('/api/push/status')).devices); } catch { /* ignore */ }
    try { setLog(arr(await api('/api/calls/log'))); } catch { /* the calls table may not exist yet */ }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  const run = async (fn) => { setBusy(true); setMsg(''); try { setMsg(await fn()); } catch (e) { setMsg(e.message); } setBusy(false); refresh(); };
  const when = (t) => new Date(t).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  const word = { on: 'on', off: 'off', blocked: 'blocked in the browser settings', unsupported: 'not available here (use Chrome on Android)', checking: 'checking' }[ps];
  return (
    <>
      <h2>Calls and alerts</h2>
      <p className="mute">Omni-Aura rings you like a phone call when something needs your decision. With the app closed, the call arrives as a notification on this phone with no ntfy app in between.</p>
      <p className="mute">Direct calls on this device: {word}{dev != null ? ` · ${dev} device${dev === 1 ? '' : 's'} registered` : ''}</p>
      {ps === 'off' && <button onClick={() => run(async () => { await enablePush(); return 'Direct calls are on for this device.'; })} disabled={busy}>{busy ? <Busy label="Working" /> : 'Turn on direct calls'}</button>}
      {ps === 'on' && <button className="ghost" onClick={() => run(async () => { await disablePush(); return 'Direct calls are off for this device.'; })} disabled={busy}>Turn off on this device</button>}
      <button className="ghost" onClick={() => run(async () => { const r = await api('/api/calls/test', 'POST'); return r.via === 'push' ? 'Ringing your phone now. Close the app and try again to see how it arrives.' : r.via === 'ntfy' ? 'No device is set up for direct calls, so that one went through ntfy.' : 'The call is ringing in the app. No device is set up for direct calls yet.'; })} disabled={busy}>Ring me now (test)</button>
      <button className="ghost" onClick={testVoice}>{vt === 'connecting' ? 'Connecting... tap to stop' : vt === 'speaking' ? 'Speaking... tap to stop' : vt === 'device' ? 'Stop (phone voice)' : 'Hear the assistant voice (test)'}</button>
      {vt === 'device' && <p className="err">The assistant's own voice could not connect just now, so the phone's built-in voice is speaking instead. Try again in a moment.</p>}
      <label className="row">Call screen
        <select value={style} onChange={(e) => { localStorage.callStyle = e.target.value; setStyle(e.target.value); }}>
          <option value="full">Full screen</option><option value="banner">Top banner</option>
        </select>
      </label>
      {msg && <p className="mute" role="status">{msg}</p>}
      <h2>Google connection</h2>
      {g && g.id !== undefined && <p className="mute">G_ID {g.id ? 'found' : 'missing'} · G_SECRET {g.secret ? 'found' : 'missing'} · accounts: {g.accounts && g.accounts.length ? g.accounts.join(', ') : 'none readable'}</p>}
      {g && g.problem && <p className="err">{g.problem}</p>}
      {g && arr(g.warn).map((w, i) => <p key={i} className="err">{w}</p>)}
      <button className="ghost" onClick={() => run(async () => { setGt(null); const r = await api('/api/google/test'); setGt(r.accounts || []); return (r.accounts || []).length ? 'Google test finished. Anything not working is explained below.' : (r.status && r.status.problem) || 'No Google accounts to test.'; })} disabled={busy}>Test Google now</button>
      {gt && gt.map((a) => (
        <div key={a.name} className="gtest">
          <b>{a.name}{a.email ? ' · ' + a.email : ''}</b>
          {[['token', 'Sign-in'], ['gmail', 'Gmail'], ['calendar', 'Calendar'], ['drive', 'Drive (files)'], ['docs', 'Docs']].map(([k, label]) => (
            <p key={k} className={a[k] === 'ok' ? 'mute' : 'err'}>{label}: {a[k] === 'ok' ? 'working' : a[k] || 'not tested'}</p>
          ))}
        </div>
      ))}
      <h2>Mail</h2>
      <p className="mute">Only unread mail from the last 2 days is read, and anything older than 12 hours never rings. Drafts that have sat for days can be cleared here.</p>
      <button className="ghost" onClick={() => run(async () => { const r = await api('/api/inbox/clear-old', 'POST'); return r.cleared ? `Cleared ${r.cleared} old draft${r.cleared === 1 ? '' : 's'}.` : 'Nothing old to clear.'; })} disabled={busy}>Clear old mail drafts</button>
      <h2>Recent calls and security</h2>
      {!log.length && <p className="mute">No calls yet.</p>}
      {log.slice(0, 12).map((c) => (
        <p key={c.id} className="mute logrow">
          <b>{c.kind === 'security' ? 'Security' : c.kind}</b> · {c.status}{c.via ? ' · ' + c.via : ''} · {when(c.created_at)}
          <br />{c.kind === 'security' && c.meta && c.meta.email ? 'Account: ' + c.meta.email : c.say}
        </p>
      ))}
    </>
  );
}

/* Settings, Security: the two fingerprint switches. Each one is proven to work before it turns on, so it cannot lock you out by surprise. */
function Fingerprint() {
  const [st, setSt] = useState(null), [ask, setAsk] = useState(fpOn()), [lockOn, setLockOn] = useState(fpLockOn()), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false);
  useEffect(() => { bioStatus().then(setSt); }, []);
  const flip = async (kind, on) => {
    if (busy) return;
    setBusy(true); setMsg('');
    const what = kind === 'lock' ? 'fingerprint unlock' : 'fingerprint checks';
    const r = on ? await enableFingerprint(kind, 'Turn on ' + what) : await disableFingerprint(kind, 'Turn off ' + what);
    if (r.ok) { (kind === 'lock' ? setLockOn : setAsk)(on); setMsg(on ? 'Turned on.' : 'Turned off.'); } else setMsg(r.why);
    setBusy(false);
  };
  return (
    <>
      <p className="mute">{st == null ? 'Checking this phone...' : st.ok ? (st.mode === 'native' ? 'This phone can check your fingerprint.' : 'This browser can check your fingerprint.') : st.why}</p>
      <label className="row"><input type="checkbox" checked={lockOn} disabled={busy} onChange={(e) => flip('lock', e.target.checked)} />Open the app with my fingerprint</label>
      <label className="row"><input type="checkbox" checked={ask} disabled={busy} onChange={(e) => flip('ask', e.target.checked)} />Ask for my fingerprint before sensitive actions: sending replies, auto-send rules, backups, emergency contacts</label>
      <p className="mute">The passphrase, if the server has one, still opens the app. The approval PIN still applies to sends.</p>
      {msg && <p className={/^turned/i.test(msg) ? 'mute' : 'err'} role="status">{msg}</p>}
    </>
  );
}

/* Settings, This app: what this copy is and which native parts it has. Useful for checking the Android build on the phone. */
function BuildInfo() {
  const [rows, setRows] = useState(null);
  useEffect(() => { buildInfo().then(setRows).catch(() => setRows([['Could not read', 'this build']])); }, []);
  if (!rows) return <p className="mute">Checking...</p>;
  return <div>{rows.map(([k, v]) => <p key={k} className="mute"><b>{k}:</b> {v}</p>)}</div>;
}

function SettingsExtras() {
  const [mem, setMem] = useState([]), [msg, setMsg] = useState(''), [chain, setChain] = useState([]), [auto, setAuto] = useState(true), [accts, setAccts] = useState([]), [isl, setIsl] = useState(localStorage.isl !== '0'), [fb, setFb] = useState([]), [models, setModels] = useState([]), [newId, setNewId] = useState('');
  const load = useCallback(async () => {
    try {
      setMem(arr(await api('/api/memories')));
      const st = await api('/api/settings'); setAuto(st.auto_chain !== false); setFb(arr(st.fallback));
      setModels(arr(await api('/api/models'))); setChain(arr(await api('/api/chain'))); setAccts(arr(await api('/api/accounts')));
    } catch (e) { setMsg(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  const saveFb = async (a) => { try { const s = await api('/api/settings', 'PUT', { fallback: a }); setFb(arr(s.fallback)); setNewId(''); setMsg('Saved'); } catch (e) { setMsg(e.message); } };
  const backup = async () => {
    const why = await guard('Download all your data');
    if (why) { setMsg(why); return; }
    try {
      const d = await api('/api/backup');
      const how = await saveFile('omni-aura-backup.json', new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' }));
      const bad = d && d.errors ? Object.keys(d.errors) : [];
      setMsg(bad.length ? `Backup created, but these tables could not be read: ${bad.join(', ')}.` : how === 'native' ? 'Backup ready. Choose where to save it.' : how === 'cancelled' ? 'The backup was not saved.' : 'Backup created. Look in your downloads.');
    } catch (e) { setMsg(e.message); }
  };
  return (
    <section>
      <CallsSettings />
      <h2>Your own switching list</h2>
      <p className="mute">Tried right after your main model, in this order. Type a model ID or pick one from the suggestions. Start it with the provider: gemini:, groq: or openrouter:</p>
      {fb.map((id, i) => <p key={id} className="row">{i + 1}. {(models.find((m) => m.id === id) || {}).name || id}<button className="sm ghost" onClick={() => saveFb(fb.filter((x) => x !== id))}>Remove</button></p>)}
      <input list="model-ids" placeholder="gemini:gemini-2.5-flash" value={newId} onChange={(e) => setNewId(e.target.value)} />
      <datalist id="model-ids">{models.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</datalist>
      <button onClick={() => { const id = newId.trim(); if (id && !fb.includes(id)) saveFb([...fb, id]); }}>Add to my list</button>
      <h2>Free-model switching</h2>
      <label className="row"><input type="checkbox" checked={auto} onChange={async (e) => { setAuto(e.target.checked); try { await api('/api/settings', 'PUT', { auto_chain: e.target.checked }); } catch (er) { setMsg(er.message); } }} />When a model runs out, switch to the next free one</label>
      {auto && <ol className="mute">{chain.map((m) => <li key={m.id}>{m.name}</li>)}</ol>}
      <h2>Email accounts</h2>
      {!accts.length && <p className="mute">None connected yet.</p>}
      {accts.map((x) => (
        <div key={x.name}>
          <p className="mute">{x.name}: {x.error ? 'not working' : x.email || 'connected'}</p>
          {x.error && <p className="err">{x.error}</p>}
        </div>
      ))}
      <h2>Live status (dynamic island)</h2>
      <label className="row"><input type="checkbox" checked={isl} onChange={(e) => { localStorage.isl = e.target.checked ? '1' : '0'; setIsl(e.target.checked); }} />Show focus mode as a live notification on the Android app</label>
      <h2>This app</h2>
      <BuildInfo />
      <h2>Security</h2>
      <Fingerprint />
      <h2>Things I remember</h2>
      {!mem.length && <p className="mute">Nothing yet. Tell Chat "remember that ..."</p>}
      {mem.map((m) => <p key={m.id} className="row">{m.fact}<button className="sm ghost" onClick={async () => { try { await api('/api/memories/' + m.id, 'DELETE'); } catch (e) { setMsg(e.message); } load(); }}>Forget</button></p>)}
      <h2>Your data</h2>
      <button onClick={backup}>Download a backup (JSON)</button>
      <button className="ghost" onClick={async () => { if (window.confirm('Clear the chat history? Saved notes are kept.')) { const why = await guard('Clear the chat history'); if (why) { setMsg(why); return; } try { await api('/api/chat/history', 'DELETE'); setMsg('Chat history cleared.'); } catch (e) { setMsg(e.message); } } }}>Clear chat history</button>
      {msg && <p className="mute" role="status">{msg}</p>}
    </section>
  );
}

const fixNow = () => new Promise((ok) => (navigator.geolocation
  ? navigator.geolocation.getCurrentPosition((p) => ok({ lat: p.coords.latitude, lon: p.coords.longitude }), () => ok({}), { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 })
  : ok({})));

function Safety() {
  const blank = { name: '', email: '', whatsapp: '', ntfy_topic: '' };
  const [cs, setCs] = useState([]), [ev, setEv] = useState(null), [f, setF] = useState(blank), [pin, setPin] = useState(''), [msg, setMsg] = useState(''), [word, setWord] = useState(''), [savedWord, setSavedWord] = useState(''), [hid, setHid] = useState(localStorage.hs === '1'), [tap3, setTap3] = useState(localStorage.sos3 !== '0'), [last, setLast] = useState(lastSos()), [sending, setSending] = useState(false), [, tick] = useState(0);
  const hold = useRef(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const load = useCallback(async () => { try { setCs(arr(await api('/api/safety/contacts'))); setEv(await api('/api/safety/timer')); const w = ((await api('/api/settings')) || {}).duress_word || ''; setWord(w); setSavedWord(w); } catch (e) { setMsg(e.message); } }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { const i = setInterval(() => tick((n) => n + 1), 15000); return () => clearInterval(i); }, []);
  useEffect(() => {
    if (!ev) return undefined;
    const sendLoc = async () => { const w = await fixNow(); if (w.lat != null) api('/api/safety/location', 'POST', w).catch(() => {}); };
    sendLoc(); const i = setInterval(sendLoc, 60000); return () => clearInterval(i);
  }, [ev && ev.id]);
  const left = ev ? Math.max(0, Math.round((new Date(ev.due_at) - Date.now()) / 6e4)) : 0;
  const start = async (m) => { try { const w = await fixNow(); if (w.lat != null) await api('/api/safety/location', 'POST', w); setEv(await api('/api/safety/timer', 'POST', { minutes: m })); setMsg(''); } catch (e) { setMsg(e.message); } };
  const cancel = async () => { try { await api(`/api/safety/timer/${ev.id}/cancel`, 'POST', { pin }); setEv(null); setPin(''); setMsg('Safe. Timer ended.'); } catch (e) { setMsg(e.message); } };
  /* The Help button shows what really happened. It no longer says "Done." whatever the result. */
  const sos = async () => {
    if (sending) return;
    setSending(true); setMsg('');
    const r = await silentSos('button');
    setLast(lastSos()); setMsg(r.ok ? 'Alert sent. ' + r.text : 'Not sent: ' + r.text); setSending(false);
  };
  return (
    <>
      <section>
        <h2>Safe-walk timer</h2>
        {ev ? (
          <>
            <p>{ev.status === 'checking' ? 'A quick check was sent to your phone. Answer it, or enter your PIN here.' : `Your alert goes out in ${left} minutes unless you tap I am safe.`}</p>
            <input type="password" inputMode="numeric" placeholder="PIN" value={pin} onChange={(e) => setPin(e.target.value)} />
            <button onClick={cancel}>I am safe</button>
          </>
        ) : <div className="row">{[15, 30, 60, 120].map((m) => <button key={m} onClick={() => start(m)}>{m} min</button>)}</div>}
        {msg && <p className={/^(alert sent|safe)/i.test(msg) ? 'mute' : 'err'} role="status">{msg}</p>}
      </section>
      <section>
        <h2>Help</h2>
        <button className="ghost" disabled={sending} style={{ touchAction: 'none', userSelect: 'none' }} onContextMenu={(e) => e.preventDefault()} onPointerDown={() => { hold.current = setTimeout(sos, 2000); }} onPointerUp={() => clearTimeout(hold.current)} onPointerLeave={() => clearTimeout(hold.current)}>{sending ? <Busy label="Sending" /> : 'Hold 2 seconds: send help'}</button>
        <p className="mute">Sends your last known location to your emergency contacts. It does not call the police, so keep 999 or 112 ready.</p>
        <h2>Silent SOS</h2>
        <p>Tap the logo three times quickly, on any screen. Nothing shows and nothing sounds.</p>
        <p className="mute">Your phone buzzes once when it starts, twice when an alert got out, and once for a long time if it could not be sent. A failed one is tried again when the phone is back online.</p>
        {last && <p className={last.ok ? 'mute' : 'err'}>Last silent SOS: {new Date(last.at).toLocaleString()}, {last.ok ? 'sent' : 'not sent'}. {last.text}</p>}
        <label className="row"><input type="checkbox" checked={tap3} onChange={(e) => { localStorage.sos3 = e.target.checked ? '1' : '0'; setTap3(e.target.checked); }} />Triple-tap on the logo sends the SOS</label>
      </section>
      <section>
        <h2>Emergency contacts</h2>
        {!cs.length && <p className="mute">None yet. Tell each person first and get their agreement.</p>}
        {cs.map((c) => <p key={c.id} className="row">{c.name}<small className="mute">{[c.email && 'email', c.whatsapp && 'WhatsApp', c.ntfy_topic && 'ntfy'].filter(Boolean).join(', ')}</small><button className="sm ghost" onClick={async () => { const why = await guard('Remove an emergency contact'); if (why) { setMsg(why); return; } try { await api('/api/safety/contacts/' + c.id, 'DELETE'); } catch (e) { setMsg(e.message); } load(); }}>Remove</button></p>)}
        <input placeholder="Name" value={f.name} onChange={set('name')} />
        <input placeholder="Email" value={f.email} onChange={set('email')} />
        <input placeholder="WhatsApp number with country code, 2547..." value={f.whatsapp} onChange={set('whatsapp')} />
        <input placeholder="ntfy topic they subscribe to" value={f.ntfy_topic} onChange={set('ntfy_topic')} />
        <button onClick={async () => { const why = await guard('Add an emergency contact'); if (why) { setMsg(why); return; } try { await api('/api/safety/contacts', 'POST', f); setF(blank); load(); } catch (e) { setMsg(e.message); } }}>Add contact</button>
        <button className="ghost" onClick={async () => { const why = await guard('Send a test alert to your contacts'); if (why) { setMsg(why); return; } try { const r = await api('/api/safety/test', 'POST'); setMsg((r.ok ? 'Alert sent. ' : '') + r.result); } catch (e) { setMsg(e.message); } }}>Send a test alert</button>
      </section>
      <section>
        <h2>Code word</h2>
        <input placeholder="A word or phrase you can type in Chat" value={word} onChange={(e) => setWord(e.target.value)} onBlur={async () => { if (word === savedWord) return; const why = await guard('Change the code word'); if (why) { setMsg(why); setWord(savedWord); return; } try { await api('/api/settings', 'PUT', { duress_word: word }); setSavedWord(word); } catch (e) { setMsg(e.message); } }} />
        <p className="mute">Type it in Chat, as a whole word or phrase, and Omni-Aura answers "Understood." while silently alerting your contacts. At least 4 characters. A duress PIN for the timer is set on the server.</p>
        <label className="row"><input type="checkbox" checked={hid} onChange={(e) => { localStorage.hs = e.target.checked ? '1' : '0'; setHid(e.target.checked); }} />Hide Safety from the menu (press and hold the logo to open it)</label>
      </section>
    </>
  );
}

const useWide = () => {
  const q = '(min-width: 900px)';
  const [w, setW] = useState(() => matchMedia(q).matches);
  useEffect(() => { const m = matchMedia(q), f = () => setW(m.matches); m.addEventListener('change', f); return () => m.removeEventListener('change', f); }, []);
  return w;
};

/* shown instead of a black screen when this build has no database address */
function SetupProblem() {
  return (
    <div className="login">
      <form onSubmit={(e) => { e.preventDefault(); location.reload(); }}>
        <h1 className="brandline"><img src="/logo.svg" alt="" width="44" height="44" />Omni-Aura</h1>
        <p className="err" role="alert">{CONFIG_PROBLEM}</p>
        <button className="primary" type="submit">Try again</button>
      </form>
    </div>
  );
}

/* Self-updating. The web app is rebuilt whenever the code is pushed, and the Android app loads it live, so there is never a new APK
   to install. This notices a newer build while the app stays open, and switches to it by itself after the app has been in the
   background for a couple of minutes (a message is shown first if you are using it). */
function useUpdates(on) {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (!on) return undefined;
    const tag = document.querySelector('script[type="module"][src*="/assets/"]');
    const mine = tag ? tag.src : '';
    if (!mine) return undefined; /* the development server has no build to compare with */
    let hiddenAt = 0, found = false, off = false;
    const check = async () => {
      if (found || off) return;
      try {
        const r = await fetch('/index.html?v=' + Date.now(), { cache: 'no-store' });
        const m = (await r.text()).match(/src="([^"]*\/assets\/[^"]+\.js)"/);
        if (m && !off && new URL(m[1], location.href).href !== mine) { found = true; setReady(true); }
      } catch { /* offline: try again later */ }
    };
    const vis = () => {
      if (document.hidden) { hiddenAt = Date.now(); return; }
      if (found && hiddenAt && Date.now() - hiddenAt > 120000) { location.reload(); return; }
      check();
    };
    document.addEventListener('visibilitychange', vis);
    const first = setTimeout(check, 4000), again = setInterval(check, 10 * 60e3);
    return () => { off = true; clearTimeout(first); clearInterval(again); document.removeEventListener('visibilitychange', vis); };
  }, [on]);
  return ready;
}

export default function App() {
  const [session, setSession] = useState(undefined), [tab, setTab] = useState('Chat'), [tick, setTick] = useState(0), [verdict, setVerdict] = useState(''), [lock, setLock] = useState({ on: null, err: '' }), [unlocked, setUnlocked] = useState(false), [intruder, setIntruder] = useState(null), [toast, setToast] = useState(null);
  const wide = useWide();
  const [navOpen, setNavOpen] = useState(() => (matchMedia('(min-width: 900px)').matches ? localStorage.nav !== '0' : false));
  const voice = useRef(null), taps = useRef({ n: 0, at: 0, hold: null }), fresh = useRef(false), hiddenAt = useRef(0);
  const bump = useCallback(() => setTick((n) => n + 1), []);
  useEffect(() => { setNavOpen(wide ? localStorage.nav !== '0' : false); }, [wide]);
  useEffect(() => {
    sb.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = sb.auth.onAuthStateChange((_, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  /* ---- the app lock: asked for on every open, and again after 5 minutes in the background ---- */
  const checkLock = useCallback(() => {
    setLock((l) => ({ ...l, err: '' }));
    fetch(API + '/api/lock/status').then((r) => r.json()).then((j) => setLock({ on: !!j.enabled, err: '' }))
      .catch(() => setLock({ on: true, err: 'Cannot reach the server. A sleeping free server can take about a minute to wake.' }));
  }, []);
  useEffect(() => { checkLock(); }, [checkLock]);
  useEffect(() => { if (session && fresh.current) { setUnlocked(true); fresh.current = false; } if (!session) setUnlocked(false); }, [session]);
  useEffect(() => {
    const vis = () => {
      if (document.hidden) hiddenAt.current = Date.now();
      else if ((lock.on || fpLockOn()) && hiddenAt.current && Date.now() - hiddenAt.current > 5 * 60e3) setUnlocked(false);
    };
    document.addEventListener('visibilitychange', vis);
    return () => document.removeEventListener('visibilitychange', vis);
  }, [lock.on]);
  /* an account that is not the owner's: sign it out and show the nice-try page */
  useEffect(() => {
    const on = () => { setIntruder((session && session.user && session.user.email) || 'this account'); sb.auth.signOut(); };
    window.addEventListener('omni:intruder', on);
    return () => window.removeEventListener('omni:intruder', on);
  }, [session]);
  useEffect(() => { if (session) api('/api/me').catch(() => {}); }, [session]);
  const open = !!session && lock.on !== null && (!(lock.on || fpLockOn()) || unlocked || fresh.current);
  const updateReady = useUpdates(!!session);
  /* the free server sleeps when it is idle; a light ping every few minutes while the app is open keeps it awake, so voice and chat answer at once */
  useEffect(() => {
    if (!session) return undefined;
    const ping = () => { if (!document.hidden) fetch(API + '/api/lock/status').catch(() => {}); };
    const id = setInterval(ping, 4 * 60e3);
    return () => clearInterval(id);
  }, [session]);
  useEffect(() => { if (open) syncPush().catch(() => {}); }, [open]);
  useEffect(() => { if (open && isNative()) autoStandby().catch(() => {}); }, [open]);
  useEffect(() => { if (!toast) return undefined; const t = setTimeout(() => setToast(null), 14000); return () => clearTimeout(t); }, [toast]);

  const calls = useCalls({ active: open, voice, onRing: (c) => { if (document.hidden) notify('Omni-Aura is calling', c.say || c.title || ''); } });
  const onCall = useCallback(async ({ call, transcript }) => {
    try {
      const r = await api(`/api/calls/${call.id}/take`, 'POST', { text: transcript });
      if (r.message) setToast({ text: r.message, goto: r.goto || '' });
      bump();
    } catch (e) { setToast({ text: 'I could not record your decision: ' + e.message }); }
  }, [bump]);

  useEffect(() => {
    if (!open) return undefined;
    /* the call screen and direct alerts handle the noisy part; these just refresh the lists */
    const ch = sb.channel('omni-live')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'checkins' }, () => bump())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'outbox' }, () => bump())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'inbox' }, () => bump())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [open, bump]);
  /* silent SOS: ask for location permission once, and send any SOS that was waiting for a connection */
  useEffect(() => {
    if (!session) return undefined;
    warmLocation(); flushSos();
    const on = () => flushSos(), vis = () => { if (!document.hidden) flushSos(); };
    window.addEventListener('online', on); document.addEventListener('visibilitychange', vis);
    return () => { window.removeEventListener('online', on); document.removeEventListener('visibilitychange', vis); };
  }, [session]);
  useEffect(() => {
    const k = (e) => { if (e.key === 'Escape' && !wide) setNavOpen(false); };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [wide]);

  const toggleNav = () => { const n = !navOpen; setNavOpen(n); if (wide) localStorage.nav = n ? '1' : '0'; };
  const go = (t) => { if (t === 'Voice') { voice.current && voice.current.start(); } else setTab(t); if (!wide) setNavOpen(false); };
  /* Three quick taps on the logo send the SOS; pressing and holding opens the Safety page. */
  const logo = {
    onClick: () => {
      const s = taps.current, now = Date.now();
      s.n = now - s.at < 650 ? s.n + 1 : 1; s.at = now;
      if (s.n >= 3) { s.n = 0; if (localStorage.sos3 !== '0') silentSos('logo'); }
    },
    onPointerDown: () => { const s = taps.current; clearTimeout(s.hold); s.hold = setTimeout(() => { s.n = 0; buzz(20); setTab('Safety'); }, 1200); },
    onPointerUp: () => clearTimeout(taps.current.hold),
    onPointerLeave: () => clearTimeout(taps.current.hold),
    onPointerCancel: () => clearTimeout(taps.current.hold),
    onContextMenu: (e) => e.preventDefault(),
  };

  if (CONFIG_PROBLEM) return <SetupProblem />;
  if (session === undefined || (session && lock.on === null && !intruder)) return <div className="splash"><InfinityLoader size={Math.round(Math.min(window.innerWidth * 0.86, 420) / 2.3)} label="Starting" /><p>Omni-Aura</p></div>;
  if (intruder) return <NiceTry tried={intruder === 'this account' ? '' : intruder} onBack={() => setIntruder(null)} />;
  if (!session) return <Login fresh={fresh} onIntruder={setIntruder} />;
  /* signing out also stops the phone listening for calls (it comes back by itself after the next sign-in) */
  const signOut = async () => {
    if (open && !window.confirm('Sign out of Omni-Aura on this device?')) return;
    try { await pauseStandby(); } catch { /* not the Android app */ }
    sb.auth.signOut();
  };
  if (!open) return <Lock onOpen={() => setUnlocked(true)} serverError={lock.err} onRetry={checkLock} passOn={!!lock.on} onSignOut={signOut} />;
  const items = NAV.filter(([t]) => t !== 'Safety' || localStorage.hs !== '1');
  const shared = { tick, voice, verdict, setVerdict, bump };
  return (
    <div className={'app' + (navOpen ? ' nav-open' : '')}>
      <aside className={'panel' + (navOpen ? ' open' : '')} aria-label="Menu" aria-hidden={!navOpen}>
        <div className="panel-in">
          <div className="panel-head"><span className="word">Omni-Aura</span><button className="icon" aria-label="Collapse menu" onClick={toggleNav}><Icon n="chev" /></button></div>
          <nav>
            {items.map(([t, ic]) => (
              <button key={t} className={'nav' + (tab === t ? ' on' : '')} aria-current={tab === t ? 'page' : undefined} onClick={() => go(t)}>
                <Icon n={ic} /><span>{t}</span>{t === 'Chat' && <em>home</em>}
              </button>
            ))}
          </nav>
          <div className="panel-out">
            <button className="nav" onClick={signOut}><Icon n="logout" /><span>Sign out</span></button>
          </div>
          <div className="panel-foot">
            <a href={API + '/terms'} target="_blank" rel="noreferrer">Terms of use</a>
            <a href={API + '/privacy'} target="_blank" rel="noreferrer">Privacy policy</a>
          </div>
        </div>
      </aside>
      <div className={'scrim' + (navOpen && !wide ? ' show' : '')} onClick={() => setNavOpen(false)} />
      <div className="column">
        <header className="top">
          <button className="icon" aria-label={navOpen ? 'Close menu' : 'Open menu'} aria-expanded={navOpen} onClick={toggleNav}><Icon n="menu" /></button>
          <button className="brand" aria-label="Omni-Aura" {...logo}><img src="/logo.svg" alt="" width="30" height="30" draggable="false" /><span>Omni-Aura</span></button>
          <span className="grow" />
          <button className="icon" aria-label="Talk to Omni-Aura" onClick={() => voice.current && voice.current.start()}><Icon n="mic" /></button>
        </header>
        <main className={'page' + (tab === 'Chat' ? ' chatpage' : '')}>
          <Boundary resetKey={tab} onHome={() => setTab('Chat')}>
            {tab === 'Chat' && <Chat {...shared} />}
            {tab !== 'Chat' && (
              <div className="col" key={tab}>
                {tab === 'Today' && <><Extras tick={tick} bump={bump} /><Today {...shared} /></>}
                {tab === 'Bills' && <Bills />}
                {tab === 'Shop' && <Shop />}
                {tab === 'Write' && <Write />}
                {tab === 'Inbox' && <Inbox tick={tick} />}
                {tab === 'Assets' && <Assets />}
                {tab === 'Train' && <Train />}
                {tab === 'Settings' && <><Settings /><SettingsExtras /><PhoneParts /></>}
                {tab === 'Safety' && <Safety />}
                {tab === 'About' && <About />}
              </div>
            )}
          </Boundary>
        </main>
      </div>
      <Voice ref={voice} onCheckin={(v) => { setVerdict(v || 'Check-in recorded.'); bump(); }} onCall={onCall} onBusy={calls.setBusy} />
      <CallLayer call={calls.call} phase={calls.phase} onAccept={calls.accept} onDecline={calls.decline} onDismiss={calls.dismiss} onOpen={(t) => setTab(t)} />
      {updateReady && !toast && (
        <div className="toast" role="status">
          <span>A new version of Omni-Aura is ready.</span>
          <button className="tiny-btn" onClick={() => location.reload()}>Update now</button>
        </div>
      )}
      {toast && (
        <div className="toast" role="status">
          <span>{toast.text}</span>
          {toast.goto && <button className="tiny-btn" onClick={() => { setTab(toast.goto); setToast(null); }}>Open {toast.goto}</button>}
          <button className="tiny-btn" aria-label="Dismiss" onClick={() => setToast(null)}>×</button>
        </div>
      )}
    </div>
  );
}
