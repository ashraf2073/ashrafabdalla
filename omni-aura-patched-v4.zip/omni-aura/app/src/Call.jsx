import { useCallback, useEffect, useRef, useState } from 'react';
import { Native, isNative } from './native.js';
import { Capacitor } from '@capacitor/core';
import { api, sb } from './lib.js';
import { audioCtx, sayAloud } from './speak.js';
import { Icon, LogoLive } from './ui.jsx';

/* ---------- ring tone: two soft bell notes, repeated, plus a vibration pattern ----------
   Browsers only allow sound after a tap; the shared audio context (speak.js) is created on the first touch of the app. */
function chime() {
  const actx = audioCtx();
  if (!actx || actx.state !== 'running') return;
  const now = actx.currentTime;
  [[880, 0], [1318.5, 0.2], [880, 0.95], [1318.5, 1.15]].forEach(([f, d]) => {
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, now + d);
    g.gain.exponentialRampToValueAtTime(0.22, now + d + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + d + 0.6);
    o.connect(g); g.connect(actx.destination); o.start(now + d); o.stop(now + d + 0.65);
  });
}
function useRinger(on) {
  useEffect(() => {
    if (!on) return undefined;
    const tick = () => { chime(); try { navigator.vibrate && navigator.vibrate([420, 160, 420, 160, 420]); } catch { /* ignore */ } };
    tick();
    const id = setInterval(tick, 2600);
    return () => { clearInterval(id); try { navigator.vibrate && navigator.vibrate(0); } catch { /* ignore */ } };
  }, [on]);
}

const hello = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };
/* ---------- direct alerts (Web Push): the phone's own notification, no ntfy app ---------- */
const b64u = (s) => { const raw = atob((s + '='.repeat((4 - (s.length % 4)) % 4)).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from(raw, (c) => c.charCodeAt(0)); };
export const pushSupported = () => typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && !Capacitor.isNativePlatform();
export async function pushState() {
  if (!pushSupported()) return 'unsupported';
  if (Notification.permission === 'denied') return 'blocked';
  try { const reg = await navigator.serviceWorker.getRegistration(); return reg && (await reg.pushManager.getSubscription()) ? 'on' : 'off'; } catch { return 'off'; }
}
async function ensureSub(force) {
  const reg = await navigator.serviceWorker.register('/sw.js');
  await navigator.serviceWorker.ready;
  let sub = await reg.pushManager.getSubscription();
  if (sub && force) { try { await sub.unsubscribe(); } catch { /* ignore */ } sub = null; }
  if (!sub) { const { key } = await api('/api/push/key'); sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64u(key) }); }
  await api('/api/push/subscribe', 'POST', { subscription: sub.toJSON(), ua: navigator.userAgent });
}
/* asks for permission, then registers this phone (from a button press) */
export async function enablePush() {
  if (!pushSupported()) throw new Error('This browser cannot receive direct alerts. Use Chrome on Android, or add the web app to your home screen.');
  if ((await Notification.requestPermission()) !== 'granted') throw new Error('Notifications were not allowed. Allow them for this site in the browser settings, then try again.');
  await ensureSub(true);
}
/* quietly keeps this phone registered on every open, once permission has been given */
export async function syncPush() {
  if (!pushSupported() || Notification.permission !== 'granted') return;
  await ensureSub(false);
}
export async function disablePush() {
  const reg = await navigator.serviceWorker.getRegistration();
  const sub = reg && (await reg.pushManager.getSubscription());
  if (sub) { try { await api('/api/push/unsubscribe', 'POST', { endpoint: sub.endpoint }); } catch { /* ignore */ } await sub.unsubscribe(); }
}

/* ---------- the call state ----------
   A call arrives live through Realtime when the app is open, or as a notification when it is closed.
   Only one call is ever on the screen. While you are on a call (or one is ringing), anything new waits its turn,
   and when you finish Omni-Aura tells you what came in: "Another emergency, sir. ..." */
const LABEL = { checkin: 'Check-in', consent: 'Needs your decision', urgent: 'Urgent message', security: 'Security alert', info: 'Message for you' };
const PRI = { security: 0, urgent: 1, consent: 2, checkin: 3, info: 4 };
const byPriority = (a, b) => (PRI[a.kind] ?? 5) - (PRI[b.kind] ?? 5) || b.id - a.id;
const numeric = (id) => /^\d+$/.test(String(id));

function makeBrief(list) {
  const n = list.length, urgent = list.some((x) => x.urgent || x.kind === 'urgent' || x.kind === 'security');
  const end = (t) => (/[.!?]$/.test(t) ? t : t + '.');
  const lab = (k, i) => { const l = LABEL[k] || 'Message'; return i ? l.charAt(0).toLowerCase() + l.slice(1) : l; };
  const lines = list.map((x, i) => end(`${lab(x.kind, i)}: ${x.say || x.title}`));
  return {
    id: 'brief-' + Date.now(), kind: 'brief', title: 'Next up', queued: list,
    say: `${urgent ? 'Another emergency, sir.' : n === 1 ? 'Another matter, sir.' : `${n} more matters, sir.`} ${lines.join(' Also, ')}`,
  };
}

function makeCtl({ setCall, setPhase, voice, ring }) {
  const seen = new Set(), queue = [], slot = { call: null, phase: 'ring' };
  let timer = 0, inVoice = false, want = null;
  const show = (c, p = 'ring') => { slot.call = c; slot.phase = p; setCall(c); setPhase(p); };
  const setPh = (p) => { slot.phase = p; setPhase(p); };
  const clear = () => { slot.call = null; slot.phase = 'ring'; setCall(null); };
  const busy = () => inVoice || !!(slot.call && (slot.phase === 'ring' || slot.phase === 'talk'));
  const post = (id, what) => { if (numeric(id)) api(`/api/calls/${id}/${what}`, 'POST').catch(() => {}); };

  const present = (c) => {
    show(c, 'ring');
    clearTimeout(timer);
    timer = setTimeout(() => { if (slot.call === c && slot.phase === 'ring') { post(c.id, 'missed'); setPh('missed'); next(false); } }, 45000);
    try { if (ring.current) ring.current(c); } catch { /* ignore */ }
    if (want === c.id) { want = null; accept(c); }
  };
  /* After a conversation, everything that queued up is announced. After a decline, the next one simply rings. */
  function next(talked) {
    if (busy() || !queue.length) return;
    queue.sort(byPriority);
    if (talked) { show(makeBrief(queue.splice(0)), 'talk'); return; }
    present(queue.shift());
  }
  function accept(c) {
    clearTimeout(timer);
    const b = slot.call && slot.call.kind === 'brief' ? slot.call : null;
    if (b) { b.queued.filter((x) => x !== c).forEach((x) => queue.push(x)); try { speechSynthesis.cancel(); } catch { /* ignore */ } }
    post(c.id, 'accept');
    const v = voice.current;
    if (c.kind === 'checkin' && c.ref && c.ref.id && v) { inVoice = true; clear(); v.start({ mode: 'checkin', checkin: { id: c.ref.id, prompt: c.say } }); }
    else if (c.kind === 'consent' && v) { inVoice = true; clear(); v.start({ mode: 'consent', call: c }); }
    else show(c, 'talk');
  }
  function decline(c) { clearTimeout(timer); post(c.id, 'decline'); clear(); next(false); }
  function dismiss() {
    clearTimeout(timer);
    try { speechSynthesis.cancel(); } catch { /* ignore */ }
    const c = slot.call, talked = !!c && (c.kind === 'brief' || slot.phase === 'talk');
    if (c) (c.kind === 'brief' ? c.queued : [c]).forEach((x) => post(x.id, 'decline'));
    clear();
    next(talked);
  }
  function incoming(c) {
    if (!c || seen.has(c.id)) return;
    seen.add(c.id);
    if (busy()) { queue.push(c); return; }
    present(c);
  }
  /* the voice screen reports when a conversation starts and ends */
  function setBusy(b) { inVoice = !!b; if (!b) next(true); }
  async function refresh() {
    try { const l = await api('/api/calls/pending'); (Array.isArray(l) ? [...l].sort(byPriority).reverse() : []).forEach(incoming); } catch { /* the server may be asleep */ }
  }
  return { incoming, accept, decline, dismiss, setBusy, refresh, wantAnswer: (id) => { const n = Number(id); if (slot.call && slot.call.id === n && slot.phase === 'ring') accept(slot.call); else want = n; } };
}

export function useCalls({ active, voice, onRing }) {
  const [call, setCall] = useState(null), [phase, setPhase] = useState('ring');
  const ring = useRef(onRing), ctl = useRef(null);
  ring.current = onRing;
  if (!ctl.current) ctl.current = makeCtl({ setCall, setPhase, voice, ring });
  const c = ctl.current;

  useEffect(() => {
    if (!active) return undefined;
    const q = new URLSearchParams(location.search);
    if (q.get('answer') === '1' && q.get('call')) c.wantAnswer(q.get('call'));
    if (q.get('call')) { try { history.replaceState(null, '', location.pathname); } catch { /* ignore */ } }
    c.refresh();
    /* the Android app was opened from a call notification (Answer, or a tap on the ringing call) */
    const offs = [];
    if (isNative()) {
      const took = (r) => { if (r && r.id) { if (r.answer) c.wantAnswer(r.id); c.refresh(); } };
      Native.launchCall().then(took);
      offs.push(Native.on('callOpened', took));
    }
    const ch = sb.channel('omni-calls').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'calls' }, (p) => { if (p.new && p.new.status === 'ringing') c.incoming(p.new); }).subscribe();
    const vis = () => { if (!document.hidden) c.refresh(); };
    const msg = (e) => { if (e.data && e.data.type === 'omni-call') { if (e.data.answer) c.wantAnswer(e.data.id); c.refresh(); } };
    document.addEventListener('visibilitychange', vis);
    if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', msg);
    /* a safety net in case Realtime is not switched on for the calls table */
    const poll = setInterval(() => { if (!document.hidden) c.refresh(); }, 20000);
    return () => {
      sb.removeChannel(ch); clearInterval(poll); offs.forEach((f) => f());
      document.removeEventListener('visibilitychange', vis);
      if ('serviceWorker' in navigator) navigator.serviceWorker.removeEventListener('message', msg);
    };
  }, [active, c]);

  return { call, phase, accept: c.accept, decline: c.decline, dismiss: c.dismiss, setBusy: c.setBusy };
}

/* ---------- the call screen ---------- */

function Orb({ state = 'speaking' }) {
  const ref = useRef(null);
  useEffect(() => {
    let raf = 0;
    const t0 = performance.now();
    const loop = (now) => {
      if (ref.current) ref.current.style.setProperty('--lvl', (0.4 + 0.34 * Math.sin((now - t0) / 260)).toFixed(3));
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);
  return <LogoLive ref={ref} state={state} />;
}

export function CallLayer({ call, phase, onAccept, onDecline, onDismiss, onOpen }) {
  const banner = typeof localStorage !== 'undefined' && localStorage.callStyle === 'banner';
  const [big, setBig] = useState(false), [sp, setSp] = useState('');
  const talk = phase === 'talk';
  useEffect(() => { setBig(false); }, [call && call.id]);
  useRinger(!!call && phase === 'ring');
  /* the call is read out in the assistant's own voice (see speak.js) */
  useEffect(() => {
    if (!call || !talk) return undefined;
    return sayAloud(call.kind === 'brief' ? call.say : `${hello()}, sir. ${call.say || call.title || ''}`, setSp);
  }, [call, talk]);
  if (!call) return null;
  const label = LABEL[call.kind] || LABEL.info;
  const meta = call.meta || {};

  if (phase === 'missed') {
    return (
      <div className="call-banner missed" role="status">
        <img src="/logo.svg" width="34" height="34" alt="" />
        <span className="cb-txt"><b>Missed call</b><em>Omni-Aura · {label}</em></span>
        <button className="cb-pill" onClick={() => onAccept(call)}>Call back</button>
        <button className="cb-pill ghost" onClick={onDismiss}>Dismiss</button>
      </div>
    );
  }
  if (talk) {
    return (
      <div className="voice call" role="dialog" aria-modal="true" aria-label="Call with Omni-Aura">
        <div className="voice-top"><span className="tag">{call.kind === 'brief' ? 'NEXT UP' : 'ON CALL'}</span></div>
        <div className="voice-stage"><Orb state={sp === 'connecting' ? 'connecting' : 'speaking'} /><p className="readout">{sp === 'connecting' ? 'CONNECTING' : sp === 'device' ? 'OMNI-AURA (PHONE VOICE)' : 'OMNI-AURA'}</p></div>
        <div className="voice-text">
          <p className="va">{call.say || call.title}</p>
          {call.kind === 'brief' && (call.queued || []).filter((q) => q.kind === 'consent' || (q.kind === 'checkin' && q.ref && q.ref.id)).map((q) => (
            <button key={q.id} className="tiny-btn take" onClick={() => onAccept(q)}>Take it: {q.title}</button>
          ))}
          {meta.email && <p className="vy">Account used: {meta.email}</p>}
          {meta.ip && <p className="vy">From: {meta.ip}</p>}
        </div>
        <div className="call-ctl">
          {(call.kind === 'urgent') && <div><button className="callbtn open" onClick={() => { onDismiss(); onOpen('Inbox'); }} aria-label="Open Inbox"><Icon n="inbox" size={26} /></button><span>Inbox</span></div>}
          <div><button className="callbtn decline" onClick={onDismiss} aria-label="End call"><Icon n="phone" size={30} fill="currentColor" /></button><span>End</span></div>
        </div>
      </div>
    );
  }
  if (banner && !big) {
    return (
      <div className="call-banner" role="alertdialog" aria-label="Incoming call from Omni-Aura">
        <button className="cb-main" onClick={() => setBig(true)} aria-label="Show the call screen">
          <img src="/logo.svg" width="38" height="38" alt="" />
          <span className="cb-txt"><b>Omni-Aura is calling</b><em>{label}{call.say ? ' · ' + call.say : ''}</em></span>
        </button>
        <button className="cb-round dec" onClick={() => onDecline(call)} aria-label="Decline"><Icon n="phone" size={20} fill="currentColor" /></button>
        <button className="cb-round acc" onClick={() => onAccept(call)} aria-label="Answer"><Icon n="phone" size={20} fill="currentColor" /></button>
      </div>
    );
  }
  return (
    <div className="voice call" role="alertdialog" aria-modal="true" aria-label="Incoming call from Omni-Aura">
      <div className="voice-top"><span className="tag">INCOMING CALL</span></div>
      <div className="voice-stage">
        <div className="call-orb"><i /><i /><i /><Orb /></div>
        <h1 className="call-name">Omni-Aura</h1>
        <p className="readout">{label.toUpperCase()}</p>
      </div>
      <div className="voice-text">{call.say && <p className="vq">{call.say}</p>}</div>
      <div className="call-ctl">
        <div><button className="callbtn decline" onClick={() => onDecline(call)} aria-label="Decline"><Icon n="phone" size={30} fill="currentColor" /></button><span>Decline</span></div>
        <div><button className="callbtn accept" onClick={() => onAccept(call)} aria-label="Answer"><Icon n="phone" size={30} fill="currentColor" /></button><span>Answer</span></div>
      </div>
    </div>
  );
}
