import { useState } from 'react';
import { Icon } from './ui.jsx';

/* The list of separate chats: its own side panel next to the menu, like a chat app's history. */
const dayLabel = (iso) => {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'Earlier';
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const diff = Math.round((today - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);
  return diff <= 0 ? 'Today' : diff === 1 ? 'Yesterday' : diff < 7 ? 'This week' : diff < 31 ? 'This month' : 'Earlier';
};

export default function ChatBar({ open, onClose, enabled, chats, cur, onOpen, onNew, onRename, onDelete, onCalls }) {
  const [q, setQ] = useState(''), [edit, setEdit] = useState(null), [name, setName] = useState('');
  const needle = q.trim().toLowerCase();
  const list = chats.filter((c) => !needle || String(c.title || '').toLowerCase().includes(needle));
  const groups = [];
  for (const c of list) {
    const label = dayLabel(c.updated_at || c.created_at);
    const g = groups[groups.length - 1];
    if (g && g.label === label) g.items.push(c); else groups.push({ label, items: [c] });
  }
  const save = () => { const id = edit; setEdit(null); if (id != null && name.trim()) onRename(id, name.trim()); };
  return (
    <>
      <div className={'chatbar-scrim' + (open ? ' show' : '')} onClick={onClose} />
      <aside className={'chatbar' + (open ? ' open' : '')} aria-label="Chats" aria-hidden={!open}>
        <div className="chatbar-head"><span>Chats</span><button className="icon" aria-label="Close the chat list" onClick={onClose}><Icon n="x" /></button></div>
        <button className="newchat" onClick={onNew}><Icon n="plus" size={18} /> New chat</button>
        {enabled && chats.length > 7 && <input className="chatq" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search chats" aria-label="Search chats" />}
        <div className="chatlist">
          <button className={'chatrow calls' + (cur === 'calls' ? ' on' : '')} onClick={onCalls}><Icon n="mic" size={16} /><span className="rowmain">Calls</span></button>
          {!enabled && <p className="mute small">Separate chats need one small database step: run <b>supabase/02-chats.sql</b> in Supabase (the steps are in PATCH_NOTES). Until then there is one chat.</p>}
          {enabled && !chats.length && <p className="mute small">Your chats will appear here. Start one with a message.</p>}
          {groups.map((g) => (
            <div key={g.label}>
              <h4>{g.label}</h4>
              {g.items.map((c) => (edit === c.id ? (
                <div key={c.id} className="chatrow editing">
                  <input autoFocus value={name} maxLength={80} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') save(); if (e.key === 'Escape') setEdit(null); }} aria-label="Chat name" />
                  <button className="icon tiny" aria-label="Save the name" onClick={save}><Icon n="check" size={16} /></button>
                </div>
              ) : (
                <div key={c.id} className={'chatrow' + (cur === c.id ? ' on' : '')}>
                  <button className="rowmain" onClick={() => onOpen(c.id)} title={c.title}>{c.title || 'New chat'}</button>
                  {cur === c.id && (
                    <span className="rowtools">
                      <button className="icon tiny" aria-label="Rename this chat" onClick={() => { setName(c.title || ''); setEdit(c.id); }}><Icon n="edit" size={15} /></button>
                      <button className="icon tiny" aria-label="Delete this chat" onClick={() => { if (window.confirm('Delete this chat and its messages? This cannot be undone.')) onDelete(c.id); }}><Icon n="trash" size={15} /></button>
                    </span>
                  )}
                </div>
              )))}
            </div>
          ))}
        </div>
      </aside>
    </>
  );
}
