import { useEffect, useRef, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { API } from './lib.js';
import { bioPrompt, bioStatus, fpLockOn } from './bio.js';
import { Busy, Icon, LogoLive } from './ui.jsx';
import { silentSos } from './sos.js';

export const CONTACT = import.meta.env.VITE_CONTACT_EMAIL || 'servicestribridge@gmail.com';
export const PORTFOLIO = import.meta.env.VITE_PORTFOLIO_URL || 'https://ashraf-abdalla.onrender.com';

async function post(path, body) {
  let r;
  try { r = await fetch(API + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); }
  catch { throw new Error('Cannot reach the server. A sleeping free server can take about a minute to wake. Try again.'); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Request failed (' + r.status + ')');
  return j;
}

/* ---- hearing the passphrase ----
   Chrome can transcribe on the spot. Where it cannot (the installed Android app), a short recording is sent
   to the server, which transcribes it. Either way the server does the comparing, so the phrase is not in this code. */
const SR = typeof window !== 'undefined' && !Capacitor.isNativePlatform() && (window.SpeechRecognition || window.webkitSpeechRecognition);

function listenOnce() {
  return new Promise((resolve, reject) => {
    const r = new SR();
    r.lang = 'en-US'; r.interimResults = false; r.maxAlternatives = 5; r.continuous = false;
    let got = false;
    r.onresult = (e) => { got = true; resolve([...e.results[0]].map((a) => a.transcript).join(' | ')); };
    r.onerror = (e) => {
      if (got) return;
      reject(new Error(e.error === 'not-allowed' ? 'Microphone access was refused. Allow it, or type the passphrase.' : e.error === 'no-speech' ? 'I did not hear anything. Try again.' : 'Voice recognition failed (' + e.error + '). You can type it instead.'));
    };
    r.onend = () => { if (!got) reject(new Error('I did not catch that. Try again.')); };
    try { r.start(); } catch (e) { reject(e); }
  });
}

function wavBase64(chunks, rate) {
  let n = 0;
  chunks.forEach((c) => { n += c.length; });
  const buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  let o = 44;
  for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) v.setInt16(o, Math.max(-1, Math.min(1, c[i])) * 32767, true);
  const u = new Uint8Array(buf);
  let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}

/* Records until you stop talking (at most 6 seconds) and returns it as a WAV, base64. */
async function recordWav(maxMs = 6000) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  const ctx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
  await ctx.resume();
  const src = ctx.createMediaStreamSource(stream), proc = ctx.createScriptProcessor(4096, 1, 1), mute = ctx.createGain();
  mute.gain.value = 0;
  const chunks = [];
  let spoke = false, quiet = 0, ms = 0;
  await new Promise((done) => {
    proc.onaudioprocess = (e) => {
      const f = new Float32Array(e.inputBuffer.getChannelData(0));
      chunks.push(f);
      let s = 0;
      for (let i = 0; i < f.length; i++) s += f[i] * f[i];
      const dt = (f.length / ctx.sampleRate) * 1000;
      ms += dt;
      if (Math.sqrt(s / f.length) > 0.02) { spoke = true; quiet = 0; } else if (spoke) quiet += dt;
      if (ms >= maxMs || (spoke && quiet > 1100 && ms > 1500)) done();
    };
    src.connect(proc); proc.connect(mute); mute.connect(ctx.destination);
  });
  stream.getTracks().forEach((t) => t.stop());
  try { proc.onaudioprocess = null; proc.disconnect(); src.disconnect(); await ctx.close(); } catch { /* ignore */ }
  return wavBase64(chunks, ctx.sampleRate);
}

/* ---------- the lock screen ----------
   Opens with the fingerprint (if you turned that on in Settings, Security) or with the passphrase, said or typed.
   passOn is false when the server has no passphrase: then the fingerprint is the only way in, and signing out is the way out. */
export function Lock({ onOpen, serverError, onRetry, passOn = true, onSignOut }) {
  const [pass, setPass] = useState(''), [busy, setBusy] = useState(false), [hear, setHear] = useState(false), [err, setErr] = useState(serverError || '');
  const [fp, setFp] = useState(false), [fpBusy, setFpBusy] = useState(false);
  const taps = useRef({ n: 0, at: 0 }), alive = useRef(true), auto = useRef(false);
  useEffect(() => () => { alive.current = false; }, []);
  useEffect(() => { setErr(serverError || ''); }, [serverError]);

  const finger = async (quiet) => {
    if (fpBusy || busy || hear) return;
    setFpBusy(true); if (!quiet) setErr('');
    const r = await bioPrompt('Open Omni-Aura');
    if (!alive.current) return;
    if (r.ok) { onOpen(); return; }
    setFpBusy(false);
    if (!r.cancelled || !quiet) setErr(r.cancelled ? 'Fingerprint cancelled.' : r.why + (passOn ? ' You can use the passphrase instead.' : ''));
  };
  /* with the fingerprint switched on, the prompt appears by itself as soon as the lock does */
  useEffect(() => {
    if (!fpLockOn()) return;
    bioStatus().then((st) => {
      if (!alive.current) return;
      setFp(st.ok);
      if (!st.ok) setErr(st.why + (passOn ? ' Use the passphrase.' : ''));
      else if (!auto.current) { auto.current = true; setTimeout(() => { if (alive.current) finger(true); }, 350); }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const check = async (path, body) => {
    setBusy(true); setErr('');
    try {
      const r = await post(path, body);
      if (!alive.current) return;
      if (r.ok) { setPass(''); onOpen(); return; }
      setErr('That is not it. Try again.');
    } catch (e) { if (alive.current) setErr(e.message); }
    if (alive.current) setBusy(false);
  };
  const typed = (e) => { e.preventDefault(); if (pass.trim() && !busy) check('/api/lock/verify', { text: pass }); };
  const speak = async () => {
    if (busy || hear) return;
    setErr(''); setHear(true);
    try {
      if (SR) { const heard = await listenOnce(); if (!alive.current) return; setHear(false); await check('/api/lock/verify', { text: heard }); return; }
      const audio = await recordWav();
      if (!alive.current) return;
      setHear(false);
      await check('/api/lock/voice', { audio });
    } catch (e) {
      if (!alive.current) return;
      setHear(false);
      setErr(e && (e.name === 'NotAllowedError' || e.name === 'SecurityError') ? 'Microphone access was refused. Allow it, or type the passphrase.' : (e && e.message) || 'Could not listen.');
    }
  };
  /* three quick taps on the logo still send the silent SOS, even while the app is locked */
  const logo = () => {
    const s = taps.current, now = Date.now();
    s.n = now - s.at < 650 ? s.n + 1 : 1; s.at = now;
    if (s.n >= 3) { s.n = 0; if (localStorage.sos3 !== '0') silentSos('logo'); }
  };
  const state = hear ? 'listening' : busy || fpBusy ? 'connecting' : 'idle';
  return (
    <div className="lock" role="dialog" aria-modal="true" aria-label="Omni-Aura is locked">
      <div className="lock-in">
        <button className="lock-orb" onClick={logo} aria-label="Omni-Aura" onContextMenu={(e) => e.preventDefault()}><LogoLive state={state} /></button>
        <h1 className="lock-title">Omni-Aura</h1>
        <p className="readout">{hear ? 'LISTENING' : busy ? 'CHECKING' : 'LOCKED'}</p>
        <p className="lock-hint">{hear ? 'Say your passphrase now.' : fp && passOn ? 'Use your fingerprint, or say or type your passphrase.' : fp ? 'Use your fingerprint.' : 'Say your passphrase, or type it.'}</p>
        {fp && <button className="primary big lock-mic" onClick={() => finger(false)} disabled={fpBusy || busy || hear}>{fpBusy ? <Busy label="Waiting for your fingerprint" /> : <><Icon n="finger" size={22} /> Use fingerprint</>}</button>}
        {passOn && (
          <>
            <button className={(fp ? 'ghost ' : 'primary big ') + 'lock-mic'} onClick={speak} disabled={busy || hear || fpBusy}>{hear ? <Busy label="Listening" /> : <><Icon n="mic" size={20} /> Say it</>}</button>
            <form onSubmit={typed} className="lock-form">
              <input type="password" autoComplete="off" autoCapitalize="none" spellCheck="false" placeholder="Or type the passphrase" value={pass} onChange={(e) => setPass(e.target.value)} aria-label="Passphrase" />
              <button className="ghost" type="submit" disabled={busy || hear || fpBusy || !pass.trim()}>{busy && !hear ? <Busy label="Checking" /> : <><Icon n="lock" size={18} /> Unlock</>}</button>
            </form>
          </>
        )}
        {err && <p className="err lock-err" role="alert">{err}</p>}
        {serverError && <button className="link" onClick={onRetry}>Try the server again</button>}
        {!passOn && onSignOut && <button className="link" onClick={onSignOut}>Sign out instead</button>}
      </div>
    </div>
  );
}

/* ---------- strangers land here instead of seeing "invalid login credentials" ---------- */
export function NiceTry({ tried, onBack }) {
  return (
    <div className="nice" role="alert">
      <div className="nice-in">
        <img src="/logo.svg" alt="" width="64" height="64" />
        <h1>Haha, nice try.</h1>
        <p>This is a private system, and that account is not on the list.</p>
        <p>If you think you should have access, contact Ashraf:</p>
        <a className="nice-mail" href={'mailto:' + CONTACT}>{CONTACT}</a>
        <p className="mute">Ashraf Abdalla, full stack developer. His work and other ways to reach him:</p>
        <a className="nice-mail" href={PORTFOLIO} target="_blank" rel="noreferrer">{PORTFOLIO.replace(/^https?:\/\//, '')}</a>
        <p className="mute">Your attempt{tried ? ' with ' + tried : ''} has been logged, and the owner has been told.</p>
        <button className="ghost" onClick={onBack}>Back</button>
      </div>
    </div>
  );
}
