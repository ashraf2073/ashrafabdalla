import { useCallback, useEffect, useRef, useState } from 'react';
import { LocalNotifications } from '@capacitor/local-notifications';
import { GoogleGenAI, Modality } from '@google/genai';
import { API, api, arr } from './lib.js';
import { audioCtx } from './speak.js';
import { Native, isNative, nativeReady } from './native.js';
import { Busy } from './ui.jsx';

const KEY = 'omni.devkey', FLAG = 'omni.standby';

/* ---------- ringing when the Android app is closed ----------
   The phone registers with the server once (it gets a long random key and keeps it), then a small background service in the
   app asks the server every few seconds whether a call is waiting, and rings the phone like a call. No Google services. */
export async function startStandby(renew = false) {
  if (!nativeReady()) throw new Error('This APK was built before the phone parts existed. Run the build-apk workflow again and install the new APK.');
  try { await LocalNotifications.requestPermissions(); } catch { /* the phone may not ask */ }
  let key = localStorage.getItem(KEY);
  if (!key || renew) { const r = await api('/api/device/register', 'POST', { name: 'Android app' }); key = r.key; localStorage.setItem(KEY, key); }
  await Native.standbyStart(API, key, 15);
  localStorage.setItem(FLAG, '1');
}
/* turned off by you (stays off) */
export async function stopStandby() { localStorage.setItem(FLAG, '0'); await Native.standbyStop(); localStorage.removeItem(KEY); }
/* signing out: the phone stops listening and forgets its key, but calls come back by themselves after the next sign-in */
export async function pauseStandby() { if (nativeReady()) { await Native.standbyStop(); } localStorage.removeItem(KEY); }
/* every time the app opens: if calls are meant to be on, make sure they are */
export async function autoStandby() {
  if (!nativeReady() || localStorage.getItem(FLAG) === '0') return;
  const info = await Native.info();
  if (!info) return;
  if (info.standbyOn && info.standbyRunning && !info.lastError && localStorage.getItem(KEY)) return;
  await startStandby(!!info.lastError || !localStorage.getItem(KEY));
}

const when = (iso) => { const d = new Date(iso); return Number.isNaN(d.getTime()) ? '?' : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); };
const ago = (ms) => { if (!ms) return 'never'; const s = Math.round((Date.now() - ms) / 1000); return s < 90 ? s + ' s ago' : s < 5400 ? Math.round(s / 60) + ' min ago' : Math.round(s / 3600) + ' h ago'; };

/* ---------- the voice test: the same connection a live session uses, saying one short sentence ---------- */
async function runVoiceTest(log) {
  const t = await api('/api/live-token', 'POST');
  log(true, `Voice ticket received from the server. Model: ${t.model}, voice: ${t.voice}.`);
  const ctx = audioCtx();
  if (!ctx) { log(false, 'This device has no sound engine inside the app.'); return; }
  try { await ctx.resume(); } catch { /* ignore */ }
  log(ctx.state === 'running', `Sound engine: ${ctx.state} at ${ctx.sampleRate} Hz.`);
  const t0 = Date.now();
  let chunks = 0, first = 0, said = '', next = 0, session = null;
  const play = (data) => {
    const raw = atob(data), n = raw.length >> 1, f = new Float32Array(n);
    for (let i = 0; i < n; i++) { let v = raw.charCodeAt(2 * i) | (raw.charCodeAt(2 * i + 1) << 8); if (v & 0x8000) v -= 0x10000; f[i] = v / 32768; }
    const b = ctx.createBuffer(1, n, 24000); b.copyToChannel(f, 0);
    const s = ctx.createBufferSource(); s.buffer = b; s.connect(ctx.destination);
    next = Math.max(next, ctx.currentTime + 0.03); s.start(next); next += b.duration;
  };
  const res = await new Promise((resolve) => {
    let over = false;
    const end = (r) => { if (!over) { over = true; clearTimeout(to); resolve(r); } };
    const to = setTimeout(() => end({ timeout: true }), 15000);
    (async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: t.token });
        session = await ai.live.connect({
          model: t.model,
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: t.voice || 'Charon' } } },
            outputAudioTranscription: {},
            systemInstruction: 'You are testing the speaker. Reply with exactly these words and nothing else: Voice check complete.',
          },
          callbacks: {
            onopen: () => log(true, `Connected to the voice service after ${Date.now() - t0} ms.`),
            onmessage: (m) => {
              const sc = m.serverContent;
              for (const p of sc?.modelTurn?.parts || []) if (p.inlineData?.data) { if (!chunks) first = Date.now() - t0; chunks += 1; play(p.inlineData.data); }
              if (sc?.outputTranscription?.text) said += sc.outputTranscription.text;
              if (sc?.turnComplete) end({ done: true });
            },
            onerror: (e) => end({ error: (e && e.message) || 'connection error' }),
            onclose: (e) => end({ closed: (e && e.reason) || 'the service closed the connection' }),
          },
        });
        session.sendRealtimeInput({ text: 'Say it now.' });
      } catch (e) { end({ error: e.message }); }
    })();
  });
  try { session && session.close(); } catch { /* ignore */ }
  if (chunks) log(true, `The voice answered: first sound after ${first} ms, ${chunks} pieces${said ? ', words: "' + said.trim() + '"' : ''}. If you heard it, the voice and the speaker work.`);
  else if (res.error) log(false, 'The voice service refused: ' + res.error);
  else if (res.closed) log(false, 'The voice service closed the connection: ' + res.closed);
  else log(false, 'Connected, but no sound came back within 15 seconds. The voice service is not answering (model busy, or a quota limit).');
}

async function micTest(log) {
  let mic;
  try { mic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
  catch (e) { log(false, 'The microphone was refused: ' + (e && e.name === 'NotAllowedError' ? 'allow it for Omni-Aura in the phone settings.' : e.message)); return; }
  const ctx = audioCtx();
  const an = ctx.createAnalyser(); an.fftSize = 512;
  const src = ctx.createMediaStreamSource(mic); src.connect(an);
  const buf = new Uint8Array(an.fftSize);
  let peak = 0;
  log(null, 'Speak now for three seconds...');
  await new Promise((done) => {
    const t0 = Date.now();
    const id = setInterval(() => {
      an.getByteTimeDomainData(buf);
      let s = 0; for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; s += v * v; }
      peak = Math.max(peak, Math.sqrt(s / buf.length));
      if (Date.now() - t0 > 3000) { clearInterval(id); done(); }
    }, 50);
  });
  try { src.disconnect(); } catch { /* ignore */ }
  mic.getTracks().forEach((t) => t.stop());
  const pct = Math.round(Math.min(1, peak * 4) * 100);
  if (pct < 4) log(false, `The microphone is open but heard almost nothing (level ${pct}%). It may be muted, covered, or another app is using it.`);
  else log(true, `The microphone works (loudest level ${pct}%).`);
}

const Row = ({ ok, children }) => <p className={ok === false ? 'err' : 'mute'}>{ok === true ? '✓ ' : ok === false ? '✗ ' : '· '}{children}</p>;

export default function PhoneParts() {
  const [info, setInfo] = useState(null), [diag, setDiag] = useState(null), [msg, setMsg] = useState(''), [busy, setBusy] = useState(''), [lines, setLines] = useState([]);
  const alive = useRef(true);
  const native = isNative();
  const refresh = useCallback(async () => {
    if (nativeReady()) { const i = await Native.info(); if (alive.current) setInfo(i); }
    try { const d = await api('/api/diag/status'); if (alive.current) setDiag(d); } catch (e) { if (alive.current) setDiag({ error: e.message }); }
  }, []);
  useEffect(() => { alive.current = true; refresh(); const id = setInterval(refresh, 10000); return () => { alive.current = false; clearInterval(id); }; }, [refresh]);
  const log = (ok, text) => setLines((l) => [...l, { ok, text }]);
  const run = async (name, fn) => { setBusy(name); setMsg(''); try { await fn(); } catch (e) { setMsg(e.message || 'Failed.'); } setBusy(''); refresh(); };

  const calls = arr(diag && diag.calls);
  const ck = diag && diag.cron && diag.cron.checkin;
  const problems = [];
  if (diag && !diag.error) {
    if (!diag.env.cronSecret) problems.push('The server has no CRON_SECRET, so it refuses its scheduled jobs (check-ins and mail checks).');
    if (!ck) problems.push('The server has never received the check-in trigger. The scheduled job that should call /cron/checkin every 3 hours is not set up, or is not reaching the server.');
    else if (Date.now() - Date.parse(ck.at) > 4.5 * 3600e3) problems.push(`The last check-in trigger reached the server ${ago(Date.parse(ck.at))} (${ck.result}). It should arrive every 3 hours, so the scheduled job has stopped or is failing.`);
    if (diag.quiet && diag.quiet.active) problems.push(`Quiet hours are on right now (it is ${diag.hourEAT}:00 EAT, quiet from ${diag.quiet.start}:00 to ${diag.quiet.end}:00), so calls are held back.`);
    if (diag.focus && diag.focus.active) problems.push('Focus mode is on, so only urgent calls get through.');
    if (!diag.env.geminiKey) problems.push('The server has no Gemini key.');
    if (!diag.pushDevices && !diag.nativeDevices) problems.push('No phone or browser is registered to be called. In a browser, turn on direct calls under Calls below; in the Android app, turn on "Calls when the app is closed".');
  }

  return (
    <>
      <section>
        <h2>Voice and calls check</h2>
        <p className="mute">If it stops answering or stops calling, this shows where the chain breaks.</p>
        {!diag && <p className="mute">Asking the server...</p>}
        {diag && diag.error && <p className="err">The server could not be reached: {diag.error}</p>}
        {diag && !diag.error && (
          <>
            {!problems.length && <Row ok>Nothing is blocking calls on the server.</Row>}
            {problems.map((p, i) => <Row key={i} ok={false}>{p}</Row>)}
            <Row ok={null}>Check-in trigger: {ck ? `${when(ck.at)}, ${ck.result}` : 'never received'}.</Row>
            <Row ok={null}>Registered to be called: {diag.pushDevices} browser{diag.pushDevices === 1 ? '' : 's'}, {diag.nativeDevices} Android phone{diag.nativeDevices === 1 ? '' : 's'}{diag.nativeDevices ? (diag.nativeOnline ? ' (listening now)' : ' (not listening right now)') : ''}.</Row>
            {calls.length > 0 && <p className="mute small">Latest calls: {calls.map((c) => `${when(c.created_at)} ${c.kind} ${c.status}${c.via ? ' via ' + c.via : ''}`).join('; ')}.</p>}
            <p className="mute small">Voice model: {diag.env.liveModel}, voice {diag.env.voice}.</p>
          </>
        )}
        <div className="row">
          <button disabled={!!busy} onClick={() => run('call', async () => { const r = await api('/api/calls/test', 'POST'); setMsg(r && r.via ? 'A test call was placed (via ' + r.via + ').' : 'A test call was placed.'); })}>{busy === 'call' ? <Busy label="Calling" /> : 'Place a test call'}</button>
        </div>
      </section>

      <section>
        <h2>Test the voice</h2>
        <div className="row">
          <button disabled={!!busy} onClick={() => run('voice', async () => { setLines([]); await runVoiceTest(log); })}>{busy === 'voice' ? <Busy label="Testing" /> : 'Test voice reply'}</button>
          <button className="ghost" disabled={!!busy} onClick={() => run('mic', async () => { setLines([]); await micTest(log); })}>{busy === 'mic' ? <Busy label="Listening" /> : 'Test microphone'}</button>
        </div>
        {lines.map((l, i) => <Row key={i} ok={l.ok}>{l.text}</Row>)}
        {msg && <p className="err" role="status">{msg}</p>}
      </section>

      {native && (
        <section>
          <h2>Android: calls and sharing</h2>
          {!nativeReady() && <p className="err">This APK was built before the phone parts existed. Run the build-apk workflow once more and install the new APK. Until then Omni-Aura cannot ring when the app is closed or share the screen over other apps.</p>}
          {nativeReady() && info && (
            <>
              <Row ok={info.standbyOn && info.standbyRunning}>Calls when the app is closed: {info.standbyOn ? (info.standbyRunning ? `on, last contact with the server ${ago(info.lastOk)}` : 'switched on, but the background service is not running') : 'off'}.</Row>
              {info.lastError && <Row ok={false}>{info.lastError}</Row>}
              <div className="row">
                {info.standbyOn
                  ? <button className="ghost" disabled={!!busy} onClick={() => run('off', async () => { await stopStandby(); setMsg('Calls when the app is closed are off.'); })}>Turn off</button>
                  : <button disabled={!!busy} onClick={() => run('on', async () => { await startStandby(true); setMsg('On. Omni-Aura will ring this phone like a call.'); })}>Turn on</button>}
                <button className="ghost" disabled={!!busy} onClick={() => run('ring', async () => { await Native.testRing(); setMsg('A test call rings in 8 seconds. Lock the phone or open another app now.'); })}>Ring test</button>
              </div>
              <p className="mute small">The phone must allow four things for calls to reach you reliably:</p>
              <Row ok={info.notifications}>Notifications{!info.notifications && <> <button className="link sm" onClick={() => run('n', async () => { await LocalNotifications.requestPermissions(); const i = await Native.info(); if (i && !i.notifications) await Native.openAppSettings(); })}>Allow</button></>}</Row>
              <Row ok={info.battery}>Unrestricted battery use (so the phone does not put the listener to sleep){!info.battery && <> <button className="link sm" onClick={() => Native.requestBatteryExemption()}>Allow</button></>}</Row>
              <Row ok={info.fullScreen}>Full-screen call over the lock screen{!info.fullScreen && <> <button className="link sm" onClick={() => Native.openFullScreenSettings()}>Allow</button></>}</Row>
              <Row ok={info.overlay}>Display over other apps (the small bubble while sharing your screen){!info.overlay && <> <button className="link sm" onClick={() => Native.openOverlaySettings()}>Allow</button></>}</Row>
              <p className="mute small">Some phones (Xiaomi, Oppo, Vivo, Samsung and others) also have their own "autostart" or "battery saver" lists: if calls stop coming, add Omni-Aura there as well.</p>
            </>
          )}
        </section>
      )}
    </>
  );
}
