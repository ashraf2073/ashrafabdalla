import { useCallback, useEffect, useState } from 'react';
import { api, arr } from './lib.js';
import { Busy, Icon, Loading } from './ui.jsx';

/* Train: Ashraf tells Omni-Aura how things work. Every lesson is read into every chat and every call from then on. */
export default function Train() {
  const [rows, setRows] = useState(null), [title, setTitle] = useState(''), [body, setBody] = useState(''), [msg, setMsg] = useState(''), [busy, setBusy] = useState(false);
  const [edit, setEdit] = useState(null), [eTitle, setETitle] = useState(''), [eBody, setEBody] = useState('');
  const load = useCallback(async () => { try { setRows(arr(await api('/api/lessons'))); } catch (e) { setMsg(e.message); setRows([]); } }, []);
  useEffect(() => { load(); }, [load]);

  const teach = async () => {
    if (!body.trim() || busy) return;
    setBusy(true); setMsg('');
    try { await api('/api/lessons', 'POST', { title: title.trim(), body: body.trim() }); setTitle(''); setBody(''); setMsg('Learned. It will follow this from now on.'); await load(); }
    catch (e) { setMsg(e.message); }
    setBusy(false);
  };
  const saveEdit = async () => {
    if (edit == null || !eBody.trim()) return;
    try { await api('/api/lessons/' + edit, 'PUT', { title: eTitle.trim(), body: eBody.trim() }); setEdit(null); setMsg('Lesson updated.'); await load(); } catch (e) { setMsg(e.message); }
  };
  const drop = async (id) => {
    if (!window.confirm('Forget this lesson?')) return;
    try { await api('/api/lessons/' + id, 'DELETE'); setMsg('Forgotten.'); await load(); } catch (e) { setMsg(e.message); }
  };
  const bad = /could not|failed|error|empty|first|200|unknown|no longer/i.test(msg);

  return (
    <>
      <section>
        <h2>Train Omni-Aura</h2>
        <p className="mute">You made Omni-Aura, so you are the one who teaches it. Tell it how things work: how you like things done, what names, places and terms mean, how your work and your day run, what to do when. Every lesson is read into every chat and every call from then on, and it follows them over its own guesses.</p>
        <p className="mute">You can also teach it by voice or in the chat: say "I am teaching you: ..." and it will file the lesson here.</p>
        <label htmlFor="lt">Short name (optional)</label>
        <input id="lt" value={title} maxLength={80} onChange={(e) => setTitle(e.target.value)} placeholder="For example: How I handle bills" />
        <label htmlFor="lb">How does it work?</label>
        <textarea id="lb" rows={5} maxLength={2000} value={body} onChange={(e) => setBody(e.target.value)} placeholder={'For example: "Bills are due on the 5th. Rent goes first, then electricity. Never remind me about bills before 9am. When I say the shop I mean the hardware shop in Kyumbi."'} />
        <button disabled={busy || !body.trim()} onClick={teach}>{busy ? <Busy label="Teaching" /> : 'Teach it'}</button>
        {msg && <p className={bad ? 'err' : 'mute'} role="status">{msg}</p>}
      </section>
      <section>
        <h2>What it has learned{rows ? ` (${rows.length})` : ''}</h2>
        {!rows && <Loading />}
        {rows && !rows.length && <p className="mute">Nothing yet. Teach it something above.</p>}
        {(rows || []).map((l) => (
          <div key={l.id} className="lesson">
            {edit === l.id ? (
              <>
                <input value={eTitle} maxLength={80} onChange={(e) => setETitle(e.target.value)} aria-label="Lesson name" />
                <textarea rows={5} maxLength={2000} value={eBody} onChange={(e) => setEBody(e.target.value)} aria-label="Lesson" />
                <div className="row"><button onClick={saveEdit} disabled={!eBody.trim()}>Save</button><button className="ghost" onClick={() => setEdit(null)}>Cancel</button></div>
              </>
            ) : (
              <>
                <p><b>{l.title}</b></p>
                <p className="pre">{l.body}</p>
                <div className="row">
                  <button className="ghost" onClick={() => { setEdit(l.id); setETitle(l.title); setEBody(l.body); }}><Icon n="edit" size={15} /> Edit</button>
                  <button className="ghost" onClick={() => drop(l.id)}><Icon n="trash" size={15} /> Forget</button>
                </div>
              </>
            )}
          </div>
        ))}
      </section>
    </>
  );
}
