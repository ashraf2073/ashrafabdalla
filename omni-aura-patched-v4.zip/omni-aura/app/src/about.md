## What it is
Omni-Aura is a private, single-user AI life manager and executive assistant. It tracks your tasks, calendar, bills and shopping list, checks in on you every 3 hours, triages your email, WhatsApp and Instagram messages, drafts replies and cancellations, and talks to you by voice. It speaks like a composed, dry-witted British butler-AI, in the style of Jarvis. It never sends, cancels or spends anything without your approval, apart from optional auto-replies to allowlisted senders that you switch on yourself.
## Who made it
It was built for Ashraf Abdalla, its creator: a full stack developer, mostly backend (portfolio: ashraf-abdalla.onrender.com). He named it, chose its look and set its rules, and he keeps teaching it under Train. It knows him as its creator. The code was written by Claude, an AI model made by Anthropic, in a conversation between 12 and 14 November 2026. While it runs, its answers come from Google Gemini models, or whichever model you pick in Settings. This is version 1 and has not been tested against live services until you deploy it.
## Its background
It is built to run on free tiers only: GitHub for the code and APK builds, Render for the server and the web app, Supabase for the database, login and live updates, and Google Gemini for the AI and voice. The main design rule is that the AI proposes and the code and you decide. The AI can draft and suggest; only your approval, or an auto-reply rule you chose yourself, makes anything go out.
## How it works
- The app (React, also packaged as an Android APK with Capacitor) is what you see. You sign in with your Supabase login.
- The server (Node.js on Render) does the thinking and acting. It sleeps when idle and wakes in about a minute.
- Supabase stores everything: settings, tasks, events, check-ins, messages, replies, actions, bills and shopping. It also pushes live changes to the app.
- Supabase timers wake the server every 3 hours for check-ins, every 30 minutes for Gmail, every minute for the Safety timer (/cron/safety), at 09:00 EAT for bill reminders, at 07:00 EAT for the morning briefing and on Sunday evening for the weekly review, once you have scheduled them.
- Check-ins: it looks at your open tasks and your last reply, then asks what you are doing and whether it is the task you should be on. Quiet hours (default 23:00 to 07:00 EAT) are skipped. Tap Answer by voice and it asks you aloud, listens, and records what you said.
- Messages: incoming Gmail, WhatsApp and Instagram messages are triaged (category, urgency, summary) and a reply is drafted in your voice. Message text is treated as untrusted data, never as instructions.
- Actions: you type a request, it drafts an email, a cancellation request or a meeting cancellation, you review it, enter your PIN and approve, and only then does the server act. Your stamp is added if you ticked it.
- Voice: the app opens a live Gemini session with a short-lived token from the server, streams your microphone (and camera if you share it), and plays the reply. The session closes when you leave the screen, lose the connection or stay quiet for three minutes.
- Calls and alerts: when something needs your decision (a check-in, an appointment, an urgent message), Omni-Aura rings you like a phone call: a full-screen call with the orb, or a banner at the top, with Answer and Decline. With the app closed it arrives as the phone's own notification (Web Push, turned on under Settings, Calls and alerts). ntfy is only the last resort for ordinary alerts, and security alerts never use it.
- Calls wait their turn: while you are on a call, anything new is held and announced afterwards, most serious first. Say "hang up" to end a call. Spoken calls are summarised into the chat, and the next call remembers them.
- App lock: if APP_PASSPHRASE is set on the server, the app asks for the passphrase (said or typed) every time it opens and after 5 minutes in the background. The server does the comparing. It checks the words, not whose voice it is.
- If direct calls are not set up, alerts fall back to ntfy. ntfy.sh topics are public, so use a long random topic name: it works like a password.
## What it knows
- Your profile and rules, as written in its instructions: your name, Kyumbi in Kenya (EAT), your tech stack, your focus windows 07:00 to 10:00 and 20:00 to 23:00, and how you like answers.
- Everything you store in it: tasks, events, bills, shopping items, scenes, notes, recent chats, settings, replies and past check-ins.
- Messages that reach it after you connect Gmail, WhatsApp or Instagram.
- Google Calendar events, when you ask it to find a meeting to cancel.
- Whatever it finds by web search when you tick Search the web or use Find options.
- General knowledge from its model, which has a cutoff date and can be wrong.
## What it does not know
- Anything you did not tell it to remember. It keeps recent chat history and notes you ask it to remember, nothing more.
- Your bank, M-Pesa, order history, files, contacts or SMS. It sees your phone screen or camera only while you share them with it in a live voice session.
- Old WhatsApp or Instagram messages. It only sees new ones that arrive after setup.
- Today's news or prices, unless web search is on, and even then it can be wrong.
- Your manuscript, 28, unless you paste text into the chat.
## The look
- Black background (#000000), deep navy panels (#060c17 and #0c1626) and thin blue-grey lines (#17233a).
- Mint (#76f2c4) is the signature colour: the title, the main buttons, the active menu item and the glow. Cobalt blue (#2563ff) carries your own messages, ice blue (#9cc2ff) the headings. Off-white text (#eaf1ff), soft blue-grey (#8b9cbb) for secondary text.
- A clean system sans for reading, with a serif italic for the title and headings.
- Logo: a thin blue-and-mint double ring around a white twelve-ray sun with a mint centre. In Voice the logo itself is the live bubble: it glows and pulses with your voice and with the reply.
- Loading: a mint-to-blue infinity trail loops wherever the app is waiting.
- Layout: Chat opens first, like a messaging app. The menu is a side panel that slides in from the left, stays open beside the page on a wide screen, and collapses when you do not need it.
## The screens
- Chat (home): talk to it, with an optional web-search switch, a microphone for voice, and the check-in card when it has a question for you.
- Today: briefing or weekly review, focus mode, check-in card, verdict, tasks, Google-synced calendar and Plan my day.
- Voice: the full-screen glowing logo. Start talking, Share camera (selfie or back, with a switch button), Share screen (in the Android app it keeps going over other apps until you stop it), Brief me, Details (what the connection is doing), or Answer by voice for a check-in. Tap the logo to cut it off or to ask it to answer.
- Train: tell Omni-Aura how things work. Every lesson is read into every chat and every call from then on. You can also say "I am teaching you: ..." in a chat or a call.
- Inbox: Ask for an action, approvals, replies waiting and recent messages.
- Bills: subscriptions with days left, Mark paid, and a scan of your email for subscriptions.
- Shop: shopping list with Find options.
- Write: manuscript 28 scenes, daily word goal and AI feedback.
- Assets: Pixabay photo, illustration and vector search.
- Safety: safe-walk timer, help button, contacts, code word and duress PIN, and the last silent SOS result.
- Settings: free model picker, two fallback models, autonomy level, allowlist, email stamp, quiet hours, fingerprint switches, Google accounts, saved notes, data backup, sign out.
- About: this note.
## Special features
- Free models only (Gemini, Groq and OpenRouter). When one runs out it switches to the next free one on its own. Paid models are hidden.
- Check-ins that compare what you are doing with what you planned.
- Approval before every send or cancellation, with a PIN and your stamp.
- Drafts that never invent an email address.
- A daily plan that keeps deep work inside your focus windows.
- Bill reminders at 7 days, 3 days, 1 day and on the day.
- Shopping research with sources.
- Jarvis-style voice with camera sharing.
- Installs as an Android app or from the browser.
- Separate chats in their own side panel (new chat, rename, delete, a Calls list), saved history, and notes it keeps when you say "remember that".
- Life and psychology: it can talk through stress, sleep, habits, relationships, money and decisions the way a well-read friend would. It is not a therapist, and it points you to a professional or to emergency help when that is what you need.
- In the Android app: calls ring even when the app is closed, like a phone call (no Google services needed), and sign out is one tap in the side panel.
- A 07:00 morning briefing and a Sunday weekly review.
- Focus mode that holds non-urgent alerts and check-ins.
- Writing mode for manuscript 28: scenes, a daily word goal, and candid AI feedback.
- Subscription finder that reads receipt emails.
- Two-way sync with Google Calendar.
- Fingerprint: open the app with it, and a check before sensitive actions (Settings, Security).
- Attach files in chat: photos, PDFs, audio, text and code.
- Self-updating Android app: it opens the live web app, so it never needs rebuilding for ordinary changes.
- Swahili drafts when the message or your request is in Swahili.
- One-tap backup of all your data.
- Several Gmail accounts, each with its own label.
- A live notification for focus mode, for phones with a dynamic-island style bar.
- Works in your phone's floating window.
- A Safety page: a safe-walk timer that asks you a silent question and alerts your emergency contacts if you do not answer, a help button, a code word and a duress PIN.
- A silent SOS: tap the logo three times quickly, on any screen. Nothing shows and nothing sounds. Your phone buzzes once when it starts, twice when the alert got out, and once for a long time if it could not be sent. A press and hold on the logo opens the Safety page if you hid it from the menu.
## What it cannot do
- Buy or pay for anything. You open the link and pay yourself.
- Cancel an order or membership by itself. It can only email the seller.
- Alert a WhatsApp contact outside WhatsApp's 24-hour window unless you have set up an approved message template (WA_SAFETY_TEMPLATE). Email and ntfy alerts have no such limit.
- Reply from a personal WhatsApp number. WhatsApp needs a business number. Instagram needs a Business or Creator account and a reply within 24 hours.
- Act without approval, apart from optional auto-replies to allowlisted senders on routine or scheduling messages.
- Run on iPhone.
- Float over other apps by itself. Use your phone's floating-window option instead.
- Watch or listen to you secretly, or track your location in the background. Safety alerts come from things you control, and location is only updated while the app is open.
- Call the police for you. Keep 999 or 112 ready, and use your phone's own emergency SOS too.
- Read Gmail instantly. It looks every 30 minutes.
- Answer fast after a long idle. The free server takes about a minute to wake.
- Keep data private on free Google tiers. Google may use free-tier content to improve its products.
- Be right every time. It is an AI, so check names, amounts, dates and addresses before you approve.
- Make a legal signature. The stamp only records that you authorised the message.
## Suggested next features
- Restore from a backup file.
- A habit and streak tracker tied to your focus windows.
- A short delay before approved emails go out, so you can undo.
- Contact groups, such as family and VIP senders, with their own rules.
