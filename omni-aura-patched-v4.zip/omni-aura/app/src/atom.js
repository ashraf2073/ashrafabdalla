/* The loader: fine layered strands flowing along an infinity curve, with an atom at the head of each flow.
   Plain canvas code with no React in it, so it can be reused and checked on its own.
   Everything is drawn relative to a 340 px wide loader and scales with the canvas. */
const TAU = Math.PI * 2;
export const MINT_RGB = [118, 242, 196];
export const BLUE_RGB = [37, 99, 255];
const ICE_RGB = [156, 194, 255];
const mix = (a, b, f) => [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
const rgba = (c, a) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${Math.max(0, Math.min(1, a)).toFixed(3)})`;

/* One strand of the infinity (layer k of K) at position u. The layers differ a little in size and phase,
   so together they weave a fine ribbon that crosses itself in the middle. */
function pt(u, k, K, cx, cy, A, B, nest, spread) {
  const s = K > 1 ? k / (K - 1) : 0.5;
  const f = 1 - nest * s;
  return [cx + A * f * Math.sin(u), cy + B * f * Math.sin(2 * u + (s - 0.5) * 2 * spread)];
}

function atom(ctx, x, y, sc, t, j, ink, full) {
  const R = 12.5 * sc;
  if (!ink) {
    const g = ctx.createRadialGradient(x, y, 0, x, y, R * 1.25);
    g.addColorStop(0, rgba(MINT_RGB, 0.6)); g.addColorStop(0.45, rgba(MINT_RGB, 0.18)); g.addColorStop(1, rgba(MINT_RGB, 0));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, R * 1.25, 0, TAU); ctx.fill();
  }
  if (full) {
    for (let i = 0; i < 3; i++) {
      ctx.save(); ctx.translate(x, y); ctx.rotate((i * Math.PI) / 3 + t * 0.8 + j * 1.3);
      ctx.strokeStyle = ink ? rgba(ink, 0.55) : rgba(ICE_RGB, 0.65); ctx.lineWidth = Math.max(0.6, 0.95 * sc);
      ctx.beginPath(); ctx.ellipse(0, 0, R, R * 0.36, 0, 0, TAU); ctx.stroke();
      const a = t * (3.1 + i * 0.9) + j * 2 + i * 2.1;
      ctx.fillStyle = ink ? rgba(ink, 1) : i % 2 ? rgba(MINT_RGB, 1) : 'rgba(255,255,255,.95)';
      ctx.beginPath(); ctx.arc(R * Math.cos(a), R * 0.36 * Math.sin(a), Math.max(0.9, 1.6 * sc), 0, TAU); ctx.fill();
      ctx.restore();
    }
  }
  ctx.fillStyle = ink ? rgba(ink, 1) : rgba(MINT_RGB, 1);
  ctx.beginPath(); ctx.arc(x, y, Math.max(1.4, (full ? 3.1 : 4) * sc), 0, TAU); ctx.fill();
}

/* Draws one frame. t is seconds. o.grow (0 to 1) is the load-in. o.ink is an [r,g,b] for use inside buttons. */
export function drawAtomLoader(ctx, W, H, t, o = {}) {
  const { layers = 8, atoms = 3, chunks = 14, full = true, ink = null, grow = 1, nest = 0.32, spread = 0.3, speed = 1.9 } = o;
  const sc = W / 340;
  const pad = (full ? 18 : 4) * sc + 1;
  const cx = W / 2, cy = H / 2, A = W / 2 - pad, B = H / 2 - pad * 0.9;
  ctx.clearRect(0, 0, W, H);
  ctx.save();
  ctx.lineCap = 'butt'; ctx.lineJoin = 'round';
  ctx.globalCompositeOperation = ink ? 'source-over' : 'lighter';
  const head = t * speed, L = (TAU / atoms) * 1.12 * grow;
  for (let j = 0; j < atoms; j++) {
    const h0 = head + (j * TAU) / atoms;
    for (let k = 0; k < layers; k++) {
      const lag = k * 0.05;
      for (let c = 0; c < chunks; c++) {
        const f0 = c / chunks, f1 = (c + 1) / chunks;
        const u0 = h0 - lag - L * (1 - f0), u1 = h0 - lag - L * (1 - f1);
        const a = Math.pow(f1, 1.7) * (ink ? 0.95 : 0.62) * grow;
        ctx.strokeStyle = ink ? rgba(ink, a) : rgba(mix(BLUE_RGB, MINT_RGB, f1), a);
        ctx.lineWidth = Math.max(0.7, (0.55 + 0.7 * f1) * sc);
        ctx.beginPath();
        for (let q = 0; q <= 3; q++) {
          const [x, y] = pt(u0 + ((u1 - u0) * q) / 3, k, layers, cx, cy, A, B, nest, spread);
          if (q) ctx.lineTo(x, y); else ctx.moveTo(x, y);
        }
        ctx.stroke();
      }
    }
  }
  /* the atoms ride the middle strand, ahead of the flow they lead */
  ctx.globalCompositeOperation = 'source-over'; ctx.lineCap = 'round';
  for (let j = 0; j < atoms; j++) {
    const [x, y] = pt(head + (j * TAU) / atoms, (layers - 1) / 2, layers, cx, cy, A, B, nest, spread);
    ctx.globalAlpha = Math.min(1, grow * 1.4);
    atom(ctx, x, y, sc, t, j, ink, full);
  }
  ctx.restore();
}

/* Starts the animation on a canvas. Returns a function that stops it. */
export function runAtomLoader(canvas, W, H, o = {}) {
  const dpr = Math.min(2.5, (typeof devicePixelRatio === 'number' && devicePixelRatio) || 1);
  canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
  canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  const calm = typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (calm) { drawAtomLoader(ctx, W, H, 1.1, { ...o, grow: 1 }); return () => {}; }
  let raf = 0, t0 = 0;
  const frame = (now) => {
    if (!t0) t0 = now;
    const t = (now - t0) / 1000;
    drawAtomLoader(ctx, W, H, t, { ...o, grow: Math.min(1, t / 1.1) });
    raf = requestAnimationFrame(frame);
  };
  raf = requestAnimationFrame(frame);
  return () => cancelAnimationFrame(raf);
}
