/* Fingerprint checks.
   In the Android app this uses the phone's own fingerprint prompt (the BiometricAuthNative plugin, which the APK build adds).
   In a browser it uses the phone's fingerprint through WebAuthn, where the browser allows it.
   Two switches, both kept on this device only (Settings, Security):
     fp      ask for the fingerprint before sensitive actions (sending, auto-send rules, backups, emergency contacts ...)
     fpLock  open the app with the fingerprint instead of typing the passphrase */
import { Capacitor, registerPlugin } from '@capacitor/core';

const Bio = registerPlugin('BiometricAuthNative');
const ls = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
};
const native = () => { try { return Capacitor.isNativePlatform(); } catch { return false; } };

export const fpOn = () => ls.get('fp') === '1';
export const fpLockOn = () => ls.get('fpLock') === '1';
export const setFp = (on) => ls.set('fp', on ? '1' : '0');
export const setFpLock = (on) => ls.set('fpLock', on ? '1' : '0');

const WHY = {
  biometryNotEnrolled: 'No fingerprint is saved on this phone. Add one in Android Settings, Security, then try again.',
  passcodeNotSet: 'Set a screen lock on this phone first (Android Settings, Security).',
  biometryLockout: 'Too many wrong tries. Wait a little, then try again.',
  biometryNotAvailable: 'This phone cannot use a fingerprint right now.',
  authenticationFailed: 'That fingerprint was not recognised.',
};
const CANCEL = /^(userCancel|appCancel|systemCancel|userFallback)$/;
const why = (code, msg) => WHY[code] || (msg && String(msg).slice(0, 160)) || 'The fingerprint check did not work.';

const b64u = {
  enc: (u8) => btoa(String.fromCharCode(...u8)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''),
  dec: (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((s.length + 3) % 4)), (c) => c.charCodeAt(0)),
};
const webReady = async () => {
  try { return !!(window.PublicKeyCredential && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable && await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()); } catch { return false; }
};

/* What this device can do right now: { ok, mode: 'native' | 'web', why } */
export async function bioStatus() {
  if (native()) {
    if (!Capacitor.isPluginAvailable('BiometricAuthNative')) return { ok: false, mode: 'native', why: 'This build of the Android app has no fingerprint support. Build the APK once more with the updated workflow (new installs keep updating themselves after that).' };
    try {
      const r = await Bio.checkBiometry();
      return r && r.isAvailable ? { ok: true, mode: 'native' } : { ok: false, mode: 'native', why: why(r && r.code, r && r.reason) };
    } catch (e) { return { ok: false, mode: 'native', why: why(e && e.code, e && e.message) }; }
  }
  return (await webReady()) ? { ok: true, mode: 'web' } : { ok: false, mode: 'web', why: 'This browser has no fingerprint sensor it can use. The Android app can.' };
}

async function webEnroll() {
  const cred = await navigator.credentials.create({ publicKey: {
    challenge: crypto.getRandomValues(new Uint8Array(32)),
    rp: { name: 'Omni-Aura' },
    user: { id: crypto.getRandomValues(new Uint8Array(16)), name: 'owner', displayName: 'Owner' },
    pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
    authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'required', residentKey: 'discouraged' },
    timeout: 60000,
  } });
  ls.set('fpCred', b64u.enc(new Uint8Array(cred.rawId)));
}
async function webAsk() {
  const id = ls.get('fpCred');
  if (!id) throw Object.assign(new Error('Fingerprint is not set up in this browser. Turn it on in Settings, Security.'), { code: 'biometryNotEnrolled' });
  await navigator.credentials.get({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), allowCredentials: [{ type: 'public-key', id: b64u.dec(id) }], userVerification: 'required', timeout: 60000 } });
}

/* Shows the fingerprint prompt. Returns { ok, cancelled, why }. */
export async function bioPrompt(reason = 'Confirm it is you', { enroll = false } = {}) {
  try {
    if (native()) {
      if (!Capacitor.isPluginAvailable('BiometricAuthNative')) return { ok: false, why: (await bioStatus()).why };
      await Bio.internalAuthenticate({ reason, cancelTitle: 'Cancel', allowDeviceCredential: false, androidTitle: 'Omni-Aura', androidSubtitle: reason });
      return { ok: true };
    }
    if (enroll) await webEnroll();
    await webAsk();
    return { ok: true };
  } catch (e) {
    const code = e && (e.code || e.errorCode);
    if (CANCEL.test(code || '') || (e && e.name === 'NotAllowedError')) return { ok: false, cancelled: true, why: 'Cancelled.' };
    return { ok: false, why: why(code, e && e.message) };
  }
}

/* Before a sensitive action. Returns '' when it may go ahead, or the sentence to show when it may not. */
export async function guard(reason) {
  if (!fpOn()) return '';
  const r = await bioPrompt(reason);
  if (r.ok) return '';
  if (r.cancelled) return 'Fingerprint cancelled. Nothing was changed.';
  return r.why + ' You can turn the fingerprint check off in Settings, Security.';
}
export async function biometricOk(reason) { return !(await guard(reason)); }

/* Turning a switch on proves it works first, so it can never lock you out by surprise. */
export async function enableFingerprint(kind, reason) {
  const st = await bioStatus();
  if (!st.ok) return { ok: false, why: st.why };
  const r = await bioPrompt(reason, { enroll: true });
  if (!r.ok) return { ok: false, why: r.cancelled ? 'Cancelled. The setting stays off.' : r.why };
  (kind === 'lock' ? setFpLock : setFp)(true);
  return { ok: true };
}
/* Turning one off asks for the fingerprint, unless the phone cannot do one at all. */
export async function disableFingerprint(kind, reason) {
  const st = await bioStatus();
  if (st.ok) {
    const r = await bioPrompt(reason);
    if (!r.ok) return { ok: false, why: r.cancelled ? 'Cancelled. The setting stays on.' : r.why };
  }
  (kind === 'lock' ? setFpLock : setFp)(false);
  return { ok: true };
}
