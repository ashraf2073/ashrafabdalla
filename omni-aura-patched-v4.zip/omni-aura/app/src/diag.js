/* What this copy of the app is, so the Android build can be checked on the phone itself (Settings, This app). */
import { Capacitor } from '@capacitor/core';
import { API } from './lib.js';

export async function buildInfo() {
  const native = Capacitor.isNativePlatform();
  const tag = document.querySelector('script[type="module"][src*="/assets/"]');
  const live = native && !/^(localhost|127\.0\.0\.1)$/.test(location.hostname);
  let server;
  try { const r = await fetch(API + '/api/lock/status', { cache: 'no-store' }); server = r.ok ? 'reachable' : 'answered with an error (' + r.status + ')'; } catch { server = 'not reachable'; }
  const plugin = (...names) => (!native ? 'not needed in a browser' : names.every((n) => Capacitor.isPluginAvailable(n)) ? 'yes' : 'NO: build the APK again');
  return [
    ['Running as', native ? (live ? 'Android app, live (updates itself)' : 'Android app, built-in copy (does NOT update itself)') : 'Web browser'],
    ['Address', location.origin],
    ['Version', tag ? tag.src.split('/').pop() : 'development'],
    ['Server', server],
    ['Fingerprint plugin', plugin('BiometricAuthNative')],
    ['File saving and sharing', plugin('Filesystem', 'Share')],
    ['Notifications', plugin('LocalNotifications')],
  ];
}
