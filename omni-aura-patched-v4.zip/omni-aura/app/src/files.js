/* Files: attaching them to a chat message, and saving or sharing one.
   In the Android app a download link does nothing, so a saved file goes to the phone's share sheet instead
   (Save to Drive or Files, send on WhatsApp ...). That needs two small plugins which the APK build adds;
   if this build does not have them, the normal browser download is tried. */
import { Capacitor, registerPlugin } from '@capacitor/core';

const FS = registerPlugin('Filesystem'), Share = registerPlugin('Share');
const native = () => { try { return Capacitor.isNativePlatform(); } catch { return false; } };

export const MAX_FILES = 4;
export const MAX_ONE = 8 * 1024 * 1024; /* one file, bytes */
export const MAX_ALL = 12 * 1024 * 1024; /* all files in one message, bytes (before the picture is shrunk) */

const EXT = { txt: 'text/plain', md: 'text/markdown', csv: 'text/csv', tsv: 'text/tab-separated-values', json: 'application/json', xml: 'application/xml', html: 'text/html', css: 'text/css', js: 'text/javascript', jsx: 'text/javascript', ts: 'text/plain', tsx: 'text/plain', py: 'text/x-python', java: 'text/plain', kt: 'text/plain', c: 'text/plain', cpp: 'text/plain', h: 'text/plain', go: 'text/plain', rs: 'text/plain', php: 'text/plain', rb: 'text/plain', sh: 'text/plain', sql: 'text/plain', yml: 'text/plain', yaml: 'text/plain', toml: 'text/plain', ini: 'text/plain', log: 'text/plain', env: 'text/plain', pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', heic: 'image/heic', mp3: 'audio/mp3', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac' };
const OK = /^(image\/|audio\/|text\/|application\/(pdf|json|xml|x-yaml|yaml|javascript|x-javascript|x-sh))/;

export const mimeOf = (f) => {
  const t = String(f.type || '').toLowerCase();
  if (t && t !== 'application/octet-stream') return t;
  const e = String(f.name || '').toLowerCase().split('.').pop();
  return EXT[e] || t || 'application/octet-stream';
};
export const kb = (n) => (n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');

const readB64 = (blob) => new Promise((ok, no) => {
  const r = new FileReader();
  r.onload = () => ok(String(r.result).split(',')[1] || '');
  r.onerror = () => no(new Error('That file could not be read.'));
  r.readAsDataURL(blob);
});

/* Phone photos are huge; the model does not need 12 megapixels. Returns a smaller JPEG data URL, or null to keep the original. */
async function shrink(file, max = 1600, force = false) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => no(new Error('x')); i.src = url; });
    const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
    if (k === 1 && file.size < 1.5e6 && !force) return null;
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(img.naturalWidth * k)); c.height = Math.max(1, Math.round(img.naturalHeight * k));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.86);
  } catch { return null; } finally { URL.revokeObjectURL(url); }
}

/* One chosen file becomes { name, mime, data (base64), size, preview }. Throws a sentence the person can read. */
export async function readAttachment(file) {
  const mime = mimeOf(file), name = String(file.name || 'file').slice(0, 80);
  if (!OK.test(mime)) throw new Error(`"${name}" is not something I can read. Pictures, PDFs, audio, text and code files work.`);
  if (file.size > MAX_ONE) throw new Error(`"${name}" is ${kb(file.size)}. The limit is ${kb(MAX_ONE)} for one file.`);
  if (mime.startsWith('image/')) {
    /* the model reads PNG, JPEG, WEBP and HEIC; anything else (GIF, BMP, SVG ...) is converted to JPEG first */
    const plain = /^image\/(png|jpe?g|webp|heic|heif)$/.test(mime);
    const small = await shrink(file, 1600, !plain);
    if (small) return { name: name.replace(/\.\w+$/, '') + '.jpg', mime: 'image/jpeg', data: small.split(',')[1], size: Math.round(small.length * 0.75), preview: small };
    if (!plain) throw new Error(`"${name}" is a picture format I cannot open. Try a PNG or JPEG.`);
    const data = await readB64(file);
    return { name, mime, data, size: file.size, preview: mime === 'image/heic' || mime === 'image/heif' ? '' : 'data:' + mime + ';base64,' + data };
  }
  return { name, mime, data: await readB64(file), size: file.size, preview: '' };
}

/* Saves or shares a file. Returns 'native', 'browser' or 'cancelled'. */
export async function saveFile(name, blob) {
  if (native() && Capacitor.isPluginAvailable('Filesystem') && Capacitor.isPluginAvailable('Share')) {
    try {
      const w = await FS.writeFile({ path: name, data: await readB64(blob), directory: 'CACHE' });
      await Share.share({ title: name, url: w.uri, dialogTitle: 'Save or send ' + name });
      return 'native';
    } catch (e) {
      if (/cancel|dismiss/i.test(String((e && e.message) || ''))) return 'cancelled';
      /* otherwise fall through to the browser way */
    }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; a.rel = 'noopener';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  return 'browser';
}
export const saveDataUrl = async (name, dataUrl) => saveFile(name, await (await fetch(dataUrl)).blob());
