import { createClient } from '@supabase/supabase-js';
export { biometricOk } from './bio.js';

/* If this copy of the app was built without its database address, say so on screen instead of crashing to a black page. */
const SB_URL = import.meta.env.VITE_SUPABASE_URL, SB_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const chain = { on() { return chain; }, subscribe() { return chain; } };
const stub = {
  auth: {
    getSession: async () => ({ data: { session: null } }),
    onAuthStateChange: () => ({ data: { subscription: { unsubscribe() {} } } }),
    signInWithPassword: async () => ({ error: { message: 'This app was built without its database address.' } }),
    signOut: async () => ({}),
  },
  channel: () => chain,
  removeChannel: () => {},
};
let client = stub, problem = '';
if (!SB_URL || !SB_KEY) problem = 'This copy of the app was built without its database address (VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are empty). Add them where the app is built, then build again.';
else { try { client = createClient(SB_URL, SB_KEY); } catch (e) { problem = 'The database address this app was built with is not valid: ' + e.message; } }
export const CONFIG_PROBLEM = problem;
export const sb = client;
export const API = (import.meta.env.VITE_API_URL || 'https://omni-aura.onrender.com').replace(/\/$/, '');
/* Anything the server sends where a list is expected becomes a list, so .map and .filter cannot crash a screen. */
export const arr = (v) => (Array.isArray(v) ? v : []);
export async function api(path, method = 'GET', body) {
  const { data } = await sb.auth.getSession();
  let r;
  try {
    r = await fetch(API + path, { method, headers: { authorization: 'Bearer ' + (data.session?.access_token || ''), 'content-type': 'application/json' }, body: body && JSON.stringify(body) });
  } catch { throw new Error('Cannot reach the server. Check your connection. A sleeping free server can take about a minute to wake.'); }
  if (!r.ok) {
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && j.error === 'not_owner') { window.dispatchEvent(new Event('omni:intruder')); throw new Error('This account is not allowed here.'); }
    if (r.status === 401) throw new Error('Not signed in as the owner. Sign out and sign in again.');
    throw new Error(j.error || 'Request failed (' + r.status + ') ' + path);
  }
  return r.json();
}

/* Settings the chat or the voice assistant may change on this device. */
export const applyUi = (ui) => {
  (Array.isArray(ui) ? ui : []).forEach((u) => {
    if (u && u.key === 'callStyle' && (u.value === 'full' || u.value === 'banner')) { try { localStorage.callStyle = u.value; } catch { /* storage unavailable */ } }
  });
};
