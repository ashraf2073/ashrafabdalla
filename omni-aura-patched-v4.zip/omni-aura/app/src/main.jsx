import { Component } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './style.css';

/* Last line of defence: whatever goes wrong while drawing, the person sees a message and a button, never a black screen. */
class Root extends Component {
  state = { err: null };
  static getDerivedStateFromError(err) { return { err }; }
  componentDidCatch(err, info) { console.error(err, info && info.componentStack); }
  render() {
    if (!this.state.err) return this.props.children;
    return (
      <div className="login"><form onSubmit={(e) => { e.preventDefault(); location.reload(); }}>
        <h1 className="brandline">Omni-Aura</h1>
        <p className="err" role="alert">Something broke while drawing the screen: {String((this.state.err && this.state.err.message) || this.state.err)}</p>
        <button className="primary" type="submit">Reload</button>
      </form></div>
    );
  }
}
createRoot(document.getElementById('root')).render(<Root><App /></Root>);
