/* The bridge to the Android parts a web page cannot do on its own: staying alive in the background, ringing like a phone
   call when the app is closed, and sharing the whole screen over other apps. In a browser, or in an APK built before these
   parts existed, every call here quietly does nothing (or says so), so the rest of the app never breaks. */
import { Capacitor, registerPlugin } from '@capacitor/core';

const plugin = Capacitor.isNativePlatform() ? registerPlugin('OmniNative') : null;
export const isNative = () => Capacitor.isNativePlatform();
export const nativeReady = () => !!plugin && Capacitor.isPluginAvailable('OmniNative');

const NO_PLUGIN = 'This APK was built without the Omni-Aura phone parts. Run the build-apk workflow again and install the new APK.';
async function run(name, arg) {
  if (!nativeReady()) throw Object.assign(new Error(NO_PLUGIN), { code: 'no_plugin' });
  return plugin[name](arg || {});
}
/* same, but never throws: returns null when anything is missing */
async function soft(name, arg) { try { return await run(name, arg); } catch { return null; } }

export const Native = {
  ready: nativeReady,
  info: () => soft('info'),
  /* ringing when the app is closed */
  standbyStart: (apiUrl, key, intervalSec = 15) => run('standbyStart', { apiUrl, key, intervalSec }),
  standbyStop: () => soft('standbyStop'),
  testRing: () => run('testRing'),
  launchCall: () => soft('launchCall'),
  /* a live voice session that keeps going while another app is in front */
  sessionStart: (title) => soft('sessionStart', { title }),
  sessionEnd: () => soft('sessionEnd'),
  prepareVoice: () => soft('prepareVoice'),
  releaseVoice: () => soft('releaseVoice'),
  /* the whole screen, over other apps */
  startScreenShare: () => run('startScreenShare'),
  stopScreenShare: () => soft('stopScreenShare'),
  /* the phone's own settings pages the features need */
  openOverlaySettings: () => soft('openOverlaySettings'),
  requestBatteryExemption: () => soft('requestBatteryExemption'),
  openFullScreenSettings: () => soft('openFullScreenSettings'),
  openAppSettings: () => soft('openAppSettings'),
  /* events: screenFrame {data}, screenEnded, endSession, callOpened {id, answer} */
  on(event, cb) {
    if (!nativeReady()) return () => {};
    let h = null, gone = false;
    plugin.addListener(event, cb).then((x) => { if (gone) { try { x.remove(); } catch { /* ignore */ } } else h = x; }, () => {});
    return () => { gone = true; try { h && h.remove(); } catch { /* ignore */ } };
  },
};
