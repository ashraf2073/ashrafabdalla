import { api } from './lib.js';

/* Silent SOS: no sound and nothing on screen. The phone buzzes once on the third tap,
   twice when an alert got out, and once for a long time when it could not be sent. */
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
export const buzz = (p) => { try { navigator.vibrate && navigator.vibrate(p); } catch {} };

const fixOnce = (opt, ms) => new Promise((ok) => {
  if (!navigator.geolocation) return ok({});
  const t = setTimeout(() => ok({}), ms + 300);
  navigator.geolocation.getCurrentPosition(
    (p) => { clearTimeout(t); ok({ lat: p.coords.latitude, lon: p.coords.longitude }); },
    () => { clearTimeout(t); ok({}); },
    { timeout: ms, ...opt },
  );
});
/* Fast: an old fix (up to 5 minutes) is fine. The alert never waits longer than 2.5 s for one. */
export const quickFix = () => fixOnce({ enableHighAccuracy: false, maximumAge: 300000 }, 2500);
export const preciseFix = () => fixOnce({ enableHighAccuracy: true, maximumAge: 0 }, 15000);
/* Ask for location permission once, up front, so the first SOS is not stopped by a prompt. */
export const warmLocation = () => { try { if (!localStorage.getItem('sos.warm')) { localStorage.setItem('sos.warm', '1'); fixOnce({ enableHighAccuracy: false, maximumAge: 300000 }, 10000); } } catch {} };

const LAST = 'sos.last', QUEUE = 'sos.queue';
const put = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
export const lastSos = () => { try { return JSON.parse(localStorage.getItem(LAST) || 'null'); } catch { return null; } };

let flying = null;
export function silentSos(source = 'logo') {
  if (!flying) flying = run(source).finally(() => { flying = null; });
  return flying;
}

async function run(source) {
  buzz(25);
  const fix = await quickFix();
  let res = null, err = '';
  for (let i = 0; i < 4; i++) {
    try {
      res = await api('/api/safety/sos', 'POST', { source, ...fix });
      if (res.ok || res.noContacts) break;
      err = res.result || 'No alert got out.';
    } catch (e) { res = null; err = e.message; }
    if (i < 3) await wait(1200 * (i + 1));
  }
  if (res && res.ok) {
    put(LAST, JSON.stringify({ at: Date.now(), ok: true, text: res.result }));
    buzz([30, 90, 30]);
    /* No fix yet? Get a precise one in the background and send it on as a location update. */
    if (fix.lat == null && !res.skipped) preciseFix().then((f) => { if (f.lat != null) api('/api/safety/sos', 'POST', { source, followup: true, ...f }).catch(() => {}); });
    return { ok: true, text: res.result };
  }
  const text = res && res.noContacts ? 'No emergency contacts are set up yet.' : err || 'No alert got out.';
  put(LAST, JSON.stringify({ at: Date.now(), ok: false, text }));
  if (!(res && res.noContacts)) put(QUEUE, String(Date.now()));   /* try again when the phone is back online */
  buzz(600);
  return { ok: false, text };
}

/* Called when the phone comes back online or the app is opened again. */
export function flushSos() {
  let at = 0;
  try { at = +localStorage.getItem(QUEUE) || 0; localStorage.removeItem(QUEUE); } catch {}
  if (at && Date.now() - at < 30 * 60e3) silentSos('queued');
}
