import { Component, forwardRef, useEffect, useRef } from 'react';
import { runAtomLoader } from './atom.js';

export const MINT = '#76f2c4';
export const BLUE = '#2563ff';

/* ---------- icons (one stroke style, 24 px grid) ---------- */
const P = {
  menu: 'M4 7h16|M4 12h16|M4 17h10',
  chat: 'M5 5h14a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-8l-4 3.5V16H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z',
  today: 'M12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8z|M12 3v2|M12 19v2|M3 12h2|M19 12h2|M5.6 5.6l1.4 1.4|M17 17l1.4 1.4|M18.4 5.6L17 7|M7 17l-1.4 1.4',
  mic: 'M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3z|M6 11a6 6 0 0 0 12 0|M12 17v4',
  inbox: 'M4 6h16v12H4z|M4 7l8 6 8-6',
  bills: 'M6 3h12v18l-3-2-3 2-3-2-3 2z|M9 8h6|M9 12h6',
  shop: 'M5 8h14l-1 12H6z|M9 8V6a3 3 0 0 1 6 0v2',
  write: 'M4 20l1-4L16 5l3 3L8 19z|M14 7l3 3',
  assets: 'M4 5h16v14H4z|M4 16l5-5 4 4 3-3 4 4|M9 9.5h.01',
  safety: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',
  settings: 'M4 7h2|M10 7h10|M8 5v4|M4 17h6|M14 17h6|M12 15v4',
  about: 'M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z|M12 11v6|M12 7.5h.01',
  send: 'M12 19V5|M6 11l6-6 6 6',
  stop: 'M7 7h10v10H7z',
  cam: 'M4 8h3l2-2h6l2 2h3v11H4z|M12 10.5a3.5 3.5 0 1 0 0 7a3.5 3.5 0 1 0 0-7z',
  globe: 'M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18z|M3 12h18|M12 3c3 3 3 15 0 18|M12 3c-3 3-3 15 0 18',
  x: 'M6 6l12 12|M18 6L6 18',
  chev: 'M15 6l-6 6 6 6',
  copy: 'M8 8h11v12H8z|M5 16V4h11',
  spark: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z',
  phone: 'M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z',
  lock: 'M6 11h12v9H6z|M8.5 11V8a3.5 3.5 0 0 1 7 0v3',
  image: 'M4 5h16v14H4z|M4 16l5-5 4 4 3-3 4 4|M15.5 9.5h.01',
  play: 'M8 5l11 7-11 7z',
  clip: 'M20 11.5l-7.8 7.8a5 5 0 0 1-7-7l8.2-8.2a3.3 3.3 0 0 1 4.7 4.7l-8.3 8.2a1.7 1.7 0 0 1-2.4-2.4l7.6-7.5',
  file: 'M7 3h7l5 5v13H7z|M14 3v5h5',
  check: 'M5 12.5l4.5 4.5L19 7',
  flip: 'M20 11a8 8 0 0 0-14.5-4.5L4 8|M4 4v4h4|M4 13a8 8 0 0 0 14.5 4.5L20 16|M20 20v-4h-4',
  screen: 'M3 5h18v11H3z|M8 20h8|M12 16v4',
  plus: 'M12 5v14|M5 12h14',
  trash: 'M5 7h14|M10 7V4h4v3|M7 7l1 13h8l1-13',
  train: 'M12 4l9 4-9 4-9-4z|M7 10.5V15c0 1.5 2.2 3 5 3s5-1.5 5-3v-4.5|M21 8v6',
  logout: 'M10 5H5v14h5|M14 8l4 4-4 4|M18 12H9',
  list: 'M9 6h11|M9 12h11|M9 18h11|M4.5 6h.01|M4.5 12h.01|M4.5 18h.01',
  edit: 'M4 20l1-4L16 5l3 3L8 19z|M14 7l3 3',
  finger: 'M5 10a7 7 0 0 1 14 0|M5 10v3c0 1.3-.2 2.4-.6 3.4|M7.6 10a4.4 4.4 0 0 1 8.8 0v2.4|M7.6 13v.6c0 1.8-.4 3.2-1 4.4|M10.2 10a1.8 1.8 0 0 1 3.6 0v4.3c0 1.6.3 2.9.9 4.1|M12 10.8v3.7c0 1.6-.4 3-1 4.2|M16.4 14.4c0 1.3-.1 2.4-.4 3.5',
};
export function Icon({ n, size = 20, ...rest }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" {...rest}>
      {P[n].split('|').map((d, i) => <path key={i} d={d} />)}
    </svg>
  );
}

/* ---------- the loading animation: fine layered strands along an infinity curve, led by atoms ----------
   size is the height in px; the width is 2.3 times that. tone "ink" draws in the text colour (inside buttons). */
const rgbOf = (css) => { const m = String(css).match(/\d+(\.\d+)?/g); return m && m.length >= 3 ? [+m[0], +m[1], +m[2]] : [0, 0, 0]; };
export function InfinityLoader({ size = 28, label = 'Loading', tone = 'glow' }) {
  const ref = useRef(null);
  const W = Math.round(size * 2.3), H = size;
  useEffect(() => {
    const c = ref.current;
    if (!c) return undefined;
    const ink = tone === 'ink' ? rgbOf(getComputedStyle(c).color) : null;
    const o = size < 44 ? { full: false, layers: size < 24 ? 3 : 4, atoms: 2, chunks: 8, ink } : size < 100 ? { layers: 5, chunks: 10, ink } : { ink };
    return runAtomLoader(c, W, H, o);
  }, [W, H, size, tone]);
  return <canvas ref={ref} className="inf" role="img" aria-label={label} />;
}
export const Busy = ({ label }) => <span className="busy"><InfinityLoader size={18} tone="ink" label={label} />{label}</span>;
export const Loading = ({ label = 'Loading' }) => <div className="center"><InfinityLoader size={84} label={label} /></div>;

/* ---------- the live bubble: the logo itself, glowing, with a tech look ----------
   CSS variable --lvl (0 to 1) is driven by the microphone and the reply audio. */
const RAYS = Array.from({ length: 12 }, (_, k) => {
  const a = (k * Math.PI) / 6, c = Math.cos(a), s = Math.sin(a);
  return [120 + 28 * c, 120 + 28 * s, 120 + 64 * c, 120 + 64 * s];
});
export const LogoLive = forwardRef(function LogoLive({ state = 'idle' }, ref) {
  return (
    <svg ref={ref} className={'lg ' + state} viewBox="0 0 240 240" role="img" aria-label="Omni-Aura">
      <defs>
        <radialGradient id="lgGlow"><stop offset="0" stopColor={MINT} stopOpacity=".6" /><stop offset=".42" stopColor={BLUE} stopOpacity=".3" /><stop offset="1" stopColor={BLUE} stopOpacity="0" /></radialGradient>
        <linearGradient id="lgArc" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={MINT} /><stop offset="1" stopColor={BLUE} /></linearGradient>
        <radialGradient id="lgCore"><stop offset="0" stopColor={MINT} stopOpacity=".5" /><stop offset=".55" stopColor={MINT} stopOpacity=".14" /><stop offset="1" stopColor={MINT} stopOpacity="0" /></radialGradient>
      </defs>
      <circle className="halo" cx="120" cy="120" r="150" fill="url(#lgGlow)" />
      <g className="spin-a"><circle cx="120" cy="120" r="115" fill="none" stroke={BLUE} strokeWidth="5" strokeDasharray="1.1 8.5" opacity=".75" /></g>
      <g className="spin-b">
        <path d="M120 10 A110 110 0 0 1 230 120" fill="none" stroke="url(#lgArc)" strokeWidth="2.6" strokeLinecap="round" />
        <path d="M120 230 A110 110 0 0 1 10 120" fill="none" stroke="url(#lgArc)" strokeWidth="2.6" strokeLinecap="round" opacity=".7" />
      </g>
      <g className="spin-c"><path d="M120 24 A96 96 0 0 1 216 120" fill="none" stroke={MINT} strokeWidth="1" strokeLinecap="round" strokeDasharray="1 5" opacity=".6" /></g>
      <circle className="ring1" cx="120" cy="120" r="104" fill="none" stroke={BLUE} strokeWidth="2.4" />
      <circle cx="120" cy="120" r="94" fill="none" stroke={MINT} strokeWidth=".9" opacity=".55" />
      <circle className="aura" cx="120" cy="120" r="84" fill="url(#lgCore)" />
      <g className="rays" stroke="#eaf1ff" strokeWidth="2.6" strokeLinecap="round">{RAYS.map((r, i) => <line key={i} x1={r[0]} y1={r[1]} x2={r[2]} y2={r[3]} />)}</g>
      <circle className="core" cx="120" cy="120" r="10" fill={MINT} />
    </svg>
  );
});

/* ---------- a screen that fails shows what went wrong instead of going blank ---------- */
export class Boundary extends Component {
  state = { err: null };
  static getDerivedStateFromError(err) { return { err }; }
  componentDidCatch(err, info) { console.error(err, info && info.componentStack); }
  componentDidUpdate(prev) { if (prev.resetKey !== this.props.resetKey && this.state.err) this.setState({ err: null }); }
  render() {
    if (!this.state.err) return this.props.children;
    return (
      <section>
        <h2>This screen hit a problem</h2>
        <p className="err">{String((this.state.err && this.state.err.message) || this.state.err)}</p>
        <p className="mute">Usually this means the server or database sent something unexpected. Nothing was lost.</p>
        <button onClick={() => this.setState({ err: null })}>Try again</button>
        <button className="ghost" onClick={this.props.onHome}>Back to Chat</button>
      </section>
    );
  }
}
