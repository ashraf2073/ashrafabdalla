export default function mountActions({ app, db, auth, A, llm, toJson, E, gToken, gmailSend, stampOf, pinOk, lock }) {
  const gcal = async (path, opt = {}) => {
    let token;
    try { token = await gToken(); } catch (e) { throw new Error('Calendar: ' + e.message); }
    return fetch('https://www.googleapis.com/calendar/v3/calendars/primary/' + path, { ...opt, headers: { authorization: 'Bearer ' + token } });
  };
  const KINDS = ['send_email', 'cancel_request', 'cancel_event'];

  app.post('/api/actions/propose', auth, A(async (req, res) => {
    const raw = await llm([{ role: 'user', content: `Ashraf asks: "${String(req.body.request || '').slice(0, 1500)}"\nClassify and draft. JSON only: {"kind":"send_email|cancel_request|cancel_event|none","summary":"one line","to":"","subject":"","body":"","search":"","note":""}.\n- send_email: draft an email as Ashraf, first person; write in Swahili if he asks for it or writes the request in Swahili.\n- cancel_request: draft a polite, firm email cancelling an order or membership; quote any order number, name or date he gave; ask for written confirmation.\n- cancel_event: "search" is one short keyword for the meeting.\n- "to" must be an email address Ashraf wrote himself; if he gave none, leave it empty. Never invent addresses.\n- "none": the request is none of these; put your reply in "note".` }], { json: true });
    let p;
    try { p = JSON.parse(raw.replace(/```json|```/g, '')); } catch { return res.status(422).json({ error: 'I could not understand that request.' }); }
    if (!KINDS.includes(p.kind)) return res.json({ note: p.note || 'I could not turn that into an action.' });
    if (p.kind === 'cancel_event') {
      const r = await (await gcal(`events?q=${encodeURIComponent(p.search || '')}&timeMin=${encodeURIComponent(new Date().toISOString())}&maxResults=5&singleEvents=true&orderBy=startTime`)).json();
      if (r.error) return res.status(502).json({ error: 'Calendar: ' + r.error.message });
      const when = (e) => e.start?.dateTime || e.start?.date || '';
      const [first, ...rest] = r.items || [];
      if (!first) return res.json({ note: `No upcoming meeting matches "${p.search}".` });
      const summary = `Cancel "${first.summary}" at ${when(first)}${rest.length ? '. Other matches: ' + rest.map((e) => `${e.summary} (${when(e)})`).join('; ') : ''}`;
      return res.json((await db.from('actions').insert({ kind: p.kind, summary, payload: { eventId: first.id } }).select().single()).data);
    }
    res.json((await db.from('actions').insert({ kind: p.kind, summary: p.summary || p.kind, payload: { to: p.to || '', subject: p.subject || '', body: p.body || '' } }).select().single()).data);
  }));

  app.get('/api/actions', auth, A(async (_, res) => res.json((await db.from('actions').select().order('id', { ascending: false }).limit(15)).data)));
  app.post('/api/actions/:id/discard', auth, A(async (req, res) => {
    await db.from('actions').update({ status: 'discarded', decided_at: new Date() }).eq('id', req.params.id).eq('status', 'proposed');
    res.json({ ok: true });
  }));

  app.post('/api/actions/:id/approve', auth, A(async (req, res) => {
    if (!pinOk(req.body?.pin)) return res.status(403).json({ error: 'Wrong PIN' });
    const unlock = lock('action:' + req.params.id);
    if (!unlock) return res.status(409).json({ error: 'This action is already being carried out.' });
    try {
      const { data: a } = await db.from('actions').select().eq('id', req.params.id).eq('status', 'proposed').maybeSingle();
      if (!a) return res.status(404).json({ error: 'That action is no longer waiting.' });
      const { to, subject, body, account } = req.body.edits || {};
      const p = { ...a.payload, ...(to != null && { to }), ...(subject != null && { subject }), ...(body != null && { body }), ...(account && { account }) };
      let ok = false, result = '';
      if (a.kind === 'cancel_event') {
        try {
          const r = await gcal(`events/${encodeURIComponent(p.eventId)}?sendUpdates=all`, { method: 'DELETE' });
          ok = r.ok || r.status === 410;
          result = ok ? 'Meeting cancelled and attendees notified.' : 'Google Calendar answered ' + r.status;
        } catch (e) { result = e.message; }
      } else {
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(p.to || '')) return res.status(400).json({ error: 'Add a valid To address first.' });
        try {
          ok = await gmailSend({ to_addr: p.to, subject: p.subject, body: p.body + (req.body.stamp ? await stampOf('AC-' + a.id) : ''), fresh: true, account: p.account });
          result = ok ? 'Email sent to ' + p.to : 'Gmail refused the send.';
        } catch (e) { result = 'Not sent: ' + e.message; }
      }
      await db.from('actions').update({ status: ok ? 'executed' : 'failed', result, decided_at: new Date() }).eq('id', a.id);
      res.json({ ok, result });
    } finally { unlock(); }
  }));
}
