import crypto from 'node:crypto';
import { passMatches } from './lib.js';

/* Calls, direct push, the app lock and intruder alerts.
   A "call" is a row in `calls`. The open app sees it at once through Realtime. When the app is closed it
   arrives as a Web Push notification from the browser itself (no ntfy app, no clipboard). ntfy is only
   used as a last resort for ordinary calls, and never for security alerts. */
export default function mountCalls({ app, db, auth, A, E, inFocus, inQuiet, ntfy, webpush, autoChain, gmailSend, google, googleTest, llm }) {
  const ownerEmail = () => String(E.OWNER_EMAIL || '').toLowerCase();
  const sign = (id, a) => crypto.createHmac('sha256', E.CRON_SECRET || 'x').update(`call:${id}:${a}`).digest('hex').slice(0, 24);
  const selfUrl = () => String(E.PUBLIC_URL || E.RENDER_EXTERNAL_URL || '').replace(/\/$/, '');
  const ipOf = (req) => { const f = String(req.get('x-forwarded-for') || '').split(',').map((s) => s.trim()).filter(Boolean); return f[f.length - 1] || req.socket?.remoteAddress || 'unknown'; };

  /* ---- tiny in-memory rate limiter ---- */
  const hits = new Map();
  const count = (key, windowMs) => {
    const now = Date.now(), a = (hits.get(key) || []).filter((t) => now - t < windowMs);
    a.push(now); hits.set(key, a);
    if (hits.size > 4000) for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > 36e5) hits.delete(k);
    return a.length;
  };

  /* ---- Web Push ---- */
  let vapid = null;
  async function vapidKeys() {
    if (vapid) return vapid;
    if (E.VAPID_PUBLIC_KEY && E.VAPID_PRIVATE_KEY) return (vapid = { publicKey: E.VAPID_PUBLIC_KEY, privateKey: E.VAPID_PRIVATE_KEY });
    const { data } = await db.from('app_kv').select().eq('k', 'vapid').maybeSingle();
    if (data?.v?.publicKey && data.v.privateKey) return (vapid = data.v);
    const k = webpush.generateVAPIDKeys();
    await db.from('app_kv').upsert({ k: 'vapid', v: k }, { onConflict: 'k' });
    return (vapid = k);
  }
  const subject = () => E.VAPID_SUBJECT || 'mailto:' + (E.ALERT_EMAIL || E.OWNER_EMAIL || 'owner@example.com');

  /* Sends one payload to every subscribed device. Returns how many accepted it. */
  async function pushAll(payload, { ttl = 120, urgency = 'high' } = {}) {
    if (!webpush) return { sent: 0, subs: 0, error: 'web-push is not installed on the server' };
    let subs = [];
    try { subs = (await db.from('push_subs').select()).data || []; } catch (e) { return { sent: 0, subs: 0, error: e.message }; }
    if (!subs.length) return { sent: 0, subs: 0 };
    const v = await vapidKeys(), body = JSON.stringify(payload);
    let sent = 0;
    await Promise.all(subs.map(async (s) => {
      try {
        await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, body, { TTL: ttl, urgency, vapidDetails: { subject: subject(), publicKey: v.publicKey, privateKey: v.privateKey } });
        sent += 1;
      } catch (e) {
        if (e.statusCode === 404 || e.statusCode === 410) { try { await db.from('push_subs').delete().eq('id', s.id); } catch { /* ignore */ } }
        else console.warn('push failed:', e.statusCode || e.message);
      }
    }));
    return { sent, subs: subs.length };
  }

  async function emailOwner(subjectLine, body) {
    const to = E.ALERT_EMAIL || E.OWNER_EMAIL;
    if (!to) return false;
    try { return await gmailSend({ to_addr: to, subject: subjectLine, body, fresh: true }); }
    catch (e) { console.warn('alert email failed:', e.message); return false; }
  }


  /* ---- the Android app's own line (no Google, no Web Push, no ntfy) ----
     The APK registers once while signed in and keeps a long random device key in the phone. A small background service in the
     APK then asks this server "is anything ringing?" every few seconds with that key, and rings the phone itself like a call.
     The key can only list and answer calls. The server stores only a hash of it. */
  const hashKey = (k) => crypto.createHash('sha256').update(String(k)).digest('hex');
  const seen = new Map(); /* device hash -> when it last asked */
  const known = new Map(); /* device hash -> { v, at } so a poll does not read the database every time */
  const nativeOnline = () => { const now = Date.now(); for (const t of seen.values()) if (now - t < 150e3) return true; return false; };
  const devAuth = async (req, res, next) => {
    try {
      const key = String(req.get('x-device-key') || '').trim(), h = key.length >= 20 && key.length <= 200 ? hashKey(key) : '';
      let hit = h ? known.get(h) : null;
      if (!hit || Date.now() - hit.at > 5 * 60e3) {
        const row = h ? (await db.from('app_kv').select().eq('k', 'device:' + h).maybeSingle()).data : null;
        hit = row ? { v: row.v || {}, at: Date.now() } : null;
        if (hit) known.set(h, hit); else known.delete(h);
      }
      if (!hit) return res.sendStatus(count('devfail:' + ipOf(req), 10 * 60e3) > 20 ? 429 : 401);
      req.device = { h, v: hit.v };
      next();
    } catch (e) { console.warn('device auth:', e.message); res.sendStatus(500); }
  };

  /* ---- ring: place a call to the owner ----
     kind: checkin | consent | urgent | security | info.  ref points at the thing it is about. */
  async function ring({ kind = 'info', title = 'Omni-Aura', say = '', ref = null, urgent = false, meta = null }) {
    let held = false;
    if (!urgent && kind !== 'security') { try { held = (await inFocus()) || (await inQuiet()); } catch { /* ignore */ } }
    let row = null;
    try { row = (await db.from('calls').insert({ kind, title, say, ref, urgent, meta, status: held ? 'held' : 'ringing' }).select().single()).data; }
    catch (e) { console.warn('calls table is not usable (run the SQL update):', e.message); }
    if (held) return { held: true, row };
    const payload = {
      id: row?.id ?? null, kind, title: 'Omni-Aura is calling', body: (title + (say ? ': ' + say : '')).slice(0, 180),
      urgent, decline: row && selfUrl() ? `${selfUrl()}/api/calls/${row.id}/respond?a=decline&sig=${sign(row.id, 'decline')}` : null,
    };
    let via = '';
    try { if ((await pushAll(payload, { urgency: urgent || kind === 'security' ? 'high' : 'normal' })).sent) via = 'push'; }
    catch (e) { console.warn('push error:', e.message); }
    if (!via && row && nativeOnline()) via = 'device'; /* the Android app is listening and will ring the phone itself */
    if (!via) {
      if (kind === 'security') { if (await emailOwner('Omni-Aura security alert', say)) via = 'email'; }
      else { try { if (await ntfy(`${title}${say ? ': ' + say : ''}`.slice(0, 400), 'OMNI-AURA is calling', true)) via = 'ntfy'; } catch { /* ignore */ } }
    }
    if (row && via) { try { await db.from('calls').update({ via }).eq('id', row.id); } catch { /* ignore */ } }
    return { row, via: via || 'app' };
  }

  /* ---- security: strangers and wrong passphrases ---- */
  async function intruder(email, how, req) {
    const e = String(email || '').toLowerCase().slice(0, 200);
    const ip = req ? ipOf(req) : 'unknown', ua = req ? String(req.get('user-agent') || '').slice(0, 160) : '';
    if (count('intr-all', 36e5) > 8 || count('intr:' + e, 10 * 60e3) > 1) return false;
    await ring({
      kind: 'security', urgent: true, title: 'Suspicious sign-in',
      say: `Sir, someone just tried to get into Omni-Aura${e ? ' with the account ' + e : ''}. I turned them away.`,
      meta: { email: e, how, ip, ua },
    });
    return true;
  }

  /* ---------- who am I (lets the app confirm the signed-in account really is the owner) ---------- */
  app.get('/api/me', auth, (_, res) => res.json({ ok: true }));

  /* ---------- app lock (public: it runs before sign-in state is known) ---------- */
  app.get('/api/lock/status', (_, res) => res.json({ enabled: !!E.APP_PASSPHRASE }));
  const tryPass = async (heard, req, res) => {
    if (!E.APP_PASSPHRASE) return res.json({ ok: true });
    const ip = ipOf(req);
    if (count('lock-all', 36e5) > 200 || count('lock:' + ip, 15 * 60e3) > 10) return res.status(429).json({ error: 'Too many tries. Wait a few minutes.' });
    if (passMatches(heard, E.APP_PASSPHRASE)) return res.json({ ok: true });
    const n = count('lockfail:' + ip, 15 * 60e3);
    if (n === 3) ring({ kind: 'security', urgent: true, title: 'App lock', say: 'Sir, the wrong passphrase has been entered three times.', meta: { how: 'lock', ip } }).catch(() => {});
    return res.json({ ok: false });
  };
  app.post('/api/lock/verify', A(async (req, res) => tryPass(String(req.body?.text || '').slice(0, 400), req, res)));
  app.post('/api/lock/voice', A(async (req, res) => {
    if (!E.APP_PASSPHRASE) return res.json({ ok: true });
    const data = String(req.body?.audio || '');
    if (!data || data.length > 900000) return res.status(400).json({ error: 'No audio received.' });
    let heard = '';
    try {
      const chain = await autoChain().catch(() => []);
      const model = (chain.find((id) => id.startsWith('gemini:')) || 'gemini:gemini-2.5-flash').slice(7);
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': E.GEMINI_KEY },
        body: JSON.stringify({ contents: [{ parts: [{ text: 'Transcribe this short audio exactly as spoken. Write numbers as digits. Reply with the transcript only.' }, { inlineData: { mimeType: 'audio/wav', data } }] }] }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error?.message || r.status);
      heard = (d.candidates?.[0]?.content?.parts || []).map((x) => x.text || '').join(' ');
    } catch (e) { return res.status(502).json({ error: 'I could not make out the recording: ' + e.message }); }
    return tryPass(heard, req, res);
  }));

  /* ---------- a stranger tried to sign in (public, rate limited) ---------- */
  app.post('/api/security/attempt', A(async (req, res) => {
    const email = String(req.body?.email || '').trim().slice(0, 200);
    const known = !!ownerEmail() && email.toLowerCase() === ownerEmail();
    if (count('att:' + ipOf(req), 15 * 60e3) > 30) return res.status(429).json({ error: 'Slow down.' });
    if (known) {
      /* the owner mistyping a password is normal: only raise an alarm if it keeps happening */
      if (count('ownerfail', 15 * 60e3) === 3) ring({ kind: 'security', urgent: true, title: 'Sign-in', say: 'Sir, the password for your account has failed three times in a row.', meta: { email, how: 'password', ip: ipOf(req) } }).catch(() => {});
      return res.json({ known: true });
    }
    intruder(email, 'login', req).catch((e) => console.warn('intruder:', e.message));
    res.json({ known: false });
  }));

  /* ---------- direct alerts (Web Push) ---------- */
  app.get('/api/push/key', auth, A(async (_, res) => {
    if (!webpush) return res.status(501).json({ error: 'The server is missing the web-push package. Redeploy the server after updating package.json.' });
    res.json({ key: (await vapidKeys()).publicKey });
  }));
  app.post('/api/push/subscribe', auth, A(async (req, res) => {
    const s = req.body?.subscription;
    if (!s?.endpoint || !s.keys?.p256dh || !s.keys?.auth) return res.status(400).json({ error: 'That subscription is incomplete.' });
    await db.from('push_subs').upsert({ endpoint: String(s.endpoint), p256dh: s.keys.p256dh, auth: s.keys.auth, ua: String(req.body.ua || '').slice(0, 160) }, { onConflict: 'endpoint' });
    res.json({ ok: true });
  }));
  app.post('/api/push/unsubscribe', auth, A(async (req, res) => { await db.from('push_subs').delete().eq('endpoint', String(req.body?.endpoint || '')); res.json({ ok: true }); }));
  app.get('/api/push/status', auth, A(async (_, res) => {
    let n = 0, err = '';
    try { n = ((await db.from('push_subs').select('id')).data || []).length; } catch (e) { err = e.message; }
    res.json({ devices: n, installed: !!webpush, error: err || undefined });
  }));


  /* ---------- the Android app's line ---------- */
  app.post('/api/device/register', auth, A(async (req, res) => {
    const key = crypto.randomBytes(32).toString('base64url');
    await db.from('app_kv').upsert({ k: 'device:' + hashKey(key), v: { name: String(req.body?.name || 'Android').slice(0, 60), created: new Date().toISOString() } }, { onConflict: 'k' });
    try { /* at most 5 phones: the oldest registrations are dropped */
      const rows = ((await db.from('app_kv').select('k,v').like('k', 'device:%')).data || []).sort((a, b) => String(b.v?.created || '').localeCompare(String(a.v?.created || '')));
      for (const r of rows.slice(5)) await db.from('app_kv').delete().eq('k', r.k);
    } catch (e) { console.warn('device tidy:', e.message); }
    res.json({ key });
  }));
  app.post('/api/device/unregister', devAuth, A(async (req, res) => {
    await db.from('app_kv').delete().eq('k', 'device:' + req.device.h);
    known.delete(req.device.h); seen.delete(req.device.h);
    res.json({ ok: true });
  }));
  /* what is ringing right now; `age` is worked out here so the phone's clock does not matter */
  app.get('/api/device/pending', devAuth, A(async (req, res) => {
    seen.set(req.device.h, Date.now());
    const { data } = await db.from('calls').select('id,kind,title,say,urgent,status,created_at').eq('status', 'ringing').gte('created_at', new Date(Date.now() - 15 * 60e3).toISOString()).order('id', { ascending: false }).limit(5);
    res.json({ calls: (data || []).map((c) => ({ id: c.id, kind: c.kind, title: c.title, say: c.say, urgent: !!c.urgent, age: Date.now() - Date.parse(c.created_at) })) });
  }));
  app.post('/api/device/calls/:id/:action', devAuth, A(async (req, res) => {
    const status = { accept: 'accepted', decline: 'declined', missed: 'missed' }[req.params.action];
    if (!status || !/^\d+$/.test(req.params.id)) return res.sendStatus(400);
    await db.from('calls').update({ status, answered_at: new Date() }).eq('id', req.params.id).eq('status', 'ringing');
    res.json({ ok: true });
  }));

  /* ---------- Voice and calls check: what the server knows, so "it stopped calling" can be explained ---------- */
  app.get('/api/diag/status', auth, A(async (_, res) => {
    const out = { now: new Date().toISOString() };
    try {
      const s = (await db.from('settings').select().eq('id', 1).single()).data, h = new Date(Date.now() + 3 * 36e5).getUTCHours();
      out.hourEAT = h;
      out.quiet = { start: s.quiet_start, end: s.quiet_end, active: h >= s.quiet_start || h < s.quiet_end };
      out.focus = { until: s.focus_until || null, active: !!s.focus_until && new Date(s.focus_until) > new Date() };
    } catch (e) { out.settingsError = e.message; }
    try { out.cron = Object.fromEntries(((await db.from('app_kv').select('k,v').like('k', 'cron:%')).data || []).map((r) => [r.k.slice(5), r.v])); } catch { out.cron = {}; }
    try { out.calls = (await db.from('calls').select('id,kind,status,via,created_at').order('id', { ascending: false }).limit(6)).data || []; } catch (e) { out.callsError = e.message; }
    try { out.pushDevices = ((await db.from('push_subs').select('id')).data || []).length; } catch { out.pushDevices = 0; }
    try { out.nativeDevices = ((await db.from('app_kv').select('k').like('k', 'device:%')).data || []).length; } catch { out.nativeDevices = 0; }
    const last = Math.max(0, ...seen.values());
    out.nativeOnline = nativeOnline(); out.nativeSeenSecAgo = last ? Math.round((Date.now() - last) / 1000) : null;
    out.env = { cronSecret: !!E.CRON_SECRET, publicUrl: !!selfUrl(), geminiKey: !!E.GEMINI_KEY, liveModel: E.LIVE_MODEL || 'gemini-3.8-live', voice: E.VOICE_NAME || 'Charon', webpush: !!webpush };
    res.json(out);
  }));

  /* ---------- calls ---------- */
  app.get('/api/calls/pending', auth, A(async (_, res) => {
    const { data } = await db.from('calls').select().eq('status', 'ringing').gte('created_at', new Date(Date.now() - 10 * 60e3).toISOString()).order('id', { ascending: false }).limit(5);
    res.json(data || []);
  }));
  app.get('/api/calls/log', auth, A(async (_, res) => res.json((await db.from('calls').select().neq('status', 'held').order('id', { ascending: false }).limit(25)).data || [])));
  app.post('/api/calls/test', auth, A(async (_, res) => {
    const r = await ring({ kind: 'info', urgent: true, title: 'Test call', say: 'This is a test call, sir. If you can hear me, direct calls are working.' });
    res.json({ via: r.via || 'app' });
  }));
  const setStatus = (status) => A(async (req, res) => {
    await db.from('calls').update({ status, answered_at: new Date() }).eq('id', req.params.id).eq('status', 'ringing');
    res.json({ ok: true });
  });
  app.post('/api/calls/:id/accept', auth, setStatus('accepted'));
  app.post('/api/calls/:id/decline', auth, setStatus('declined'));
  app.post('/api/calls/:id/missed', auth, setStatus('missed'));
  /* The notification's Decline button can't sign in, so it carries a signed link instead. */
  app.post('/api/calls/:id/respond', A(async (req, res) => {
    const a = req.query.a === 'decline' ? 'decline' : null, sg = String(req.query.sig || '');
    const want = a ? sign(req.params.id, a) : '';
    if (!a || sg.length !== want.length || !crypto.timingSafeEqual(Buffer.from(sg), Buffer.from(want))) return res.sendStatus(403);
    await db.from('calls').update({ status: 'declined', answered_at: new Date() }).eq('id', req.params.id).eq('status', 'ringing');
    res.json({ ok: true });
  }));

  /* After a spoken consent call: work out what he decided. Only the safe outcomes happen by themselves:
     a draft is discarded or reworded. Sending always stays behind the Approve button and the PIN. */
  app.post('/api/calls/:id/take', auth, A(async (req, res) => {
    const text = String(req.body?.text || '').trim().slice(0, 2000);
    const { data: c } = await db.from('calls').select().eq('id', req.params.id).maybeSingle();
    if (!c) return res.status(404).json({ error: 'That call no longer exists.' });
    await db.from('calls').update({ status: 'done', answer: text, answered_at: new Date() }).eq('id', c.id);
    if (c.kind !== 'consent' || !text) return res.json({ ok: true, decision: 'none', message: text ? 'Noted.' : 'Call ended.' });
    let d = { decision: 'unclear' };
    try {
      const raw = await llm([{ role: 'user', content: `Ashraf was asked for his decision about: ${c.say}\nDraft reply: ${c.meta?.draft || 'none'}\nHe said: ${text}\nJSON only: {"decision":"approve|decline|change|later|unclear","reply":""}. "reply" is a revised draft in his own voice, only when decision is change.` }], { json: true });
      d = JSON.parse(String(raw).replace(/```json|```/g, ''));
    } catch (e) { console.warn('take not understood:', e.message); }
    const oid = c.ref?.table === 'outbox' ? c.ref.id : null;
    let message = 'I could not tell what you decided, so I left it as it is.', goto = '';
    if (d.decision === 'decline') {
      if (oid) { await db.from('outbox').update({ status: 'discarded' }).eq('id', oid).eq('status', 'pending'); message = 'Declined, and I discarded the draft.'; }
      else message = 'Declined. Nothing was sent.';
    } else if (d.decision === 'change' && oid && d.reply) {
      await db.from('outbox').update({ body: String(d.reply).slice(0, 4000) }).eq('id', oid).eq('status', 'pending');
      message = 'I reworded the draft. Review it in Inbox, then approve it.'; goto = 'Inbox';
    } else if (d.decision === 'approve') { message = 'Understood. Approve the reply in Inbox (your PIN applies) and it will go.'; goto = 'Inbox'; }
    else if (d.decision === 'later') message = 'Left for later.';
    res.json({ ok: true, decision: d.decision || 'unclear', message, goto });
  }));

  /* ---------- Google status, so the app can say exactly what is missing ---------- */
  app.get('/api/google/status', auth, A(async (_, res) => res.json(google())));
  /* Tries every account against Gmail, Calendar, Drive and Docs, and says in plain words what fails. */
  app.get('/api/google/test', auth, A(async (_, res) => res.json({ status: google(), accounts: await googleTest() })));

  /* One tap to drop mail drafts that have been sitting for days. */
  app.post('/api/inbox/clear-old', auth, A(async (_, res) => {
    const { data } = await db.from('outbox').update({ status: 'discarded' }).eq('status', 'pending').lte('created_at', new Date(Date.now() - 3 * 864e5).toISOString()).select('id');
    res.json({ cleared: (data || []).length });
  }));

  return { ring, pushAll, intruder };
}
