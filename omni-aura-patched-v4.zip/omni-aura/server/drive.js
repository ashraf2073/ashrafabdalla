/* Google Drive and Docs for the assistant, and a probe that says exactly what is wrong with a Google account.
   Uses the same accounts as Gmail and Calendar. It needs the Drive and Docs APIs switched on in Google Cloud and a
   refresh token that was made with their scopes. */
const SCOPE = {
  Gmail: 'https://mail.google.com/',
  'Google Calendar': 'https://www.googleapis.com/auth/calendar',
  'Google Drive': 'https://www.googleapis.com/auth/drive',
  'Google Docs': 'https://www.googleapis.com/auth/documents',
};

/* Turns a Google error into something that says what to do. */
export function friendly(api, status, d) {
  const msg = d?.error?.message || '', why = `${msg} ${d?.error?.status || ''} ${d?.error?.errors?.[0]?.reason || ''}`;
  if (/has not been used|is disabled|accessNotConfigured|SERVICE_DISABLED/i.test(why)) {
    return `The ${api} API is switched off in your Google Cloud project. In Google Cloud open APIs and Services, Library, search for "${api}", press Enable, wait a minute and try again.`;
  }
  if (status === 403 && /insufficient|scope|PERMISSION_DENIED/i.test(why)) {
    return `This Google token was made without ${api} permission. Make a new refresh token that includes ${SCOPE[api] || 'that scope'} and put it in G_ACCOUNTS.`;
  }
  if (status === 401) return 'Google did not accept this token. It may have expired or been revoked: make a new refresh token.';
  return `${api} answered ${status}${msg ? ': ' + msg : ''}`;
}

/* A small markdown to HTML step, so Google converts the text into a properly formatted Doc. */
export function toHtml(src) {
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const inl = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  let out = '', list = false;
  for (const ln of String(src).split('\n')) {
    const li = ln.match(/^\s*[-*]\s+(.*)/);
    if (li) { if (!list) { out += '<ul>'; list = true; } out += `<li>${inl(li[1])}</li>`; continue; }
    if (list) { out += '</ul>'; list = false; }
    const h = ln.match(/^(#{1,3})\s+(.*)/);
    if (h) out += `<h${h[1].length}>${inl(h[2])}</h${h[1].length}>`;
    else if (ln.trim()) out += `<p>${inl(ln)}</p>`;
  }
  return `<html><body>${out}${list ? '</ul>' : ''}</body></html>`;
}

export function makeDrive({ gToken, acctNames }) {
  async function call(api, url, opts = {}, acct) {
    const name = acct || acctNames()[0];
    const r = await fetch(url, { ...opts, headers: { authorization: 'Bearer ' + (await gToken(name)), ...(opts.headers || {}) } });
    if (!r.ok) throw new Error(friendly(api, r.status, await r.json().catch(() => ({}))));
    return r;
  }
  const q1 = (s) => String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'");

  async function find(query, acct) {
    const q = ['trashed = false', query ? `(name contains '${q1(query)}' or fullText contains '${q1(query)}')` : ''].filter(Boolean).join(' and ');
    const r = await call('Google Drive', `https://www.googleapis.com/drive/v3/files?pageSize=10&orderBy=${encodeURIComponent('modifiedTime desc')}&fields=${encodeURIComponent('files(id,name,mimeType,modifiedTime,webViewLink)')}&q=${encodeURIComponent(q)}`, {}, acct);
    return (await r.json()).files || [];
  }

  async function read(id, acct) {
    const base = `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}`;
    const meta = await (await call('Google Drive', `${base}?fields=id,name,mimeType,webViewLink`, {}, acct)).json();
    const g = meta.mimeType || '';
    let url;
    if (g === 'application/vnd.google-apps.document' || g === 'application/vnd.google-apps.presentation') url = `${base}/export?mimeType=text/plain`;
    else if (g === 'application/vnd.google-apps.spreadsheet') url = `${base}/export?mimeType=text/csv`;
    else if (/^text\//.test(g) || /json|csv|xml|markdown/.test(g)) url = `${base}?alt=media`;
    else throw new Error(`I cannot read "${meta.name}" (${g || 'unknown type'}) from here.`);
    const t = await (await call('Google Drive', url, {}, acct)).text();
    return { ...meta, text: t.slice(0, 8000), truncated: t.length > 8000 };
  }

  async function create(title, content, acct) {
    const b = 'omni' + Math.random().toString(36).slice(2);
    const meta = JSON.stringify({ name: String(title || 'Untitled').slice(0, 200), mimeType: 'application/vnd.google-apps.document', appProperties: { omni: '1' } });
    const body = `--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--${b}\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n${toHtml(content)}\r\n--${b}--`;
    const r = await call('Google Drive', 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink', { method: 'POST', headers: { 'content-type': `multipart/related; boundary=${b}` }, body }, acct);
    return r.json();
  }

  /* Only documents this assistant created itself can be added to. */
  async function append(id, text, acct) {
    const meta = await (await call('Google Drive', `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}?fields=id,name,mimeType,appProperties,webViewLink`, {}, acct)).json();
    if (meta.mimeType !== 'application/vnd.google-apps.document') throw new Error('That is not a Google Doc.');
    if (meta.appProperties?.omni !== '1') throw new Error(`I only add to documents I created myself, and "${meta.name}" is not one of them. I can make a new document instead.`);
    await call('Google Docs', `https://docs.googleapis.com/v1/documents/${encodeURIComponent(id)}:batchUpdate`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ requests: [{ insertText: { endOfSegmentLocation: {}, text: '\n' + String(text).slice(0, 20000) } }] }),
    }, acct);
    return meta;
  }
  return { find, read, create, append };
}

/* Checks every Google account against Gmail, Calendar, Drive and Docs and explains each failure. */
export async function probe({ gToken, acctNames }) {
  const out = [];
  for (const name of acctNames()) {
    const row = { name, email: '', token: 'ok', gmail: '', calendar: '', drive: '', docs: '' };
    let tok;
    try { tok = await gToken(name); } catch (e) { row.token = e.message; out.push(row); continue; }
    const H = { authorization: 'Bearer ' + tok };
    const one = async (key, api, url, okStatuses = [200]) => {
      try {
        const r = await fetch(url, { headers: H }), d = await r.json().catch(() => ({}));
        row[key] = okStatuses.includes(r.status) ? 'ok' : friendly(api, r.status, d);
        if (key === 'gmail' && d.emailAddress) row.email = d.emailAddress;
      } catch (e) { row[key] = e.message; }
    };
    await Promise.all([
      one('gmail', 'Gmail', 'https://gmail.googleapis.com/gmail/v1/users/me/profile'),
      one('calendar', 'Google Calendar', 'https://www.googleapis.com/calendar/v3/users/me/calendarList?maxResults=1'),
      one('drive', 'Google Drive', 'https://www.googleapis.com/drive/v3/about?fields=user'),
      one('docs', 'Google Docs', 'https://docs.googleapis.com/v1/documents/omni-probe', [404, 400]),
    ]);
    out.push(row);
  }
  return out;
}
