export default function mount({ app, db, auth, A, llm, toJson, E, gToken }) {
  const eat = () => new Date(Date.now() + 3 * 36e5).toISOString().slice(0, 16).replace('T', ' ');

  app.get('/api/events', auth, A(async (_, res) => res.json((await db.from('events').select().gte('end_at', new Date(Date.now() - 864e5).toISOString()).order('start_at').limit(50)).data)));
  app.post('/api/events', auth, A(async (req, res) => {
    const { title, start_at, end_at } = req.body;
    if (!String(title || '').trim() || !start_at) return res.status(400).json({ error: 'Give the event a title and a start time.' });
    res.json((await db.from('events').insert({ title, start_at, end_at: end_at || start_at }).select().single()).data);
  }));
  app.delete('/api/events/:id', auth, A(async (req, res) => {
    const { data: ev } = await db.from('events').select('gcal_id').eq('id', req.params.id).maybeSingle();
    let warning;
    if (ev?.gcal_id) {
      /* Best effort: a Google sign-in problem must not stop you deleting the local copy. */
      try { await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(ev.gcal_id)}?sendUpdates=none`, { method: 'DELETE', headers: { authorization: 'Bearer ' + (await gToken()) } }); }
      catch (e) { warning = 'Deleted here, but not in Google Calendar: ' + e.message; }
    }
    await db.from('events').delete().eq('id', req.params.id);
    res.json({ ok: true, warning });
  }));
  app.put('/api/tasks/:id', auth, A(async (req, res) => res.json((await db.from('tasks').update({ status: req.body.status }).eq('id', req.params.id).select().single()).data)));
  app.get('/api/inbox', auth, A(async (_, res) => res.json((await db.from('inbox').select().order('id', { ascending: false }).limit(20)).data)));
  app.post('/api/outbox/:id/discard', auth, A(async (req, res) => { await db.from('outbox').update({ status: 'discarded' }).eq('id', req.params.id); res.json({ ok: true }); }));

  app.post('/api/agenda', auth, A(async (_, res) => {
    const { data: tasks } = await db.from('tasks').select().eq('status', 'open').order('due').limit(20);
    const { data: events } = await db.from('events').select().gte('end_at', new Date().toISOString()).order('start_at').limit(20);
    res.json({ plan: await llm([{ role: 'user', content: `Now: ${eat()} EAT. Stored times are UTC; show everything in EAT (UTC+3). Tasks: ${JSON.stringify(tasks)}. Events: ${JSON.stringify(events)}. Build today's agenda as a short timed list. Put deep-code and high-focus work only inside 07:00-10:00 and 20:00-23:00 EAT; use other hours for light tasks, messages and breaks. Flag conflicts and overdue tasks.` }]) });
  }));

  app.get('/api/brief', auth, A(async (_, res) => {
    const [t, o, i] = await Promise.all([
      db.from('tasks').select('title').eq('status', 'open').order('due').limit(5),
      db.from('outbox').select('id').eq('status', 'pending'),
      db.from('inbox').select('channel,sender,triage').order('id', { ascending: false }).limit(10),
    ]);
    const urgent = (i.data || []).filter((m) => m.triage?.urgency === 'high');
    res.json({ text: `Open tasks: ${(t.data || []).map((x) => x.title).join('; ') || 'none'}. Replies waiting: ${(o.data || []).length}. Urgent messages: ${urgent.map((m) => `${m.channel} from ${m.sender}: ${m.triage.summary}`).join('; ') || 'none'}.` });
  }));

  const px = new Map();
  app.get('/api/assets', auth, A(async (req, res) => {
    const q = String(req.query.q || '').slice(0, 100), type = ['photo', 'illustration', 'vector'].includes(req.query.type) ? req.query.type : 'photo', k = type + q, hit = px.get(k);
    if (hit && Date.now() - hit.at < 864e5) return res.json(hit.d);
    const r = await fetch(`https://pixabay.com/api/?key=${E.PIXABAY_KEY}&q=${encodeURIComponent(q)}&image_type=${type}&per_page=18&safesearch=true`).then(toJson);
    const d = { hits: (r.hits || []).map((h) => ({ id: h.id, tags: h.tags, previewURL: h.previewURL, pageURL: h.pageURL })) };
    px.set(k, { at: Date.now(), d });
    res.json(d);
  }));

  app.post('/api/live-token', auth, A(async (_, res) => {
    const now = Date.now();
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/auth_tokens', {
      method: 'POST',
      headers: { 'x-goog-api-key': E.GEMINI_KEY, 'content-type': 'application/json' },
      body: JSON.stringify({ uses: 1, expireTime: new Date(now + 30 * 60e3).toISOString(), newSessionExpireTime: new Date(now + 60e3).toISOString() }),
    }).then(toJson);
    if (!r.name) return res.status(502).json({ error: r.error?.message || 'No token returned' });
    res.json({ token: r.name, model: E.LIVE_MODEL || 'gemini-3.8-live', voice: E.VOICE_NAME || 'Charon' });
  }));
}
