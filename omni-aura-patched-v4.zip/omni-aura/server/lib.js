/* Pure helpers with no imports from the rest of the server, so they can be tested on their own. */

/* ---------- Google accounts ----------
   G_ACCOUNTS should be {"name":"refresh-token"}, but on a phone it often arrives with curly quotes,
   wrapped in an extra pair of quotes, as name=token pairs, or as a bare list. Accept all of those, and
   when nothing usable is found say exactly what is wrong instead of a generic "add G_ACCOUNTS". */
const straighten = (s) => String(s ?? '')
  .replace(/[\u201C\u201D\u201E\u201F\u2033]/g, '"')
  .replace(/[\u2018\u2019\u201A\u201B\u2032]/g, "'")
  .replace(/[\u00A0\u200B\uFEFF]/g, ' ');
export const unquote = (v) => String(v ?? '').trim().replace(/^[`"']+|[`"']+$/g, '').trim();
const looksLikeToken = (t) => /^1\/\/[\w\-./~+]{20,}$/.test(t);

export function parseAccounts(rawAccounts, rawRefresh) {
  const accounts = {};
  const warn = [];
  let problem = '';
  const add = (name, tok) => {
    const t = unquote(tok);
    if (!t) return;
    const n = String(name ?? '').trim() || 'acct' + (Object.keys(accounts).length + 1);
    accounts[n] = t;
    if (!looksLikeToken(t)) warn.push(`The value for "${n}" does not look like a Google refresh token (they start with 1//). Google will probably refuse it.`);
  };
  const fromValue = (k, v) => add(k, v && typeof v === 'object' ? v.refresh || v.token || v.refresh_token : v);

  const src = straighten(rawAccounts).trim();
  if (src) {
    let body = src;
    if (/^(['"`])[\s\S]*\1$/.test(body) && /[{[]/.test(body)) body = body.slice(1, -1).trim();
    let parsed = false;
    try {
      const j = JSON.parse(body);
      parsed = true;
      if (Array.isArray(j)) j.forEach((v, i) => fromValue(v && typeof v === 'object' ? v.name : 'acct' + (i + 1), v));
      else if (j && typeof j === 'object') Object.entries(j).forEach(([k, v]) => fromValue(k, v));
    } catch { /* not JSON: try the looser formats below */ }
    if (!parsed) {
      let emails = 0;
      for (const part of body.split(/[\n,;]+/).map((p) => p.trim()).filter(Boolean)) {
        const kv = part.match(/^["']?([\w .@-]+?)["']?\s*[=:]\s*["']?(\S+?)["']?$/);
        if (kv && !/^https?$/i.test(kv[1])) add(kv[1], kv[2]);
        else if (looksLikeToken(unquote(part))) add('', part);
        else if (/@/.test(part)) emails += 1;
      }
      if (!Object.keys(accounts).length) {
        problem = emails
          ? 'G_ACCOUNTS holds email addresses. It has to hold Google OAuth refresh tokens (they start with 1//), written like {"main":"1//0g..."}. An email address on its own cannot sign in.'
          : `G_ACCOUNTS is set (${src.length} characters) but it is not valid JSON. Write it like {"main":"1//0g..."} with straight double quotes. A phone keyboard often turns them into curly quotes.`;
      }
    } else if (!Object.keys(accounts).length) {
      problem = 'G_ACCOUNTS is valid JSON but holds no refresh token. Write it like {"main":"1//0g..."}.';
    }
  }
  const single = unquote(straighten(rawRefresh));
  if (!Object.keys(accounts).length && single) {
    add('primary', single);
    problem = '';
  }
  if (!Object.keys(accounts).length && !problem) problem = 'No Google account is set up. Add G_ACCOUNTS as {"main":"1//0g..."} (or G_REFRESH) under Render, Environment, then redeploy.';
  return { accounts, problem, warn };
}

/* ---------- spoken passphrase ----------
   "Omni Aura 5063", "omni-aura fifty sixty three" and "OmniAura five oh six three" all mean OmniAura5063. */
const ONES = { zero: 0, oh: 0, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9 };
const TEENS = { ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19 };
const TENS = { twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90 };
export function spokenDigits(text) {
  const w = String(text ?? '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean);
  const out = [];
  for (let i = 0; i < w.length; i++) {
    const t = w[i];
    if (t in TENS) {
      let n = TENS[t];
      if (w[i + 1] in ONES && ONES[w[i + 1]] > 0) n += ONES[w[++i]];
      out.push(String(n));
    } else if (t in TEENS) out.push(String(TEENS[t]));
    else if (t in ONES) out.push(String(ONES[t]));
    else out.push(t);
  }
  return out.join(' ');
}
export const squash = (s) => spokenDigits(s).replace(/[^a-z0-9]/g, '');
/* `heard` may hold several recogniser guesses separated by "|". Any one of them matching is enough. */
export function passMatches(heard, pass) {
  const want = squash(pass);
  if (!want) return false;
  return String(heard ?? '').split('|').some((alt) => { const got = squash(alt); return !!got && got.includes(want); });
}
