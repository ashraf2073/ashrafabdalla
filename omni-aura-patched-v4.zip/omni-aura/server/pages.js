import { readFileSync } from 'node:fs';
export default function mountPages({ app }) {
  const rd = (f) => readFileSync(new URL('./' + f, import.meta.url), 'utf8');
  app.get('/', (_, res) => res.type('html').send(rd('home.html')));
  app.get('/privacy', (_, res) => res.type('html').send(rd('privacy.html')));
  app.get('/terms', (_, res) => res.type('html').send(rd('terms.html')));
}
