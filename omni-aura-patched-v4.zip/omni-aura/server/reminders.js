export default function mountReminders({ app, db, auth, cron, A, push }) {
  const today = () => Date.parse(new Date(Date.now() + 3 * 36e5).toISOString().slice(0, 10) + 'T00:00:00Z');
  const daysUntil = (d) => Math.round((Date.parse(d + 'T00:00:00Z') - today()) / 864e5);
  const LABEL = { 7: 'in 7 days', 3: 'in 3 days', 1: 'tomorrow, 24 hours from now', 0: 'today', '-1': 'overdue since yesterday' };
  const advance = (d, cycle) => {
    const t = new Date(d + 'T00:00:00Z');
    if (cycle === 'weekly') t.setUTCDate(t.getUTCDate() + 7);
    else if (cycle === 'yearly') t.setUTCFullYear(t.getUTCFullYear() + 1);
    else {
      const day = t.getUTCDate();
      t.setUTCDate(1); t.setUTCMonth(t.getUTCMonth() + 1);
      t.setUTCDate(Math.min(day, new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate()));
    }
    return t.toISOString().slice(0, 10);
  };

  app.post('/cron/reminders', cron, A(async (_, res) => {
    const { data: subs } = await db.from('subscriptions').select().eq('active', true);
    const sent = [];
    for (const s of subs || []) {
      const d = daysUntil(s.next_due);
      if (!(d in LABEL) || (s.notified || []).includes(d)) continue;
      if (!(await push(`${s.name}${s.amount ? ' (' + s.amount + ')' : ''} is due ${LABEL[d]}.${s.notes ? ' How to pay: ' + s.notes : ''}`, 'OMNI-AURA payment reminder', d <= 0))) continue;
      await db.from('subscriptions').update({ notified: [...(s.notified || []), d] }).eq('id', s.id);
      sent.push(`${s.name}:${d}`);
    }
    res.json({ sent });
  }));

  app.get('/api/subs', auth, A(async (_, res) => res.json((await db.from('subscriptions').select().eq('active', true).order('next_due')).data)));
  app.post('/api/subs', auth, A(async (req, res) => {
    const { name, amount, cycle, next_due, notes } = req.body;
    if (!name || !/^\d{4}-\d{2}-\d{2}$/.test(next_due || '') || !['weekly', 'monthly', 'yearly', 'once'].includes(cycle)) return res.status(400).json({ error: 'Name, cycle and a due date are required.' });
    res.json((await db.from('subscriptions').insert({ name: String(name).slice(0, 100), amount: amount || null, cycle, next_due, notes: notes || null }).select().single()).data);
  }));
  app.post('/api/subs/:id/paid', auth, A(async (req, res) => {
    const { data: s } = await db.from('subscriptions').select().eq('id', req.params.id).maybeSingle();
    if (!s) return res.sendStatus(404);
    let patch = { active: false };
    if (s.cycle !== 'once') {
      let n = advance(s.next_due, s.cycle);
      for (let i = 0; i < 24 && daysUntil(n) < 0; i++) n = advance(n, s.cycle);
      patch = { next_due: n, notified: [] };
    }
    res.json((await db.from('subscriptions').update(patch).eq('id', s.id).select().single()).data);
  }));
  app.delete('/api/subs/:id', auth, A(async (req, res) => { await db.from('subscriptions').delete().eq('id', req.params.id); res.json({ ok: true }); }));
}
