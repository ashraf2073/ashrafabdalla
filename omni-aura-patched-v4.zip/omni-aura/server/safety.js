import crypto from 'node:crypto';
export default function mountSafety({ app, db, auth, cron, A, E, settings, push, gmailSend, pinOk }) {
  const eat = (d) => new Date(new Date(d).getTime() + 3 * 36e5).toISOString().slice(11, 16);
  const sig = (id, a) => crypto.createHmac('sha256', E.CRON_SECRET || 'x').update(`${id}:${a}`).digest('hex').slice(0, 24);
  const base = () => (E.PUBLIC_URL || E.RENDER_EXTERNAL_URL || '').replace(/\/$/, '');
  const num = (v) => typeof v === 'number' && Number.isFinite(v);
  const REASONS = { logo: 'he used the silent SOS', button: 'he held the help button', queued: 'he used the silent SOS while the phone was offline, so this arrived late' };
  let lastOk = 0, running = null;

  /* One alert at a time. The 60 second quiet period only starts after an alert actually got out,
     so a failed attempt can always be retried. A second tap while one is in flight joins it. */
  function fire(reason, opt = {}) {
    const live = !opt.test && !opt.followup;
    if (live) {
      if (running) return running;
      if (Date.now() - lastOk < 60e3) return Promise.resolve({ ok: true, skipped: true, result: 'skipped, an alert was just sent' });
    }
    if (opt.followup && Date.now() - lastOk > 10 * 60e3) return Promise.resolve({ ok: true, skipped: true, result: 'no recent alert to update' });
    const job = deliver(reason, opt)
      .then((r) => { if (r.ok && live) lastOk = Date.now(); return r; })
      .finally(() => { if (running === job) running = null; });
    if (live) running = job;
    return job;
  }

  async function deliver(reason, { silent = false, test = false, eventId, followup = false }) {
    let s = {}, cs = [];
    try { s = (await settings()) || {}; } catch (e) { console.warn('safety: settings unreadable:', e.message); }
    try { cs = (await db.from('contacts').select()).data || []; }
    catch (e) { console.warn('safety: contacts unreadable:', e.message); return { ok: false, result: 'could not read your contacts: ' + e.message }; }
    const where = num(s.loc_lat) && num(s.loc_lon) ? `https://maps.google.com/?q=${s.loc_lat},${s.loc_lon} (updated ${s.loc_at ? eat(s.loc_at) + ' EAT' : 'at an unknown time'})` : 'location not available';
    const lead = test ? 'TEST ONLY, no danger. ' : '';
    const text = followup
      ? `${lead}Safety update: Ashraf's latest location: ${where}. Sent automatically by Omni-Aura.`
      : `${lead}Safety alert: Ashraf may need help (${reason}). Last known location: ${where}. Sent automatically by Omni-Aura.`;
    const sent = [];
    const wa = async (to) => {
      const body = E.WA_SAFETY_TEMPLATE
        ? { messaging_product: 'whatsapp', to, type: 'template', template: { name: E.WA_SAFETY_TEMPLATE, language: { code: E.WA_SAFETY_LANG || 'en' }, components: [{ type: 'body', parameters: [{ type: 'text', text: 'Ashraf' }, { type: 'text', text: where }] }] } }
        : { messaging_product: 'whatsapp', to, text: { body: text } };
      const r = await fetch(`https://graph.facebook.com/${E.GRAPH_VERSION || 'v21.0'}/${E.WA_PHONE_ID}/messages`, { method: 'POST', headers: { authorization: 'Bearer ' + E.WA_TOKEN, 'content-type': 'application/json' }, body: JSON.stringify(body) });
      if (!r.ok) console.warn('safety: WhatsApp refused', r.status, (await r.text().catch(() => '')).slice(0, 300), E.WA_SAFETY_TEMPLATE ? '' : '(no WA_SAFETY_TEMPLATE set: free text only works inside the 24-hour window)');
      return r.ok;
    };
    const job = (c, via, f) => Promise.resolve().then(f).then((ok) => sent.push(`${c.name} ${via} ${ok ? 'ok' : 'failed'}`)).catch((e) => { console.warn(`safety: ${c.name} ${via} failed:`, e.message); sent.push(`${c.name} ${via} failed`); });
    await Promise.all(cs.flatMap((c) => [
      c.email && job(c, 'email', () => gmailSend({ to_addr: c.email, subject: `${test ? 'TEST: ' : ''}${followup ? 'Safety update' : 'Safety alert'} from Ashraf`, body: text, fresh: true })),
      c.ntfy_topic && job(c, 'ntfy', () => fetch(`https://ntfy.sh/${encodeURIComponent(c.ntfy_topic)}`, { method: 'POST', headers: { Title: test ? 'TEST safety alert' : followup ? 'Safety update' : 'Safety alert', Priority: '5', Tags: 'rotating_light' }, body: text }).then((r) => r.ok)),
      c.whatsapp && E.WA_PHONE_ID && E.WA_TOKEN && job(c, 'whatsapp', () => wa(c.whatsapp)),
    ].filter(Boolean)));
    const result = sent.join('; ') || 'no contacts set up';
    const ok = sent.some((x) => x.endsWith(' ok'));
    /* Bookkeeping after the alert must never turn a delivered alert into an error. */
    if (eventId) { try { await db.from('safety_events').update({ result }).eq('id', eventId); } catch (e) { console.warn('safety: result not saved:', e.message); } }
    if (!silent) { try { await push(`Alert sent: ${result}`, 'OMNI-AURA safety', true); } catch (e) { console.warn('safety: own notification failed:', e.message); } }
    return { ok, result, noContacts: !sent.length };
  }

  /* Whole word or phrase only, so a code word like "star" is not set off by "start". */
  const norm = (x) => String(x).toLowerCase().replace(/\s+/g, ' ').trim();
  const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  app.locals.duress = async (text) => {
    let w = '';
    try { w = norm((await settings()).duress_word || ''); } catch { return false; }
    if (w.length < 4) return false;
    if (!new RegExp(`(^|[^\\p{L}\\p{N}])${esc(w)}($|[^\\p{L}\\p{N}])`, 'u').test(norm(text))) return false;
    fire('he used his code word', { silent: true }).catch(() => {});
    return true;
  };

  app.get('/api/safety/contacts', auth, A(async (_, res) => res.json((await db.from('contacts').select().order('id')).data)));
  app.post('/api/safety/contacts', auth, A(async (req, res) => {
    const { name, email, whatsapp, ntfy_topic } = req.body;
    if (!name || !(email || whatsapp || ntfy_topic)) return res.status(400).json({ error: 'Give a name and at least one way to reach them.' });
    res.json((await db.from('contacts').insert({ name: String(name).slice(0, 80), email: email || null, whatsapp: String(whatsapp || '').replace(/\D/g, '') || null, ntfy_topic: ntfy_topic || null }).select().single()).data);
  }));
  app.delete('/api/safety/contacts/:id', auth, A(async (req, res) => { await db.from('contacts').delete().eq('id', req.params.id); res.json({ ok: true }); }));
  const saveLoc = async (lat, lon) => {
    if (!num(lat) || !num(lon)) return;
    try { await db.from('settings').update({ loc_lat: lat, loc_lon: lon, loc_at: new Date().toISOString() }).eq('id', 1); } catch (e) { console.warn('safety: location not saved:', e.message); }
  };
  app.post('/api/safety/location', auth, A(async (req, res) => { await saveLoc(req.body.lat, req.body.lon); res.json({ ok: true }); }));

  app.get('/api/safety/timer', auth, A(async (_, res) => { const { data } = await db.from('safety_events').select().in('status', ['active', 'checking']).order('id', { ascending: false }).limit(1); res.json(data?.[0] || null); }));
  app.post('/api/safety/timer', auth, A(async (req, res) => {
    const m = Math.max(5, Math.min(480, +req.body.minutes || 30));
    await db.from('safety_events').update({ status: 'cancelled' }).in('status', ['active', 'checking']);
    res.json((await db.from('safety_events').insert({ kind: 'timer', status: 'active', minutes: m, due_at: new Date(Date.now() + m * 6e4).toISOString() }).select().single()).data);
  }));
  app.post('/api/safety/timer/:id/cancel', auth, A(async (req, res) => {
    const pin = String(req.body.pin || '');
    if (E.DURESS_PIN && pin === E.DURESS_PIN) {
      await db.from('safety_events').update({ status: 'cancelled' }).eq('id', req.params.id);
      fire('he entered his duress PIN', { silent: true }).catch(() => {});
      return res.json({ ok: true });
    }
    if (!pinOk(pin)) return res.status(403).json({ error: 'Wrong PIN' });
    await db.from('safety_events').update({ status: 'ok' }).eq('id', req.params.id).in('status', ['active', 'checking']);
    res.json({ ok: true });
  }));

  /* The app sends this from the logo triple tap and from the help button. It returns
     { ok, result, skipped?, noContacts? } and never waits for a GPS fix. A later call with
     followup:true sends contacts the better location once the phone has it. */
  app.post('/api/safety/sos', auth, A(async (req, res) => {
    const { lat, lon, source, followup } = req.body || {};
    await saveLoc(lat, lon);
    res.json(await fire(REASONS[source] || REASONS.button, { silent: true, followup: !!followup }));
  }));
  app.post('/api/safety/test', auth, A(async (_, res) => { const r = await fire('this is a test', { test: true }); res.json({ ok: r.ok, result: r.result }); }));

  app.post('/cron/safety', cron, A(async (_, res) => {
    const now = new Date().toISOString(), out = [], grace = +E.SAFE_GRACE_S || 120;
    const { data: due } = await db.from('safety_events').select().eq('status', 'active').lte('due_at', now);
    for (const e of due || []) {
      await db.from('safety_events').update({ status: 'checking', grace_until: new Date(Date.now() + grace * 1e3).toISOString() }).eq('id', e.id);
      const u = (a) => `${base()}/safety/respond?id=${e.id}&a=${a}&sig=${sig(e.id, a)}`;
      /* Priority 5 (urgent): an unanswered quick check alerts your contacts, so it must not be silent. */
      if (E.NTFY_TOPIC) await fetch(`https://ntfy.sh/${E.NTFY_TOPIC}`, { method: 'POST', headers: { Title: 'Quick check', Priority: '5', Tags: 'warning', Actions: `http, Fine, ${u('ok')}, method=POST, clear=true; http, Help, ${u('help')}, method=POST, clear=true` }, body: `Tap Fine or Help. No answer within ${grace} seconds sends your alert.` }).catch(() => {});
      out.push('check ' + e.id);
    }
    /* An event only becomes 'alerted' once an alert got out. Otherwise the next minute tries again,
       for up to 10 minutes after the grace period. */
    const { data: late } = await db.from('safety_events').select().eq('status', 'checking').lte('grace_until', now);
    for (const e of late || []) {
      const r = await fire('his safe-walk timer ended and he did not answer', { eventId: e.id });
      const giveUp = Date.now() - new Date(e.grace_until).getTime() > 10 * 60e3;
      if (r.ok || giveUp) await db.from('safety_events').update({ status: 'alerted' }).eq('id', e.id);
      out.push(`alert ${e.id}: ${r.result}${r.ok || giveUp ? '' : ' (will retry)'}`);
    }
    res.json({ out });
  }));

  app.all('/safety/respond', A(async (req, res) => {
    const { id, a, sig: s } = req.query;
    if (!E.CRON_SECRET || !['ok', 'help'].includes(a) || s !== sig(id, a)) return res.sendStatus(403);
    const { data: e } = await db.from('safety_events').select().eq('id', id).maybeSingle();
    if (!e) return res.sendStatus(404);
    if (a === 'ok') { await db.from('safety_events').update({ status: 'ok' }).eq('id', id).in('status', ['active', 'checking']); return res.send('ok'); }
    const r = await fire('he tapped Help on a quick check', { eventId: +id, silent: true });
    if (r.ok) await db.from('safety_events').update({ status: 'alerted' }).eq('id', id);
    res.send(r.ok ? 'ok' : 'not sent, will retry');
  }));
}
