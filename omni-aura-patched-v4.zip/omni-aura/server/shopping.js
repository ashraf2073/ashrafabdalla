export default function mountShopping({ app, db, auth, A, settings, E }) {
  app.get('/api/shop', auth, A(async (_, res) => res.json((await db.from('shopping').select().order('status').order('id', { ascending: false })).data)));
  app.post('/api/shop', auth, A(async (req, res) => {
    const { name, note, budget, link } = req.body;
    if (!name) return res.status(400).json({ error: 'Name the item first.' });
    res.json((await db.from('shopping').insert({ name: String(name).slice(0, 120), note: note || null, budget: budget || null, link: /^https?:\/\//i.test(link || '') ? link : null }).select().single()).data);
  }));
  app.put('/api/shop/:id', auth, A(async (req, res) => res.json((await db.from('shopping').update({ status: req.body.status === 'bought' ? 'bought' : 'todo' }).eq('id', req.params.id).select().single()).data)));
  app.delete('/api/shop/:id', auth, A(async (req, res) => { await db.from('shopping').delete().eq('id', req.params.id); res.json({ ok: true }); }));

  app.post('/api/shop/:id/find', auth, A(async (req, res) => {
    const { data: it } = await db.from('shopping').select().eq('id', req.params.id).maybeSingle();
    if (!it) return res.sendStatus(404);
    const s = await settings();
    const id = [s.model, ...(s.fallback || [])].find((x) => x?.startsWith('gemini:'));
    if (!id) return res.status(400).json({ error: 'Pick a Gemini model in Settings first; web search needs one.' });
    const text = `Shopper in ${E.SHOP_REGION || 'Kenya'}; use local currency where possible. Item: "${it.name}". Details: ${it.note || 'none'}. Budget: ${it.budget || 'none'}.\nFind up to 3 good options currently on sale. For each give the name, approximate price and store, and one line on why it fits. Add one line on authenticity or warranty risks. Never invent prices: write "price not found" instead. Plain text, no tables.`;
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${id.slice(7)}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': E.GEMINI_KEY },
      body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text }] }], tools: [{ google_search: {} }] }),
    });
    const d = await r.json();
    if (!r.ok) return res.status(502).json({ error: d.error?.message || 'Search failed' });
    const c = d.candidates?.[0];
    const options = (c?.content?.parts || []).map((p) => p.text || '').join('');
    const sources = (c?.groundingMetadata?.groundingChunks || []).map((g) => g.web).filter(Boolean).slice(0, 6).map((w) => ({ title: w.title, uri: w.uri }));
    res.json((await db.from('shopping').update({ options, sources }).eq('id', it.id).select().single()).data);
  }));
}
