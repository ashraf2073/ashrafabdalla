-- OMNI-AURA wipe. DELETES every Omni-Aura table and everything in it (chat history, notes, tasks, drafts, settings ...), then
-- the owner function. It touches nothing else in your project (your sign-in accounts are kept).
-- Only needed for a true fresh start. Normally just run 01-schema.sql, which repairs without deleting.
-- To really wipe: on the line marked EDIT change NO to WIPE, run this, then run 01-schema.sql.

do $$
declare
  confirm_text text := 'NO'; -- EDIT: change NO to WIPE
  t text;
begin
  if confirm_text <> 'WIPE' then
    raise exception 'Nothing was deleted. To wipe, change NO to WIPE on the line marked EDIT and run again.';
  end if;
  foreach t in array array['settings', 'tasks', 'events', 'subscriptions', 'shopping', 'scenes', 'memories', 'briefings', 'checkins', 'actions', 'chat_log', 'writing_log', 'inbox', 'outbox', 'contacts', 'safety_events', 'calls', 'push_subs', 'app_kv', 'chats'] loop
    execute format('drop table if exists public.%I cascade', t);
  end loop;
  drop function if exists public.is_owner() cascade;
end $$;

-- Anything else left in the public schema (from earlier versions) is listed here; it was not touched.
select table_name as leftover_table from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE';
